﻿using CareCoordination.Application.Abstracts.DALInterfaces;
using CareCoordination.Application.Abstracts.HandlerInterfaces;
using CareCoordination.Application.Abstracts.ServiceInterfaces;
using CareCoordination.Application.Models;
using CareCoordination.Domain.Constants;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordination.Application.Handlers
{
    public class PatientLookupManagement:IPatientLookupManagement
    {
        private readonly IPatientLookupService _memberLookupService;
        private readonly IPatientRepository patientRepository;

        public PatientLookupManagement(IPatientLookupService memberLookupService, IPatientRepository patientRepository)
        {
            _memberLookupService = memberLookupService;
            this.patientRepository = patientRepository;
        }
        public async Task<List<PatientDetailsResponse>> GetMemberDetails(PatientLookupRequestModel request)
        {
            request.RequestedBy = Constants.ClientSystemCC;
            request.CPTcode = Constants.DefaultCPT;
            List<PatientDetailsResponse> patientdetails= await _memberLookupService.GetMemberDetails(request);
            if(patientdetails!=null && patientdetails.Count > 0)
            {
                foreach(PatientDetailsResponse response in patientdetails)
                {
                    if(string.IsNullOrWhiteSpace(response.ErrorMsg)){
                        response.Response.Patient.IsRestrictedMember = patientRepository.IsRestrictedMember(response.Response.Patient.PatientID);
                    }
                }
            }
            return patientdetails;

        }
        public async Task<List<MemberEligibilityResponseModel>> GetMemberEligibility(MemberEligibilityRequestModel request)
        {
            request.Qualifiers.ReviewType = Constants.ReviewType;
            request.Qualifiers.Workflow = Constants.WorkFlow;
            request.Qualifiers.ClientSystem = Constants.ClientSystemCC;
            return await _memberLookupService.GetMemberEligibility(request);
        }
    }
}

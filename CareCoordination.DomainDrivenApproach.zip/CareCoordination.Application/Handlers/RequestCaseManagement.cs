﻿using CareCoordination.Application.Abstracts.DALInterfaces;
using CareCoordination.Application.Abstracts.HandlerInterfaces;
using CareCoordination.Application.Models;

namespace CareCoordination.Application.Handlers
{
    public class RequestCaseManagement : ICaseManagement
    {
        private readonly IRequestManagement _handleRequest;
        public RequestCaseManagement(IRequestManagement handleRequest)
        {
            _handleRequest = handleRequest;              
        }
        public Task<CaseManagementResponseModel> UpdateCaseStatusAsync(CaseManagementModel request)
        {
            return _handleRequest.UpdateCaseStatusAsync(request);
        }
        public Task<CaseManagementResponseModel> UpdateIsEscalateRequestAsync(CaseManagementModel request)
        {
            return _handleRequest.UpdateIsEscalateRequestAsync(request);
        }
        public Task<CaseManagementResponseModel> UpdateMissedStartOfCareAsync(CaseManagementModel request)
        {
            return _handleRequest.UpdateMissedStartOfCareAsync(request);
        }
        public Task<CaseManagementResponseModel> UpdateFollowUpDateAsync(CaseManagementModel request)
        {
            return _handleRequest.UpdateFollowUpDateAsync(request);
        }
        public Task<CaseManagementResponseModel> AddNoteAsync(CaseManagementModel request)
        {
            var result = _handleRequest.AddNoteAsync(request);
            return result;
        }
        public Task<CaseManagementResponseModel> UpdateCaseManagerAsync(CaseManagementModel request)
        {
            return _handleRequest.UpdateCaseManagerAsync(request);
        }
        public Task<List<CareCoordinationActivityResponseModel>> GetActivityAsync(string careCoordinationEpisodeId)
        {
            return _handleRequest.GetActivityAsync(careCoordinationEpisodeId);
        }
    }
}

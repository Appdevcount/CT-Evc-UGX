﻿using AutoMapper;
using CareCoordination.Application.Abstracts.DALInterfaces;
using CareCoordination.Application.Abstracts.HandlerInterfaces;
using CareCoordination.Application.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordination.Application.Handlers
{
    public class RequestViewLookupManagement :IRequestViewLookupManagement
    {
        private readonly IProcedureCodeSearchAndUpdate _reqViewDetails;
        public RequestViewLookupManagement(IProcedureCodeSearchAndUpdate reqViewDetails, IMapper mapper)
        {
            _reqViewDetails = reqViewDetails;

        }
        public Task<ProcedureCodeSearchResponseModel> GetProcedureCodes(ProcedureCodeSearchRequestModel request)

        {
            return _reqViewDetails.GetProcedureCodes(request);
        }

        public Task<ProcedureCodeAddOrRemoveResponseModel> AddProcedureCode(ProcedureCodeAddOrRemoveRequestModel request)
        {
            return _reqViewDetails.AddProcedureCode(request);
        }
        public Task<ProcedureCodeAddOrRemoveResponseModel> RemoveProcedureCode(ProcedureCodeAddOrRemoveRequestModel request)
        {
            return _reqViewDetails.RemoveProcedureCode(request);
        }

    }
}

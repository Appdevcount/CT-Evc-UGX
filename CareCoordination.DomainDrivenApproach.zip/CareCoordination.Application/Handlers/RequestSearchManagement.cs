﻿using CareCoordination.Application.Abstracts.DALInterfaces;
using CareCoordination.Application.Abstracts.HandlerInterfaces;
using CareCoordination.Application.Models;
using CareCoordination.Domain.Entities;
using CareCoordination.Domain.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordination.Application.Handlers
{
    public class RequestSearchManagement : IRequestSearchManagement
    {
        private readonly IRequestSearch _requestSearch;
        private readonly IUserRepository _userRepository;
        public RequestSearchManagement(IRequestSearch requestSearch, IUserRepository userRepository)
        {
            _requestSearch = requestSearch ?? throw new ArgumentNullException(nameof(requestSearch));
            _userRepository = userRepository;
        }

        public async Task<List<RequestSearchResult>> GetRequests(GetCareCoordinationRequestModel request)
        {
            List<RequestSearchResult> response = await _requestSearch.GetRequests(request);
            User user = _userRepository.GetUserDetails(request.UserName!);
            response = response.Select(result =>
            {
                if (result.IsRestrictedMember && ((!user.HasLEA) && (user.Role!.Contains("NCCCord"))))
                {
                    return result.MaskPropertiesExcept<RequestSearchResult>("CareCoordinationEpisodeId");
                }
                return result;
            }).ToList();
            return response;
        }

        public async Task<CareCoordinationDetails> GetRequestDetailsById(string Id)
        {
            return await _requestSearch.GetRequestDetailsById(Id);
        }
    }
}

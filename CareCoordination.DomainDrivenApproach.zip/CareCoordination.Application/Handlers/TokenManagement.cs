﻿using CareCoordination.Api.DTOs;
using CareCoordination.Application.Models;
using CareCoordination.Application.Abstracts.HandlerInterfaces;
using CareCoordination.Application.Abstracts.ServiceInterfaces;

namespace CareCoordination.Application.Handlers
{
    public class TokenManagement: ITokenManagement
    {
        private readonly ITokenService _tokenService;

        public TokenManagement(ITokenService tokenService)
        {
            _tokenService = tokenService;
        }
        
        public string GenerateToken(string userName)
        {
            return _tokenService.GenerateToken(userName);
        }

        public string ValidateToken(string token)
        {
            return _tokenService.ValidateToken(token);
        }

        public TokenDetailsResponse RefreshTokens(string userName,string refreshToken)
        {
            return _tokenService.RefreshTokens(userName, refreshToken);
        }

        public TokenResponse GetUserToken(string userName, string refreshToken)
        {
            return _tokenService.GetUserToken(userName, refreshToken);
        }
    }
}

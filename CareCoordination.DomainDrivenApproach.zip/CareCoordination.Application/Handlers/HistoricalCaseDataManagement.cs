﻿using CareCoordination.Application.Abstracts.HandlerInterfaces;
using CareCoordination.Application.Abstracts.ServiceInterfaces;
using CareCoordination.Application.Models;
using CareCoordination.Domain.Models.HistoricalCaseDataModels;

namespace CareCoordination.Application.Handlers
{
    public class HistoricalCaseDataManagement:IHistoricalCaseDataManagement
    {
        private readonly IHistoricalCaseDataService _historicalCaseDataService;
        public HistoricalCaseDataManagement(IHistoricalCaseDataService historicalCaseDataService)
        {
            _historicalCaseDataService = historicalCaseDataService;
        }

        public async Task<List<CareCoordinationHistoricalRequest>> GetHistoricalCaseData(GetHistoricalCaseDataRequestModel request)
        {
            return await _historicalCaseDataService.GetHistoricalCaseData(request);
        }
    }
}

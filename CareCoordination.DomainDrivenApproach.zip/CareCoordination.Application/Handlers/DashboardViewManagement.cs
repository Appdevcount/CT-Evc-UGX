﻿using AutoMapper;
using CareCoordination.Application.Abstracts.DALInterfaces;
using CareCoordination.Application.Abstracts.HandlerInterfaces;
using CareCoordination.Application.Abstracts.ServiceInterfaces;
using CareCoordination.Application.Models;
using CareCoordination.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordination.Application.Handlers
{
    public class DashboardViewManagement : IDashboardViewManagement
    {
        private readonly IDashboardView _dashboardView;
        private readonly IUserRepository _userRepository;
        private readonly CareCoordination.Domain.Services.MaskingService _maskingService;
        public DashboardViewManagement(IDashboardView dashboardView, IUserRepository userRepository, CareCoordination.Domain.Services.MaskingService maskingService)
        {
            _dashboardView = dashboardView ?? throw new ArgumentNullException(nameof(dashboardView));
            _userRepository = userRepository;
            _maskingService = maskingService ?? throw new ArgumentNullException(nameof(maskingService));
        }
        public async Task<DashboardLoadResponseModel> GetDashboardDetails(DashboardLoadRequestModel request)
        {
            DashboardLoadResponseModel response = await _dashboardView.GetDashboardDetails(request);
            User user = _userRepository.GetUserDetails(request.UserName!);
            response.DashboardDetails = response.DashboardDetails?.Select(result =>
            {
                if (result.IsRestrictedMember && ((!user.HasLEA) && (user.Role!.Contains("NCCCord"))))
                {
                    return _maskingService.MaskPropertiesExcept(result, "CareCoordinationEpisodeId");
                }
                return result;
            }).ToList();
            return response;
        }
        public async Task<DashboardCaseAssignmentResponseModel> DashboardCaseAssignment(DashboardCaseAssignmentRequestModel request)
        {

            return await _dashboardView.DashboardCaseAssignment(request);
        }

        public async Task<AssigneeDetailsResponse> GetAssigneeDetails(string UserName)
        {
            return await _dashboardView.GetAssigneeDetails(UserName);
        }
    }
}

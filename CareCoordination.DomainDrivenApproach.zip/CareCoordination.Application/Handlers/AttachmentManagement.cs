﻿using CareCoordination.Application.Abstracts.DALInterfaces;
using CareCoordination.Application.Abstracts.HandlerInterfaces;
using CareCoordination.Application.Abstracts.ServiceInterfaces;
using CareCoordination.Application.Models;
using CareCoordination.Domain.Constants;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordination.Application.Handlers
{
    public class AttachmentManagement : IAttachmentManagement
    {
        private readonly IFileHandler _fileHandler;
        private readonly IAttachmentDetails _attachmentDetails;
        
        private readonly int _maxFileCount;
        private readonly CareCoordination.Domain.Services.AttachmentDomainService _attachmentDomainService;
        public AttachmentManagement(IFileHandler fileHandler, IAttachmentDetails attachmentDetails, IConfiguration config, CareCoordination.Domain.Services.AttachmentDomainService attachmentDomainService)
        {
            _fileHandler = fileHandler;
            _attachmentDetails = attachmentDetails;
            _maxFileCount = int.TryParse(config.GetSection("Attachment:MaxCount")?.Value, out var val) ? val : 0;
            _attachmentDomainService = attachmentDomainService ?? throw new ArgumentNullException(nameof(attachmentDomainService));
        }

        public async Task<DownloadFilePropertiesModel?> GetFileByObjectId(Int64 ObjectId)
        {
            return await _fileHandler.GetFileByObjectId(ObjectId);
        }

        public List<UploadedFileDataModel>? GetListOfObjects(string EpisodeId)
        {
            return _fileHandler.GetListOfObjects(EpisodeId);
        }
        public  string GetAttachmentCount(string EpisodeId)
        {
            int count = _attachmentDetails.GetAttachmentCount(EpisodeId);
            return _attachmentDomainService.ValidateAttachmentCount(count, _maxFileCount);
        }


        public UploadedFilePropertiesModel? PostToOVEndpoint(UploadedFileModel fileToUpload,HttpContext httpContext)
        {
            var response= _fileHandler.PostToOVEndpoint(fileToUpload, httpContext);
            var fileDalModel= new UploadedFileDalModel();
            fileDalModel.EpisodeId=fileToUpload.EpisodeId;
            fileDalModel.AMSObjectValetId = response?.AMSObjectValetId ?? Guid.Empty;
            fileDalModel.AttachmentName=fileToUpload.Filename;
            fileDalModel.DocumentType=fileToUpload.DocumentType;
            fileDalModel.UserId = fileToUpload.UserId;
            _attachmentDetails.AddAttachmentDetails(fileDalModel);
            return response;
        }
        public async Task <DeleteFilePropertiesModel> DeleteFile(DeleteFilePropertiesViewModel deleteFilePropertiesViewModel)
        {
            if(deleteFilePropertiesViewModel == null || 
                deleteFilePropertiesViewModel.ObjectId == 0 || 
                string.IsNullOrWhiteSpace(deleteFilePropertiesViewModel.EpisodeId))
            {
                throw new ArgumentException("EpisodeId, AMSObjectValetId, ObjectId cannot be NULL");
            }
            return await _fileHandler.DeleteFile(deleteFilePropertiesViewModel);
        }
    }
}

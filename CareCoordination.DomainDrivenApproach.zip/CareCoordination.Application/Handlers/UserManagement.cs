﻿using CareCoordination.Domain.Entities;
using CareCoordination.Application.Abstracts.HandlerInterfaces;
using CareCoordination.Application.Abstracts.ServiceInterfaces;

namespace CareCoordination.Application.Handlers
{
    public class UserManagement: IUserManagement
    {
        private readonly IUserService _userService;

        public UserManagement(IUserService userService)
        {
            _userService = userService;
        }

        public User ValidateUser(string username)
        {
            return _userService.ValidateUser(username);
        }
    }
}

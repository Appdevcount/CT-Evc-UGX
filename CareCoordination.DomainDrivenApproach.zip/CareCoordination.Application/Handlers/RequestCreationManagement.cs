﻿using CareCoordination.Application.Abstracts.DALInterfaces;
using CareCoordination.Application.Abstracts.HandlerInterfaces;
using CareCoordination.Application.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CareCoordination.Domain.Validators;
using CareCoordination.Domain.Models;
using System.Net;

namespace CareCoordination.Application.Handlers
{
    public class RequestCreationManagement : IRequestCreationManagement
    {
        private readonly IRequestCreate _requestCreate;
        public RequestCreationManagement(IRequestCreate requestCreate)
        {
            _requestCreate = requestCreate;
        }
        public Task<CareCoordinationRequestModel> GetNextSequenceNo(CareCoordinationRequestModel request)
        {
            return  _requestCreate.GetNextSequenceNo(request);
        }

        public async Task<CareCoordinationResponseModel> SaveCareCordinationRequest(CareCoordinationRequestModel request)
        {
            
            return  await _requestCreate.SaveCareCordinationRequest(request);
            
        }
    }
}

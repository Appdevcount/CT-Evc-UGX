﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordination.Application.Handlers
{
    [ExcludeFromCodeCoverage]
    public static class ObjectExtensionsManagement
    {
        public static T MaskPropertiesExcept<T>(this T obj, string propertyToExclude) where T : class, new()
        {
            ArgumentNullException.ThrowIfNull(obj);

            T maskedObj = new T();
            PropertyInfo[] properties = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);

            foreach (var prop in properties)
            {
                if (!prop.CanRead || !prop.CanWrite)
                    continue;

                if (string.Equals(prop.Name, propertyToExclude, StringComparison.OrdinalIgnoreCase))
                {
                    prop.SetValue(maskedObj, prop.GetValue(obj));
                }
                else
                {
                    object maskedValue = GetMaskedValue(prop.PropertyType)!;
                    prop.SetValue(maskedObj, maskedValue);
                }
            }

            return maskedObj;
        }

        private static object? GetMaskedValue(Type type)
        {
            if (type == typeof(string))
                return "***";
            if (type == typeof(System.Nullable<int>) || type == typeof(System.Nullable<long>) || type == typeof(System.Nullable<short>))
                return -1;
            if (type == typeof(System.Nullable<DateTime>))
                return DateTime.MinValue;
            if (type == typeof(System.Nullable<bool>))
                return false;
            if (type.IsValueType)
                return Activator.CreateInstance(type);

            return null;
        }
    }


}

﻿using CareCoordination.Application.Abstracts.HandlerInterfaces;
using CareCoordination.Application.Abstracts.ServiceInterfaces;
using CareCoordination.Application.Models.SiteRequestModels;

namespace CareCoordination.Application.Handlers
{
    public class SiteLookupManagement : ISiteLookupManagement
    {
        private readonly ISiteLookupService _siteLookupService;
        public SiteLookupManagement(ISiteLookupService siteLookupService)
        {
            _siteLookupService = siteLookupService;
        }

        public async Task<SiteSearchResponse> GetSiteDetails(GetSiteDetailsRequestModel request)
        {
            return await _siteLookupService.GetSiteDetails(request);
        }

        public string UpsertSiteDetails(UpdateSiteDetailsRequestModel updateSiteDetailsRequestModel)
        {
            return _siteLookupService.UpsertSiteDetails(updateSiteDetailsRequestModel);
        }
    }
}

﻿using CareCoordination.Application.Models;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordination.Application.Abstracts.ServiceInterfaces
{
    public interface IFileHandler
    {
        UploadedFilePropertiesModel? PostToOVEndpoint(UploadedFileModel uploadedFile, HttpContext httpContext);
        List<UploadedFileDataModel>? GetListOfObjects(string EpisodeId);
        Task<DownloadFilePropertiesModel> GetFileByObjectId(Int64 ObjectId);
        Task<DeleteFilePropertiesModel> DeleteFile(DeleteFilePropertiesViewModel deleteFilePropertiesViewModel);
  }
}

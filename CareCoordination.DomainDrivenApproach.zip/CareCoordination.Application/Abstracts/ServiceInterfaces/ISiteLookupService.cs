﻿using CareCoordination.Application.Models.SiteRequestModels;
using CareCoordination.Domain.Models;

namespace CareCoordination.Application.Abstracts.ServiceInterfaces
{
    public interface ISiteLookupService
    {
        Task<SiteSearchResponse> GetSiteDetails(GetSiteDetailsRequestModel request);
        string UpsertSiteDetails(UpdateSiteDetailsRequestModel updateSiteDetailsRequestModel);
        List<SearchResult> ConvertAndSetNetworkTypeForSite(List<GetSitesResponse> sites, ProviderNetworkRulesResponse pnrResponse);
    }
}

﻿using CareCoordination.Api.DTOs;
using CareCoordination.Application.Models;

namespace CareCoordination.Application.Abstracts.ServiceInterfaces
{
    public interface ITokenService
    {
        string GenerateToken(string userName);
        string ValidateToken(string token);
        TokenDetailsResponse RefreshTokens(string userName, string oldRefreshToken);
        TokenResponse GetUserToken(string userName,string refreshToken);
    }
}

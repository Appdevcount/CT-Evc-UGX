﻿using CareCoordination.Application.Models;
using CareCoordination.Domain.Models.HistoricalCaseDataModels;

namespace CareCoordination.Application.Abstracts.ServiceInterfaces
{
    public interface IHistoricalCaseDataService
    {
        Task<List<CareCoordinationHistoricalRequest>> GetHistoricalCaseData(GetHistoricalCaseDataRequestModel request);
    }
}

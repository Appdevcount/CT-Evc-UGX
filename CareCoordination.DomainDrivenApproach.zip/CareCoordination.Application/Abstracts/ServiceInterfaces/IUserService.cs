﻿using CareCoordination.Domain.Entities;

namespace CareCoordination.Application.Abstracts.ServiceInterfaces
{
    public interface IUserService
    {
        User ValidateUser(string username);
    }
}

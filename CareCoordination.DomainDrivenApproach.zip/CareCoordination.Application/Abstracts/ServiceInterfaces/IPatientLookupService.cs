﻿using CareCoordination.Application.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordination.Application.Abstracts.ServiceInterfaces
{
    public interface IPatientLookupService
    {
       Task<List<PatientDetailsResponse>> GetMemberDetails(PatientLookupRequestModel request);
       Task<List<MemberEligibilityResponseModel>> GetMemberEligibility(MemberEligibilityRequestModel request);

        

    }
}

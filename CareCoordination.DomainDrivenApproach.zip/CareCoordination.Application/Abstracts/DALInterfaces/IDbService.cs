﻿using CareCoordination.Application.Models;
using CareCoordination.Domain.Models;
using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordination.Application.Abstracts.DALInterfaces
{
    public interface IDbService
    {
        Task<IEnumerable<T>> QueryAsync<T>(string command, object? parms, CommandType? commandType, IDbTransaction? transaction = null, int? commandTimeout = null);
        Task<T?> QueryFirstOrDefaultAsync<T>(string command, object? parms, CommandType? commandType, IDbTransaction? transaction = null, int? commandTimeout = null);
        T? QueryFirstOrDefault<T>(string command, object? parms, CommandType? commandType, IDbTransaction? transaction = null, int? commandTimeout = null);
        Task<int> ExecuteAsync(string command, object? parms, CommandType? commandType, IDbTransaction? transaction = null, int? commandTimeout = null);
        Task<IGridReaderWrapper> QueryMultipleAsync(string command, object? parms, CommandType? commandType, IDbTransaction? transaction = null, int? commandTimeout = null);
        Task<GetRequestDetailsByIdResultModel?> QueryMultipleAsyncForRequestDetails(string command, object? parms, CommandType? commandType, IDbTransaction? transaction = null, int? commandTimeout = null);
    }
}

﻿using CareCoordination.Domain.Entities;

namespace CareCoordination.Application.Abstracts.DALInterfaces
{
    public interface IPatientRepository
    {
        bool IsRestrictedMember(string PatientId);
    }
}

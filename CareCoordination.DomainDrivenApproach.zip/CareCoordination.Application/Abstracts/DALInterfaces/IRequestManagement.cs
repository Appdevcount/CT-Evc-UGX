﻿using CareCoordination.Application.Models;

namespace CareCoordination.Application.Abstracts.DALInterfaces
{
    public interface IRequestManagement
    {
        Task<CaseManagementResponseModel> UpdateMissedStartOfCareAsync(CaseManagementModel request);
        Task<CaseManagementResponseModel> UpdateCaseStatusAsync(CaseManagementModel request);
        Task<CaseManagementResponseModel> UpdateIsEscalateRequestAsync(CaseManagementModel request);
        Task<CaseManagementResponseModel> UpdateFollowUpDateAsync(CaseManagementModel request);
        Task<CaseManagementResponseModel> AddNoteAsync(CaseManagementModel request);
        Task<CaseManagementResponseModel> UpdateCaseManagerAsync(CaseManagementModel request);
        Task<List<CareCoordinationActivityResponseModel>> GetActivityAsync(string careCoordinationEpisodeId);
    }
}

﻿using CareCoordination.Application.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordination.Application.Abstracts.DALInterfaces
{
    public interface IRequestSearch
    {
        Task<List<RequestSearchResult>> GetRequests(GetCareCoordinationRequestModel request);
        Task<CareCoordinationDetails> GetRequestDetailsById(string Id);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordination.Application.Abstracts.DALInterfaces
{
    public interface IGridReaderWrapper : IDisposable
    {
        Task<IEnumerable<T>> ReadAsync<T>(bool buffered = true);
        Task<T?> ReadSingleOrDefaultAsync<T>();
    }


}

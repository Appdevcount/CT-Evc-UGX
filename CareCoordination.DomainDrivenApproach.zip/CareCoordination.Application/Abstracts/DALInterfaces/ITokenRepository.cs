﻿using CareCoordination.Api.DTOs;

namespace CareCoordination.Application.Abstracts.DALInterfaces
{
    public interface ITokenRepository
    {
        void StoreRefreshToken(string userName, string refreshToken);
        TokenResponse GetUserToken(string userName, string refreshToken);
    }
}
﻿using CareCoordination.Application.Models.SiteRequestModels;
using CareCoordination.Domain.Models;

namespace CareCoordination.Application.Abstracts.DALInterfaces
{
    public interface ISiteRepository
    {
        string UpsertSiteDetails(UpdateSiteDetailsRequestModel updateSiteDetailsRequestModel);

        CaseDetailsEntity GetDetailsForSiteLookupRequestModel(string episodeId);

        Task<List<GetSitesResponse>> GetSites(GetSitesRequestModel request);
    }
}

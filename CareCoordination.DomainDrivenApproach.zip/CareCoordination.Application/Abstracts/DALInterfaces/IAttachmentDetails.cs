﻿using CareCoordination.Application.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordination.Application.Abstracts.DALInterfaces
{
    public interface IAttachmentDetails
    {
        void AddAttachmentDetails(UploadedFileDalModel fileDalModel);
        Task<bool> DeleteAttachmentDetails(DeleteFilePropertiesViewModel deleteFilePropertiesViewModel);
        int GetAttachmentCount(string EpisodeId);
    }
}

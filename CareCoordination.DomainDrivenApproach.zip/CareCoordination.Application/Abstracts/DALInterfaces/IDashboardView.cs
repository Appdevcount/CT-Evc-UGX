﻿using CareCoordination.Application.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordination.Application.Abstracts.DALInterfaces
{
    public interface IDashboardView
    {
        Task<DashboardLoadResponseModel> GetDashboardDetails(DashboardLoadRequestModel request);
        Task<DashboardCaseAssignmentResponseModel> DashboardCaseAssignment(DashboardCaseAssignmentRequestModel request);
        Task<AssigneeDetailsResponse> GetAssigneeDetails(string UserName);
    }
}

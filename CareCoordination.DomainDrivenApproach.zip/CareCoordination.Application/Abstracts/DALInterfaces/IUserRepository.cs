﻿using CareCoordination.Domain.Entities;

namespace CareCoordination.Application.Abstracts.DALInterfaces
{
    public interface IUserRepository
    {
        User GetUserDetails(string userName);
    }
}

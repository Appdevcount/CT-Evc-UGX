﻿using CareCoordination.Application.Models;
using CareCoordination.Domain.Models.HistoricalCaseDataModels;

namespace CareCoordination.Application.Abstracts.HandlerInterfaces
{
    public interface IHistoricalCaseDataManagement
    {
        Task<List<CareCoordinationHistoricalRequest>> GetHistoricalCaseData(GetHistoricalCaseDataRequestModel request);
    }
}

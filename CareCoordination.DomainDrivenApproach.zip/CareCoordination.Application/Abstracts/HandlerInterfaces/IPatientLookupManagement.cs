﻿using CareCoordination.Application.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordination.Application.Abstracts.HandlerInterfaces
{
    public interface IPatientLookupManagement
    {
        
        Task<List<PatientDetailsResponse>> GetMemberDetails(PatientLookupRequestModel request);
        Task<List<MemberEligibilityResponseModel>> GetMemberEligibility(MemberEligibilityRequestModel request);

    }
}

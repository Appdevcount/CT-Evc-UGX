﻿using CareCoordination.Application.Models;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace CareCoordination.Application.Abstracts.HandlerInterfaces
{
    public interface IAttachmentManagement
    {
        UploadedFilePropertiesModel? PostToOVEndpoint(UploadedFileModel fileToUpload, HttpContext httpContext);
        List<UploadedFileDataModel>? GetListOfObjects(string EpisodeId);
        Task<DownloadFilePropertiesModel> GetFileByObjectId(Int64 ObjectId);
        Task<DeleteFilePropertiesModel> DeleteFile (DeleteFilePropertiesViewModel deleteFilePropertiesViewModel);
        string? GetAttachmentCount(string EpisodeId);
    }
}

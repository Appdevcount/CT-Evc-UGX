﻿using CareCoordination.Api.DTOs;
using CareCoordination.Application.Models;

namespace CareCoordination.Application.Abstracts.HandlerInterfaces
{
    public interface ITokenManagement
    {
        string GenerateToken(string userName);
        string ValidateToken(string token);
        TokenDetailsResponse RefreshTokens(string userName,string refreshToken);
        TokenResponse GetUserToken(string userName, string refreshToken);
    }
}

﻿using CareCoordination.Application.Models.SiteRequestModels;

namespace CareCoordination.Application.Abstracts.HandlerInterfaces
{
    public interface ISiteLookupManagement
    {
        Task<SiteSearchResponse> GetSiteDetails(GetSiteDetailsRequestModel request);
        string UpsertSiteDetails(UpdateSiteDetailsRequestModel updateSiteDetailsRequestModel);
    }
}

﻿using CareCoordination.Domain.Entities;

namespace CareCoordination.Application.Abstracts.HandlerInterfaces
{
    public interface IUserManagement
    {
        User ValidateUser(string username);
    }
}

﻿using CareCoordination.Application.Models;

namespace CareCoordination.Application.Abstracts.HandlerInterfaces
{
    public interface ICaseManagement  
    {
        Task<CaseManagementResponseModel> UpdateMissedStartOfCareAsync(CaseManagementModel request);
        Task<CaseManagementResponseModel> UpdateCaseStatusAsync(CaseManagementModel request);
        Task<CaseManagementResponseModel> UpdateIsEscalateRequestAsync(CaseManagementModel request);
        Task<CaseManagementResponseModel> UpdateFollowUpDateAsync(CaseManagementModel request);
        Task<CaseManagementResponseModel> AddNoteAsync(CaseManagementModel request);
        Task<CaseManagementResponseModel> UpdateCaseManagerAsync(CaseManagementModel request);
        Task<List<CareCoordinationActivityResponseModel>> GetActivityAsync(string careCoordinationEpisodeId);
    }
}

﻿using CareCoordination.Application.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordination.Application.Abstracts.HandlerInterfaces
{
    public interface IRequestViewLookupManagement
    {
        Task<ProcedureCodeSearchResponseModel> GetProcedureCodes(ProcedureCodeSearchRequestModel request);

        Task<ProcedureCodeAddOrRemoveResponseModel> AddProcedureCode(ProcedureCodeAddOrRemoveRequestModel request);
        Task<ProcedureCodeAddOrRemoveResponseModel> RemoveProcedureCode(ProcedureCodeAddOrRemoveRequestModel request);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordination.Application.Models
{
    public class AccessTokenItem
    {
        public string? Token_type { get; set; }
        public int Expires_in { get; set; }
        public int Ext_expires_in { get; set; }
        public string? Access_token { get; set; }
        public DateTime ExpiresIn { get; set; }
    }
    public class OAuthTokenFetchHeaders
    {
        public string? AccessTokenURL { get; set; }
        public string? ScopeURL { get; set; }
        public string? GrantType { get; set; }
        public string? ClientID { get; set; }
        public string? ClientSecret { get; set; }
    }
    [ExcludeFromCodeCoverage]
    public static class OAuthParameters
    {

        public const string GrantType = "grant_type";

        public const string Scope = "scope";

        public const string ClientId = "client_id";

        public const string ClientSecret = "client_secret";

        public const string Bearer = "Bearer";
    }
}

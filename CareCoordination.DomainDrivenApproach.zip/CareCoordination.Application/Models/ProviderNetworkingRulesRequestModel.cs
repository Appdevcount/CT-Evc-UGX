﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordination.Application.Models
{
    public class ProviderNetworkingRulesRequestModel
    {
        public required string ReviewType { get; set; }
        public required string LookupType { get; set; }
        
        public required string CompanyID { get; set; }
        public required string GroupNumber { get; set; }
        public required string MemberIPACode { get; set; }
        public string? Modality { get; set; }
        public string? CPTCode { get; set; }
        public string? InsCarrier { get; set; }
        public string? ClientSystem { get; set; }
        public string? InsPlanType { get; set; }
        public string? PatientID { get; set; }
        public string? PatientDOB { get; set; }
        public string? PatientFName { get; set; }
        public string? PatientLName { get; set; }
        public string? PatientState { get; set; }
        public string? MemberNetworkCode { get; set; }
        public string? Workflow {  get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordination.Application.Models
{
    public class ProcedureCodeSearchRequestModel
    {
        public string? ProcedureCodeIDorDesc { get; set; }
        public string? InsCarrier { get; set; }
        public int CompanyID { get; set; }
    }
}


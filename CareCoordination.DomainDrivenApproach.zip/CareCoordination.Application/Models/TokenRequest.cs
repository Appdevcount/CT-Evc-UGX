﻿namespace CareCoordination.Api.DTOs
{
    public class TokenRequest
    {
        public string? Username { get; set; }

    }
}

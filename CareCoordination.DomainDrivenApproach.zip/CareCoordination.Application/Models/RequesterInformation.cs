﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordination.Application.Models
{
    public class RequesterInformation
    {
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? ContactNumber { get; set; }
        public string? ContactExtension { get; set; }
        public string? FaxNumber { get; set; }
        public string? Facility { get; set; }
        public string? Email { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordination.Application.Models
{
    public class AssigneeDetailsResponse
    {
        public List<string>? AssigneeName { get; set; }
        public List<string>? AssigneeUser { get; set; }
        public bool? IsSuccess { get; set; }
        public string? Error { get; set; }
    }
}

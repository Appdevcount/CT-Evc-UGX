﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordination.Application.Models
{
    public class DashboardCaseAssignmentRequestModel
    {
        public List<string>? CareCoordinationEpisodeIDs { get; set; }
        public string? AssigneeName { get; set; }
    }
}

﻿namespace CareCoordination.Application.Models.SiteRequestModels
{
    public class SiteSearchResponse: ResponseBase
    {
        public SiteSearchResponse()
        {
            SearchResults = new List<SearchResult>();
        }
        public IList<SearchResult> SearchResults { get; set; }
    }

    public class ResponseBase
    {
        public ResponseBase()
        {
            Error = new Error();
        }
        public bool IsSuccess { get; set; }
        public string Status { get; set; }
        public Error Error { get; set; }
    }

    public class Error
    {
        public string? Message { get; set; }
        public string? Type { get; set; }
    }

    public class SearchResult
    {
        public string PRVNO { get; set; }
        public string PNAME { get; set; }
        public string PSNAM { get; set; }
        public string APRNO { get; set; }
        public string PADD1 { get; set; }
        public string PADD2 { get; set; }
        public string PCITY { get; set; }
        public string PSTAT { get; set; }
        public string PAZIP { get; set; }
        public string PPHON { get; set; }
        public string PFAX { get; set; }
        public string PTYPE { get; set; }
        public string PTYPEDESC { get; set; }
        public string PTYP2 { get; set; }
        public string MDPRV { get; set; }
        public string PSMID { get; set; }
        public decimal CONTRACT_EFFECTIVE_DATE { get; set; }
        public decimal CONTRACT_TERM_DATE { get; set; }
        public string FFS_VENDOR { get; set; }
        public string GROUP_CARRIER { get; set; }
        public string PLAN_TYPE { get; set; }
        public string PROVIDER_ATTRIBUTE { get; set; }
        public string PPSTRF { get; set; }
        public string PROVIDER_PAR_FLAG { get; set; }
        public double SortOrder { get; set; }
        public int GeoZip { get; set; }
        public string SelectableYN { get; set; }
        public string NPI { get; set; }
        public string TAXID { get; set; }
        public string Entity { get; set; }
        public string MemberIPACode { get; set; }
        public string PUSRDF { get; set; }
        public string LastModifiedBy { get; set; }
        public string LastModifiedDate { get; set; }
        public string NonSiteAlternateID { get; set; }
        public string PPPSTS { get; set; }
        public string PCPSTRF { get; set; }
        public string PCPPLS { get; set; }
        public string SiteNetworkStatus { get; set; }
        public string AssignmentValue { get; set; }
        public int PreferredSort { get; set; }
        public string SiteType { get; set; }
        public string SortToken { get; set; }
        public string providerTypeValue { get; set; }
        public string? NetworkIds { get; set; }
        public string? PhysicianName { get; set; }
    }
}

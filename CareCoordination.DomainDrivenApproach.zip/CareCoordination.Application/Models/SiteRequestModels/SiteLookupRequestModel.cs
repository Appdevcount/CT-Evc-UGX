﻿namespace CareCoordination.Application.Models.SiteRequestModels
{
    public class SiteLookupRequest:RequestBase
    {
        public SiteLookupRequest()
        {
            CaseSummaryDetail = new CaseSummaryDetail();
            PatientDetail = new PatientDetail();
            PhysicianDetail = new PhysicianDetail();
            Site = new Site();
            SiteRule = new SiteRule();
        }

        public CaseSummaryDetail CaseSummaryDetail { get; set; }
        public PatientDetail PatientDetail { get; set; }
        public PhysicianDetail PhysicianDetail { get; set; }
        public Site Site { get; set; }
        public SiteRule SiteRule { get; set; }
        public string LookupType { get; set; }
    }

    public class RequestBase
    {
        public string RequestedBy { get; set; }
    }

    public class CaseSummaryDetail:CaseSummary
    {
        public string CPTCode { get; set; }
        public string CPTModality { get; set; }
        public string Priority { get; set; }
        public bool ExpLocSite { get; set; }
        public string Payor { get; set; }
        public int CaseProviderTypeID { get; set; }
        public string RetroSite { get; set; }
        public string WidgetCPTList { get; set; }
        public string surgeonNPI { get; set; }
    }

    public class CaseSummary
    {
        public string Carrier { get; set; }
        public string PlanCode { get; set; }
        public string CompanyId { get; set; }
        public bool IsRetroCase { get; set; }

    }

    public class PatientDetail:Patient
    {
        public string PatientId { get; set; }
        public string MemberCode { get; set; }
        public string DateOfBirth { get; set; }
        public string State { get; set; }
        public string PatientPlanCode { get; set; }
        public string SSNum { get; set; }
        public string Entity { get; set; }
        public string IOQFacilities { get; set; }
        public string TieredNetworkIndicator { get; set; }
        public string SOCIndicator { get; set; }
        public string SOCCase { get; set; }
    }

    public class Patient
    {
        public string JurisdictionState { get; set; }
        public string MemberIPACode { get; set; }
        public string GroupNumber { get; set; }
        public string LineOfBusiness { get; set; }
        public string PUSRDF { get; set; }
        public string PlanType { get; set; }
    }

    public class PhysicianDetail:Physician
    {
        public string OAOPhysicianId { get; set; }
        public string ZipCode { get; set; }
        public string PhysicianDistance { get; set; }
        public string PhysicianTin { get; set; }
        public string PhysicianLastName { get; set; }
        public string PhysicianFirstName { get; set; }
        public string PhysicianNPI { get; set; }
    }

    public class Physician
    {
        public string State { get; set; }
    }

    public class Site
    {
        public string SiteID { get; set; }
        public string SiteName { get; set; }
        public string SiteCity { get; set; }
        public string NonPar { get; set; }
        public string SiteZip { get; set; }
        public string SiteSearchConstraint { get; set; }
        public string ContractSite { get; set; }
        public string SiteState { get; set; }
        public string Npi { get; set; }
        public string SiteAddress1 { get; set; }
        public string SiteAddress2 { get; set; }
        public string AllEntity { get; set; }
        public string AllIpaCode { get; set; }
        public string CptPrivlegingSiteSearch { get; set; }
        public string UspNetworkIds { get; set; }
        public string Distance { get; set; }
        public string FirstName { get; set; }
        public string UnetTciTableNumber { get; set; }
        public string UspBenefitServiceArea { get; set; }
        public string CallType { get; set; }
        public string SiteLifetimeKey { get; set; }
        public string NetworkIds { get; set; }
    }
    public class SiteRule
    {
        public string? Steerage { get; set; }
        public string? IncludeNetworkIds { get; set; }
        public string? ExcludeNetworkIds { get; set; }
        public string? MemberIPAs { get; set; }
    }
}

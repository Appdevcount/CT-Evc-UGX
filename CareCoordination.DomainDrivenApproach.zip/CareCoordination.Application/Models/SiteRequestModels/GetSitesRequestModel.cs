﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordination.Application.Models.SiteRequestModels
{
    [ExcludeFromCodeCoverage]
    public class GetSitesRequestModel
    {
        public string? MbrZip { get; set; }
        public string? Carrier { get; set; }
        public string? CPTCode { get; set; }
        public string? MemberIPA { get; set; }
        public string? PatientEntity { get; set; }
        public string? MemberPlanType { get; set; }
        public string? SiteID { get; set; }
        public string? SiteName { get; set; }
        public string? SiteCity { get; set; }
        public string? SiteZip { get; set; }
        public string? AltID { get; set; }
        public string? PatientPlanCode { get; set; }
        public string? SiteState { get; set; }
        public int CaseProviderTypeID { get; set; }
        public string? AllEntity { get; set; }
        public string? AllIPACode { get; set; }
        public string? PatPUSRDF { get; set; }
        public string? ssnum { get; set; }
        public string? NetworkId { get; set; }
    }
}

﻿namespace CareCoordination.Application.Models.SiteRequestModels
{
    public class UpdateSiteDetailsRequestModel
    {
        public string? CareCoordinationEpisodeId { get; set; }
        public string? OAOSiteID { get; set; }
        public string? NonParSiteID { get; set; }
        public string? OldSiteID { get; set; }
        public string? SiteName { get; set; }
        public string? SiteAddr1 { get; set; }
        public string? SiteAddr2 { get; set; }
        public string? SiteCity { get; set; }
        public string? SiteState { get; set; }
        public string? SiteZip { get; set; }
        public string? SitePhone { get; set; }
        public string? SiteFax { get; set; }
        public string? SiteSpec1 { get; set; }
        public string? SiteSpec2 { get; set; }
        public string? SiteSpecDesc1 { get; set; }
        public string? SiteSpecDesc2 { get; set; }
        public string? SiteAlternateID { get; set; }
        public string? SiteNYMIPar { get; set; }
        public decimal? SteeragePosition { get; set; }
        public string? NPI { get; set; }
        public decimal SiteIdent { get; set; }
        public decimal SelectionMethodID { get; set; }
        public string? Email { get; set; }
        public string? PUSRDF { get; set; }
        public string? SiteIPA { get; set; }
        public string? SiteEntity { get; set; }
        public string? SiteType { get; set; }
        public string? UserId { get; set; }
        public string? PhysicianName { get; set; }
    }
}

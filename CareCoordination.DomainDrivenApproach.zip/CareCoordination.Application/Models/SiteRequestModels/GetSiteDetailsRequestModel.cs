﻿namespace CareCoordination.Application.Models.SiteRequestModels
{
    public class GetSiteDetailsRequestModel
    {
        public string? ProviderCity { get; set; }
        public string? ProviderEligibilityType { get; set; }
        public string? ProviderNPI { get; set; }
        public string? ProviderName { get; set; }
        public string? ProviderOAOID { get; set; }
        public string? ProviderTIN { get; set; }
        public string? ProviderZip { get; set; }
        public string? RequestId { get; set; }
        public string? MemberIPA { get; set; }
    }
}

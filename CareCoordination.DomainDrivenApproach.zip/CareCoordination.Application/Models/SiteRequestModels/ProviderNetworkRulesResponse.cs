﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace CareCoordination.Application.Models.SiteRequestModels
{
    public class ProviderNetworkRulesResponse
    {
        [JsonProperty(nameof(LookupType))]
        public string? LookupType { get; set; }
        [JsonProperty("IPA.Included")]
        public string? IPAIncluded { get; set; }
        [JsonProperty("HCNTRP.PPSTRF.Included")]
        public string? HCNTRPPPSTRFIncluded { get; set; }
        [JsonProperty("HPSAIP.PRVGRN.Excluded")]
        public string? HPSAIPPRVGRNExcluded { get; set; }
        [JsonProperty("HPSAIP.PRVGRN.Included")]
        public string? HPSAIPPRVGRNIncluded { get; set; }
        [JsonProperty("Site.IPA.Included")]
        public string? SiteIPAIncluded { get; set; }
        [JsonProperty("Site.HCNTRP.PPSTRF.Included")]
        public string? SiteHCNTRPPPSTRFIncluded { get;set; }
        [JsonProperty("Site.HPSAIP.PRVGRN.Excluded")]
        public string? SiteHPSAIPPRVGRNExcluded {  get; set; }
        [JsonProperty("Site.HPSAIP.PRVGRN.Included")]
        public string? SiteHPSAIPPRVGRNIncluded { get; set; }
        [JsonProperty("Physician.IPA.Included")]
        public string? PhysicianIPAIncluded {  get; set; }
        [JsonProperty("Physician.HCNTRP.PPSTRF.Included")]
        public string? PhysicianHCNTRPPPSTRFIncluded { get; set; }
        [JsonProperty("Physician.HPSAIP.PRVGRN.Excluded")]
        public string? PhysicianHPSAIPPRVGRNExcluded { get; set; }
        [JsonProperty("Physician.HPSAIP.PRVGRN.Included")]
        public string? PhysicianHPSAIPPRVGRNIncluded { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CareCoordination.Domain.Models;

namespace CareCoordination.Application.Models
{
    [ExcludeFromCodeCoverage]
    public class QueryResultModel  
    {
        public CareCoordinationRequestEntity? RequestEntity { get; set; }
    }
}

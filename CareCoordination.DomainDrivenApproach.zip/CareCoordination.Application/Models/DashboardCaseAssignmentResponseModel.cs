﻿namespace CareCoordination.Application.Models
{
    public class DashboardCaseAssignmentResponseModel
    {
        public bool? IsSuccess { get; set; }
        public string? Error { get; set; }
    }
}

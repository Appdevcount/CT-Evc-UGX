﻿namespace CareCoordination.Application.Models
{
    public class MemberEligibilityResponseModel
    {
        public string? CompanyID { get; set; }

        public string? InsCarrier { get; set; }

        public string? PlanTypeEligible { get; set; }

        public required DateTime DOS { get; set; }

        public string? CPTCode { get; set; }

        public string? CaseBuild { get; set; }

        public string? MemberInScope { get; set; }
        public string? CPLNTP { get; set; }

    }
}

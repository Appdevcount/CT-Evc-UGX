﻿
namespace CareCoordination.Application.Models
{
    public class MemberEligibilityRequestModel
    {
        public required MemberEligibility Qualifiers { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordination.Application.Models
{
    public class CareCoordinationActivityResponseModel
    {
        public string? CareCoordinationEpisodeId { get; set; }
        public DateTime? CareCoordinationEpisodeDate { get; set; }
        public int Id { get; set; }
        public string? Comments { get; set; }
        public string? UserId { get; set; }
        public string? RoleType { get; set; }
        public string? CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
    }
}

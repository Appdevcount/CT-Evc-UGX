﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordination.Application.Models
{
    public class CptCodeModel
    {
        public int? Id { get; set; }
        public string? CptCode { get; set; }
        public string? SimplifiedDescription { get; set; }
        public string? CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public bool? PrivateDutyNurse { get; set; }
        public bool? CustomNeed { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordination.Application.Models
{
    [ExcludeFromCodeCoverage]
    public class DashboardLoadResponseModel
    {
        public List<DashboardDetail>? DashboardDetails { get; set; }
        public DashboardCounts? DashboardCounts { get; set; }
        public bool IsSuccess { get; set; }
        public string? Error { get; set; }
        public int TotalRecords { get; set; }
        public bool IsSupervisor { get; set; }
    }
    [ExcludeFromCodeCoverage]

    public class DashboardDetail
        { 
        public string? CareCoordinationEpisodeID { get; set; }
        public string? PatientID { get; set; }
        public string? PatientName { get; set; }
        public DateTime PatientDOB { get; set; }
        public DateTime CreatedDateTime { get; set; }
        public string? CreatedBy { get; set; }
        public DateTime DateOfClosing { get; set; }
        public string? CaseStatus { get; set; }
        public string? AssignmentStatus { get; set; }
        public string? SubServiceType { get; set; }
        public string? AssigneeName { get; set; }
        public string? EscalationStatus { get; set; }
        public string? AssigneeEmailId { get; set; }
        public string? Reason { get; set; }
        public string? HealthPlan { get; set; }
        public string? FollowupNotes { get; set; }
        public DateTime FollowupDate { get; set; }
        public string? PatientCity { get; set; }
        public string? PatientState { get; set; }
        public bool IsQuickCreate { get; set; }
        public bool MissedStartOfCare { get; set; }
        public string? AssignedTo { get; set; }
        public bool IsRestrictedMember { get; set; }
        public string? ServiceType { get; set; }
        }
    [ExcludeFromCodeCoverage]
    public class DashboardCounts
    {
        public int CasesOpen { get; set; }
        public int IsEscalated { get; set; }
        public int IsNotEscalated { get; set; }
        public int MissedStartOfCare { get; set; }
        public int Assigned { get; set; }
        public int AssigneeId { get; set; }
        public int HomeHealth { get; set; }
        public int HomeInfusionTherapy { get; set; }        
        public int DME { get; set; }
        public int Sleep { get; set; }
         public int OnP {get; set;}
        public int MemberEscalation { get; set; }
        public int MissedServices { get; set; }
        public int FindServiceProvider { get; set; }
        public int OtherReason { get; set; }
        public int NoneReason { get; set; }
        public int Closed {  get; set; }
        public int Unassigned { get; set; }


    }
}

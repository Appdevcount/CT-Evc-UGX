﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordination.Application.Models
{
    public class CareCoordinationDetails
    {
        public string? CareCoordinationEpisodeId { get; set; }
        public DateTime? CareCoordinationEpisodeDate { get; set; }
        public string? CaseStatus { get; set; }
        public string? HealthPlan { get; set; }
        public int? CompanyId { get; set; }
        public string? Program { get; set; }
        public string? Reason { get; set; }
        public DateTime? DateOfService { get; set; }
        public DateTime? DateOfClosing { get; set; }
        public bool? IsEscalated { get; set; }
        public string? CreatedBy { get; set; }
        public DateTime? CreateDate { get; set; }
        public bool? MissedStartOfCare { get; set; }
        public string? MissedStartOfCareReason { get; set; }
        public string? AssigneeEmailId { get; set; }
        public string? AssigneeName { get; set; }
        public DateTime? AssigneeDate { get; set; }
        public PatientDetails? PatientDetails { get; set; }
        public RequesterInformation? Requester { get; set; }
        public CaseManager? CaseManager { get; set; }
        public Site? Site { get; set; }
        public FollowUpDetails? FollowUp { get; set; }
        public List<Note>? Notes { get; set; }
        public List<Attachment>? Attachments { get; set; }
        public List<CptCodeModel>? CPTCodes { get; set; }
        public List<CareCoordinationActivity>? Activity { get; set; }
        public bool? StaffedRequest { get; set; }
        public string? SubServiceType { get; set; }
        public string? OON { get; set; }
    }  
}

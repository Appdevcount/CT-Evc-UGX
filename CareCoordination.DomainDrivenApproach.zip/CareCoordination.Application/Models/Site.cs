﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordination.Application.Models
{
    public class Site
    {
        public string? OAOSiteID { get; set; }
        public string? NonParSiteID { get; set; }
        public string? OldSiteID { get; set; }
        public string? Name { get; set; }
        public string? Addr1 { get; set; }
        public string? Addr2 { get; set; }
        public string? City { get; set; }
        public string? State { get; set; }
        public string? Zip { get; set; }
        public string? Phone { get; set; }
        public string? Fax { get; set; }
        public string? Spec1 { get; set; }
        public string? Spec2 { get; set; }
        public string? SpecDescription1 { get; set; }
        public string? SpecDescription2 { get; set; }
        public string? AlternateID { get; set; }
        public string? NYMIPar { get; set; }
        public string? SteeragePosition { get; set; }
        public string? NPI { get; set; }
        public string? SiteIdent { get; set; }
        public string? SelectionMethodID { get; set; }
        public string? Email { get; set; }
        public string? PUSRDF { get; set; }
        public string? IPA { get; set; }
        public string? Entity { get; set; }
        public string? SiteType { get; set; }
        public string? PhysicianName { get; set; }
    }
}

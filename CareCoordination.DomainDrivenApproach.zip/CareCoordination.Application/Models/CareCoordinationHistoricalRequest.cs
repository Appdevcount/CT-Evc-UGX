﻿namespace CareCoordination.Application.Models;

public class CareCoordinationHistoricalRequest
{
    public string? RequestForCareCoordinationKey { get; set; }
    public string? CareCoordinationId { get; set; }
    public RequestedServices? RequestedServices { get; set; }
    public MemberPolicyModel? MemberPolicy { get; set; }
    public DateTime RequestedServiceDate { get; set; }
    public List<Provider>? Providers { get; set; }
    public List<ProcedureCode>? ProcedureCodes { get; set; }
    public Requester? Requester { get; set; }
    public ReasonDetails? ReasonDetails { get; set; }
    public Insurer? Insurer { get; set; }
    public StatusDetails? StatusDetails { get; set; }
    public DateTime? DateOfClosing { get; set; }
}

public class RequestedServices
{
    public string? Program { get; set; }
    public string? ServicePlaceCode { get; set; }
    public string? ServicePlace { get; set; }
    public string? ServicePlaceFullName { get; set; }
    public List<ServiceType>? ServiceTypes { get; set; }
}

public class ServiceType
{
    public string? ServiceTypeId { get; set; }
    public string? ServiceTypeName { get; set; }
}

public class MemberPolicyModel
{
    public string? InsuranceCarrierKey { get; set; }
    public string? MemberPolicyKey { get; set; }
    public string? MemberId { get; set; }
    public string? Gender { get; set; }
    public string? FirstName { get; set; }
    public string? MiddleName { get; set; }
    public string? LastName { get; set; }
    public DateTime? DateOfBirth { get; set; }
    public string? AddressLine1 { get; set; }
    public string? AddressLine2 { get; set; }
    public string? City { get; set; }
    public string? County { get; set; }
    public string? StateCode { get; set; }
    public string? ZipCode { get; set; }
    public string? GroupNumber { get; set; }
    public string? PrimaryLanguage { get; set; }
    public bool IsMemberQuickCreate { get; set; }
    public bool IsMemberEligible { get; set; }
}

public class Provider
{
    public string? Fax { get; set; }
    public string? PhoneExtension { get; set; }
    public string? Phone { get; set; }
    public string? Zip { get; set; }
    public string? StateCode { get; set; }
    public string? County { get; set; }
    public string? City { get; set; }
    public string? Address2 { get; set; }
    public string? Address1 { get; set; }
    public string? AddressKey { get; set; }
    public string? TIN { get; set; }
    public string? NPI { get; set; }
    public string? LastName { get; set; }
    public string? FirstName { get; set; }
    public string? OrganizationName { get; set; }
    public string? ProviderType { get; set; }
    public string? ProviderTypeIdentifier { get; set; }
    public string? ProviderContractKey { get; set; }
    public string? SourceDataProviderKey { get; set; }
    public bool IsParticipatingProvider { get; set; }
    public bool IsQuickCreate { get; set; }
    public string? ProviderNetworkType { get; set; }
    public string? QuickCreateSource { get; set; }
    public string? SourceNotes { get; set; }
}

public class ProcedureCode
{
    public string? Name { get; set; }
    public string? SimplifiedDescription { get; set; }
    public string? Units { get; set; }
}

public class Requester
{
    public string? FirstName { get; set; }
    public string? LastName { get; set; }
    public string? PhoneNumber { get; set; }
    public string? Extension { get; set; }
    public string? Fax { get; set; }
    public string? Email { get; set; }
    public string? Facility { get; set; }
}

public class ReasonDetails
{
    public string? Reason { get; set; }
    public string? Notes { get; set; }
    public DateTime? StartOfCareDate { get; set; }
}

public class Insurer
{
    public string? InsuranceCarrierName { get; set; }
    public string? InsuranceCarrierDisplayName { get; set; }
}

public class StatusDetails
{
    public string? Status { get; set; }
    public string? Notes { get; set; }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordination.Application.Models
{
    public class MemberEligibility
    {
        public required string ReviewType { get; set; }
        public required string Workflow { get; set; }
        public required string PatientID { get; set; }
        public required string PatientMemberCode { get; set; }
        public required DateTime DOS { get; set; }
        public required string InsCarrier { get; set; }
        public required string PatientDOB { get; set; }
        public string? Modality { get; set; }
        public string? CompanyID { get; set; }
        public string? DMEBenefit { get; set; }
        public string? CPLNTP { get; set; }
        public string? InsPlanType { get; set; }
        public string? GroupNumber { get; set; }
        public string? PatientState { get; set; }
        public string? JurisdictionState { get; set; }
        public string? CPTCode { get; set; }
        public string? Environment { get; set; }
        public required string ClientSystem { get; set; }
    }
}

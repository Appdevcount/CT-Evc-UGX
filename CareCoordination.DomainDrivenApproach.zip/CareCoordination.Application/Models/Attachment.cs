﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordination.Application.Models
{
    public class Attachment
    {
        public int Id { get; set; }
        public DateTime? ReceivedDate { get; set; }
        public string? AttachmentName { get; set; }
        public string? AMSObjectValetId { get; set; }
        public string? DocumentType { get; set; }
        public string? CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
    }
}

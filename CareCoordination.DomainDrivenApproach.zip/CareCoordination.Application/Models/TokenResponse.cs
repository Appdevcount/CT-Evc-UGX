﻿namespace CareCoordination.Api.DTOs
{
    public class TokenResponse
    {
        public int? CareCoordinationTokenId { get; set; }
        public string? UserName { get; set; }
        public string? RefreshToken { get; set; }
        public DateTime? Expiration { get; set; }
        public DateTime? CreatedDate { get; set; }
    }
}

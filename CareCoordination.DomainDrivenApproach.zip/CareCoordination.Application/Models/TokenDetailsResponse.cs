﻿namespace CareCoordination.Application.Models
{
    public class TokenDetailsResponse
    {
        public string? RefreshToken { get; set; }
        public string? AccessToken { get; set; }
    }
}

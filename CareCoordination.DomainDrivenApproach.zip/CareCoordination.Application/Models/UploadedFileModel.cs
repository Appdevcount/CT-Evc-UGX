﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordination.Application.Models
{
    public class UploadedFileModel
    {
        public string? EpisodeId { get; set; }
        public IFormFile? file { get; set; }
        public string? Filename { get; set; }
        public string? DocumentType { get; set; }
        public string? UserName { get; set; }
        public string? UserId { get; set; }
    }
    public class UploadedFileDataModel
    {
        public string? Id { get; set; }
        public string? RequestId { get; set; }
        public string? EpisodeId { get; set; }

        public int ObjectId { get; set; }
        public string? Filename { get; set; }
        public string? Description { get; set; }
        public string? CreatedDate { get; set; }
        public string? ObjectClassKey { get; set; }
        public string? ObjectClassDescription { get; set; }
        public string? CreatedBy { get; set; }
        public string? Policy { get; set; }
        public int ObjectSize { get; set; }

    }
    public class DownloadFilePropertiesModel
    {
        public string? FileName { get; set; }
        public string? ContentType { get; set; }
        public Stream? FileStreamContent { get; set; }
    }
    public class UploadedFilePropertiesModel
    {
        public Guid AMSObjectValetId { get; set; }
    }
    public class UploadedFileDalModel
    {
        public string? EpisodeId { get; set; }
        public Guid AMSObjectValetId { get; set; }
        public string? DocumentType { get; set; }
        public string? AttachmentName { get; set; }      
        public string? UserId { get; set; }

    }
    public class DeleteFilePropertiesModel
    {
        public bool? IsDeleted { get; set; }
        public string? Error { get; set; }
    }
    public class DeleteFilePropertiesViewModel
    {
        public string? EpisodeId { get; set; }
        public long ObjectId { get; set; }
    }
}

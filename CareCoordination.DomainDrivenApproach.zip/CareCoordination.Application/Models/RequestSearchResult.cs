﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordination.Application.Models
{
    public class RequestSearchResult
    {
        public string? CareCoordinationEpisodeId { get; set; }
        public DateTime? CareCoordinationEpisodeDate { get; set; }
        public string? CaseStatus { get; set; }
        public string? HealthPlan { get; set; }
        public int? CompanyId { get; set; }
        public string? Program { get; set; }
        public string? Reason { get; set; }
        public DateTime? DateOfService { get; set; }
        public DateTime? DateOfClosing { get; set; }
        public bool? IsEscalated { get; set; }
        public string? CreatedBy { get; set; }
        public DateTime? CreateDate { get; set; }
        public Patient? PatientDetails { get; set; }
        public bool? StaffedRequest { get; set; }
        public string? SubServiceType { get; set; }
        public bool IsRestrictedMember { get; set; }
    }

    public class Patient
    {
        public string? ID { get; set; }
        public string? Name { get; set; }
        public DateTime? DateOfBirth { get; set; }
    }
}

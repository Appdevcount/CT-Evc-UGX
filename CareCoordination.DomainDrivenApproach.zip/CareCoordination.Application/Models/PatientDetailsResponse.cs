﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordination.Application.Models
{
    [ExcludeFromCodeCoverage]
    public class MemberLookupBaseModel
    {
        public string? LookUpStatus { get; set; }
        public string? ReturnText { get; set; }
        public string? ReturnCode { get; set; }
    }
    [ExcludeFromCodeCoverage]
    public class PatientDetailsResponse
    {
        public PatientResponseRecord? Response { get; set; }
        public string? ErrorMsg { get; set; }
        public bool IsSuccess { get; set; } = true;
    }
    [ExcludeFromCodeCoverage]
    public class PatientResponseRecord : MemberLookupBaseModel
    {
        public PatientResponseRecord()
        {
            Patient = new Patients();
            Benefits = new List<Benefit>();
        }
        
        public Patients Patient { get; set; }
        public string? MultipleDependents { get; set; }
        public string? SubscriberLastName { get; set; }
        public string? SubscriberFirstName { get; set; }
        public string? RelationshipCode { get; set; }
        public string? AAAReturnCode { get; set; }
        public IList<Benefit> Benefits { get; set; }
        public string? Message { get; set; }
        public bool ValidInfo { get; set; }
        public string? Language { get; set; }
        public string? CategoryNumber { get; set; }
        public string? SecondaryId { get; set; }
        public string? Erisa { get; set; }
        public string? CompanyId { get; set; }
        public string? HealthPlan { get; set; }
        public string? ExternalMemberID { get; set; }
        public string? Effective { get; set; }
        public string? Indicator { get; set; }
        public string? OONBenefits { get; set; }
        public string? SiteOfCareIndicator { get; set; }
        public string? Policy { get; set; }
        public string? LookupType { get; set; }
        public string? AssigningOrganization { get; set; }
        public string? FundingType { get; set; }
        public string? ChemoIndicator { get; set; }
        public string? IsLegacyID { get; set; }
        public string? ProviderPlanNetworkIndicator { get; set; }
        public string? GroupInUnconfirmedTable { get; set; }
        public string? CaseStatus { get; set; }
        public string? UsesMemberCode { get; set; }
        public string? NewInsCarrier { get; set; }
        public string? RealCarrier { get; set; }
        public string? MarketCode { get; set; }
        public string? ProductCode { get; set; }
        public string? RetroIndicator { get; set; }
        public string? MedNecIndicator { get; set; }
        public string? PatientDDPIndicator { get; set; }
        public string? MemberContract { get; set; }
        public string? ManualAdd { get; set; }
        public string? ValidPatient { get; set; }
        public string? PatientIDNoMemCode { get; set; }
        public string? PrimaryHealthPlanID { get; set; }
        public string? FraudFlag { get; set; }
        public string? SecondaryHealthPlanID { get; set; }
        public string? PhoneNumber { get; set; }
        public string? FaxNumber { get; set; }
        public int CarrierID { get; set; }
        public string? DefaultEntity { get; set; }
        public int LenMemberCode { get; set; }
        public string? InactivePolicyMessage { get; set; }
        public string? PatientPlanNumber { get; set; }
        public string? IsHorizonHasOONBenefit { get; set; }
        public string? IsHorizonHasITSBenefit { get; set; }
        public string? IsCignaHasOONforChemo { get; set; }
        public string? IsInscope { get; set; }
        public string? NetworkPatientID { get; set; }
        public string? MBI { get; set; }
        public string? HContract { get; set; }
        public string? PBP { get; set; }
    }
    [ExcludeFromCodeCoverage]
    public class Patients
    {
        public string? PatientID { get; set; }
        public string? LastName { get; set; }
        public string? FirstName { get; set; }
        public string? PatientName { get; set; }
        public string? PatientAddr1 { get; set; }
        public string? PatientAddr2 { get; set; }
        public string? PatientCity { get; set; }
        public string? PatientState { get; set; }
        public string? PatientZip { get; set; }
        public string? PatientGender { get; set; }
        public string? PatientPhone { get; set; }
        public string? PatientDOB { get; set; }
        public string? PatientEffDate { get; set; }
        public string? PatientTermDate { get; set; }
        public string? PatientGroupNumber { get; set; }
        public string? PatientGroupDescription { get; set; }
        public string? OAOSubNo { get; set; }
        public string? OAOPerNo { get; set; }
        public string? Entity { get; set; }
        public string? PlanCode { get; set; }
        public string? PlanType { get; set; }
        public string? JurisdictionState { get; set; }
        public string? LineOfBusiness { get; set; }
        public string? IPACode { get; set; }
        public string? PatientPUSRDF { get; set; }
        public string? PatientPlanNetworkIndicator { get; set; }
        public string? ExtID { get; set; }
        public string? PatientORGCD { get; set; }
        public string? CellPhone { get; set; }
        public string? DefaultPlanCode { get; set; }
        public string? MemberCode { get; set; }
        public string? Ssnum { get; set; }
        public string? CPECFL { get; set; }
        public string? CPECFD { get; set; }
        public string? CPBPID { get; set; }
        public string? TIT19 { get; set; }
        public string? EMAIL { get; set; }
        public string? Category { get; set; }
        public string? CPEFDT { get; set; }
        public bool IsRestrictedMember { get; set; }
    }
    [ExcludeFromCodeCoverage]
    public class Benefit
    {
        public Benefit()
        {
            ServiceTypeCodes = new List<string>();
            Messages = new List<string>();
            RelatedEntities = new List<RelatedEntity>();
        }
   
        public string? InformationCode { get; set; } 
        public string? InsuranceTypeCode { get; set; }  
        public string? PlanCoverageDescription { get; set; }
        public string? ProductCode { get; set; } 
        public string? MarketCode { get; set; } 
        public string? AuthorizationIndicator { get; set; }
        public string? DateLastUpdate { get; set; }
        public IList<string> ServiceTypeCodes { get; set; } 
        public IList<string> Messages { get; set; }
        public IList<RelatedEntity> RelatedEntities { get; set; }
        public string? CoverageLevelCode { get; set; } 
        public string? PlanNetworkIndicator { get; set; } 
        public string? MonetaryAmount { get; set; }
        public string? Percent { get; set; }
        public string? TimePeriodQualifier { get; set; }
        public string? FacilityTypeCode { get; set; }
    }
    [ExcludeFromCodeCoverage]
    public class RelatedEntity
    {
        public string? EntityCode { get; set; }
        public string? EntityType { get; set; }
        public string? LastName { get; set; }
        public string? PayorID { get; set; }
        public string? Address1 { get; set; }
        public string? City { get; set; }
        public string? State { get; set; }
        public string? Zip { get; set; }
        public string? URL { get; set; }
    }

}

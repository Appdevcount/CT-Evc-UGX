﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordination.Application.Models
{
    public class ProcedureCodeSearchResponseModel
    {
        public List<ProcedureCodeDetails>? ProcedureCodeDetails { get; set; }
        public bool IsSuccess { get; set; }
        public string? Error { get; set; }

    }
    
}

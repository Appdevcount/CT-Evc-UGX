﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordination.Application.Models
{
    public class PatientDetails
    {
        public string? PatientID { get; set; }
        public string? MemberCode { get; set; }
        public string? Name { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public string? GroupNumber { get; set; }
        public string? PlanType { get; set; }
        public string? LineOfBusiness { get; set; }
        public string? Language { get; set; }
        public string? PatientPlanType { get; set; }
        public string? Entity { get; set; }
        public string? Category { get; set; }
        public string? IPA { get; set; }
        public long? PatientIdent { get; set; }
        public string? Email { get; set; }
        public string? CellPhone { get; set; }
        public string? JurisdictionState { get; set; }
        public string? TIT19 { get; set; }
        public string? Calculated_PatientID_PatientMemberCode_GroupNumber { get; set; }
        public int? CaseFactor { get; set; }
        public string? PUSRDF { get; set; }
        public string? FundType { get; set; }
        public string? ERISA { get; set; }
        public string? EXTID { get; set; }
        public DateTime? StartDate { get; set; }
        public bool? MemberQuickCreate { get; set; }
        public string? PatientSex { get; set; }
        public string? PatientAddr1 { get; set; }
        public string? PatientAddr2 { get; set; }
        public string? PatientState { get; set; }
        public string? PatientCity { get; set; }
        public string? PatientZip { get; set; }
    }
}

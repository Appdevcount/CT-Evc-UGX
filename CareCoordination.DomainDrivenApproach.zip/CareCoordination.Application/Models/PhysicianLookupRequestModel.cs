﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordination.Application.Models
{
    public class PhysicianLookupRequestModel
    {
        public string? PhySrch { get; set; } 
        public string? NonParFlag { get; set; } 
        public string? FullCarrier { get; set; }
        public string? CompanyId { get; set; }
        public string? PatEntity { get; set; }
        public string? PatPlanType { get; set; }
        public string? PhysID { get; set; }
        public string? PhysName { get; set; }
        public string? PhysZip { get; set; }
        public string? PhysCity { get; set; }
        public string? IPACode { get; set; }
        public string? AltID { get; set; }
        public string? CSNSearch { get; set; }
        public string? InsertingApplication { get; set; }
        public string? UserName { get; set; }
        public string? GroupNumber { get; set; }
        public DateTime TS { get; set; }
        public bool IsRequestingProvider { get; set; }
        public string? Steerage { get; set; }
        public string? ExcludedNetworkIDs { get; set; }
        public string? IncludedNetworkIDs { get; set; }
        public string? MemberIPAs { get; set; }
    }
}

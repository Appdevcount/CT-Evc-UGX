﻿namespace CareCoordination.Api.DTOs
{
    public class RefreshTokenRequest
    {
        public string? RefreshToken { get; set; }
        public string? UserName { get; set; }
    }
}

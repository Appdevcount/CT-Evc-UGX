﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordination.Application.Models
{
    public class FollowUpDetails
    {
        public DateTime? FollowUpDate { get; set; }
        public string? Notes { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordination.Application.Models
{
    public class ProcedureCodeAddOrRemoveRequestModel
    {
        public string? EpisodeID { get; set; }
        public string? ProcedureCode { get; set; }
        public string? ProcedureDesc { get; set; }
        public string? UserId { get; set; }
        public bool? PrivateDutyNurse { get; set; }
        public bool? CustomNeed { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordination.Application.Models
{
    public class GetHistoricalCaseDataRequestModel
    {
        public string? requestId { get; set; }
        public string? patientId { get; set; }
        public string? firstName { get; set; }
        public string? lastName { get; set; }
        public string? dateOfBirth { get; set; }
    }
}

﻿using AutoMapper;
using CareCoordination.Application.Models;
using CareCoordination.Domain.Models;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Dapper;
using CareCoordination.Application.Abstracts.DALInterfaces;
using Azure.Core;
using CareCoordination.DAL.Utils;

namespace CareCoordination.DAL.Implementation
{
    public class RequestCreation : IRequestCreate
    {
        private readonly IDbService _dbservice;
        public RequestCreation(IDbService dbService)
        {
            _dbservice = dbService;
        }

        public async Task<CareCoordinationRequestModel> GetNextSequenceNo(CareCoordinationRequestModel request)
        {
            var spResult = await _dbservice.QueryFirstOrDefaultAsync<int>("[CC_GetNextEpisodeID]", null, commandType: CommandType.StoredProcedure);
            request.EpisodeId = string.Concat("CCR", spResult.ToString("D9"));
            return request;
        }

        public async Task<CareCoordinationResponseModel> SaveCareCordinationRequest(CareCoordinationRequestModel request)
        {
            CareCoordinationResponseModel response = new CareCoordinationResponseModel();
            try
            {
                var parameters = SaveCareCoordinationRequestParameterBuilder.BuildSaveCareCordinationRequestParameters(request);
                await _dbservice.ExecuteAsync("CreateCCRequest", parameters, commandType: CommandType.StoredProcedure);
                response.EpisodeId = request.EpisodeId;
                response.IsSuccess = true;
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Error = ex.Message;
                throw;
            }
            return response;
        }
    }
}

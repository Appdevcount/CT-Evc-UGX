﻿using CareCoordination.Application.Models;
using System.Data;
using Dapper;
using CareCoordination.Application.Abstracts.DALInterfaces;
using CareCoordination.DAL.Utils;
using System.Linq;

namespace CareCoordination.DAL.Implementation
{
    public class RequestManagement : IRequestManagement
    {
        private readonly IDbService _dbservice;
        public RequestManagement(IDbService dbService)
        {
            _dbservice = dbService;
        }
        public async Task<CaseManagementResponseModel> UpdateMissedStartOfCareAsync(CaseManagementModel request)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@RequestId", request.RequestId);
            parameters.Add("@MissedStartOfCare", request.MissedStartOfCare);
            parameters.Add("@MissedStartOfCareReason", request.MissedStartOfCareReason);
            parameters.Add("@UserId", request.UserId);
            parameters.Add("@RequestType",request.RequestType);
            parameters.Add("@DateOfService", request.DateOfService);
            return await ExecuteUpdateAsync(parameters);
        }
        public async Task<CaseManagementResponseModel> UpdateCaseStatusAsync(CaseManagementModel request)
        {
            var parameters = SaveCareCoordinationRequestParameterBuilder.BuildUpdateCaseStatusParameters(request);
            return await ExecuteUpdateAsync(parameters);
        }
        public async Task<CaseManagementResponseModel> UpdateIsEscalateRequestAsync(CaseManagementModel request)
        {
            var parameters = SaveCareCoordinationRequestParameterBuilder.BuildIsEscalateRequestParameters(request);
            return await ExecuteUpdateAsync(parameters);
        }
        public async Task<CaseManagementResponseModel> UpdateFollowUpDateAsync(CaseManagementModel request)
        {
            CaseManagementResponseModel response = new CaseManagementResponseModel();
            try
            {
                var parameters = SaveCareCoordinationRequestParameterBuilder.BuildFollowUpDateParameters(request);
                return await ExecuteUpdateAsync(parameters);
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Error = ex.Message;
                throw;
            }
        }
        public async Task<CaseManagementResponseModel> AddNoteAsync(CaseManagementModel request)
        {
            CaseManagementResponseModel response = new CaseManagementResponseModel();
            try
            {
                var parameters = SaveCareCoordinationRequestParameterBuilder.BuildAddNotesParameters(request);
                return await ExecuteUpdateAsync(parameters);
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Error = ex.Message;
                throw;
            }
        }
        public async Task<CaseManagementResponseModel> UpdateCaseManagerAsync(CaseManagementModel request)
        {
            CaseManagementResponseModel response = new CaseManagementResponseModel();
            try
            {
                var parameters = SaveCareCoordinationRequestParameterBuilder.BuildUpdateCaseManagerParameters(request);
                return await ExecuteUpdateAsync(parameters);
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Error = ex.Message;
                throw;
            }
        }
        public async Task<CaseManagementResponseModel> ExecuteUpdateAsync(DynamicParameters parameters)
        {
            CaseManagementResponseModel response = new CaseManagementResponseModel();

            try
            {

                var result = await _dbservice.QueryFirstOrDefaultAsync<CaseManagementResponseModel>("[usp_UpdateCareCoordinationCaseStatus]", parameters, commandType: CommandType.StoredProcedure);
                if (result != null)
                {
                    result.IsSuccess = true;
                    return result;
                }
                else
                {
                    return new CaseManagementResponseModel { IsSuccess = true };
                }
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Error = ex.Message;
                throw;
            }

        }
        public async Task<List<CareCoordinationActivityResponseModel>> GetActivityAsync(string careCoordinationEpisodeId)
        { 
            try
            {
                var parameters = SaveCareCoordinationRequestParameterBuilder.BuildGetActivityParameters(careCoordinationEpisodeId);
                return await GetActivityDataAsync(parameters);
            }
            catch (Exception )
            {
                throw ;
            }
        }
        public async Task<List<CareCoordinationActivityResponseModel>> GetActivityDataAsync(DynamicParameters parameters)
        {
            try
            {
                var result = (await _dbservice.QueryAsync<CareCoordinationActivityResponseModel>("[GetCareCoordinationActivityDetails]", parameters, commandType: CommandType.StoredProcedure)).ToList();
                if (result != null && result.Count!=0)
                {
                    return result;

                }
                else
                {
                    return new List<CareCoordinationActivityResponseModel>();
                }
            }
            catch (Exception )
            {
                throw ;
            }

        }
    }
}

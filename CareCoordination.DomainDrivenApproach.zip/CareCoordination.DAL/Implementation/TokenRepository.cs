﻿using AutoMapper;
using Dapper;
using System.Data;
using CareCoordination.Api.DTOs;
using CareCoordination.Application.Abstracts.DALInterfaces;
using CareCoordination.Domain.Models;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System.Diagnostics.CodeAnalysis;

namespace CareCoordination.DAL.Implementation
{
    [ExcludeFromCodeCoverage]
    public class TokenRepository(IConfiguration configuration,IMapper mapper): ITokenRepository
    {
        private readonly string _connectionString = configuration.GetConnectionString("PreAuthin");
        private readonly IConfiguration _configuration = configuration;
        private readonly IMapper _mapper = mapper;

        public void StoreRefreshToken(string userName, string refreshToken)
        {
            using var connection = new SqlConnection(_connectionString);
            using var command = new SqlCommand("UpsertCareCoordinationToken", connection)
            {
                CommandType = CommandType.StoredProcedure
            };
            int refreshTokenexpirationMinutes = Convert.ToInt32(_configuration.GetSection("JwtSettings:refreshTokenexpirationMinutes").Value);
            command.Parameters.AddWithValue("@UserName", userName);
            command.Parameters.AddWithValue("@RefreshToken",refreshToken);
            command.Parameters.AddWithValue("@Expiration", DateTime.UtcNow.AddMinutes(refreshTokenexpirationMinutes));
            connection.Open();  
            command.ExecuteNonQuery();
        }

        public TokenResponse GetUserToken(string userName,string refreshToken)
        {
            TokenResponse result = new TokenResponse();
            var parameters = new DynamicParameters();
            parameters.Add("@UserName",string.IsNullOrEmpty(userName) ? DBNull.Value : userName,DbType.String);
            parameters.Add("@RefreshToken",string.IsNullOrEmpty(refreshToken) ? "CalledForValidation" : refreshToken,DbType.String);
            using(var connection = new SqlConnection(_connectionString))
            {
                try
                {
                    connection.Open();
                    var spResult = (connection.Query<CareCoordinationAuthTokenEntity>("GetCareCoordinationToken",parameters,commandType: CommandType.StoredProcedure));
                    if (spResult.Any())
                    {
                        result = _mapper.Map<TokenResponse>(spResult.FirstOrDefault());
                    }
                }
                catch(Exception)
                {
                    throw;
                }
                return result;
            }
        }
    }
}

﻿using Dapper;
using System.Data;
using CareCoordination.Domain.Entities;
using CareCoordination.Application.Abstracts.DALInterfaces;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using CareCoordination.Domain.Models;
using AutoMapper;
using System.Diagnostics.CodeAnalysis;

namespace CareCoordination.DAL.Implementation
{
    [ExcludeFromCodeCoverage]
    public class UserRepository(IConfiguration configuration,IMapper mapper): IUserRepository
    {
        private readonly string _connectionString = configuration.GetConnectionString("PreAuthin");
        private readonly IMapper _mapper = mapper;

        public User GetUserDetails(string userName)
        {
            User user = new User();
            var parameters = new DynamicParameters();
            parameters.Add("@UserName",string.IsNullOrEmpty(userName) ? DBNull.Value : userName,DbType.String);
            using(var connection = new SqlConnection(_connectionString))
            {
                try
                {
                    connection.Open();
                    var spResult = (connection.Query<UserRolesEntity>("CCT_GetUserRoles_ByUserName",parameters,commandType: CommandType.StoredProcedure));
                    user = _mapper.Map<User>(spResult.FirstOrDefault());
                    user.HasLEA = spResult.Any(i => i.RoleID == 96);
                    user.Permissions = spResult?.Select(i => i.Permission)?.ToArray() ?? Array.Empty<string>();
                }
                catch(Exception)
                {
                    throw;
                }
            }
            return user;
        }
    }
}

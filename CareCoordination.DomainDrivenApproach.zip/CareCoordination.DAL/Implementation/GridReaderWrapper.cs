﻿using CareCoordination.Application.Abstracts.DALInterfaces;
using Dapper;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordination.DAL.Implementation
{
    [ExcludeFromCodeCoverage]
    public class GridReaderWrapper : IGridReaderWrapper
    {
        private readonly SqlMapper.GridReader _gridReader;
        private bool _disposed;

        public GridReaderWrapper(SqlMapper.GridReader gridReader)
        {
            _gridReader = gridReader;
        }

        public Task<IEnumerable<T>> ReadAsync<T>(bool buffered = true)
        {
            return _gridReader.ReadAsync<T>(buffered);
        }

        public Task<T?> ReadSingleOrDefaultAsync<T>()
        {
            return _gridReader.ReadSingleOrDefaultAsync<T>();
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                if (disposing)
                {
                    // Dispose managed resources
                    _gridReader.Dispose();
                }

                // Dispose unmanaged resources

                _disposed = true;
            }
        }

        public void Dispose()
        {
            Dispose(disposing: true);
            GC.SuppressFinalize(this);
        }
    }
}

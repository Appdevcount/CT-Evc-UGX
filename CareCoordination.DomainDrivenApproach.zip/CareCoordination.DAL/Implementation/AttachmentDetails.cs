﻿using AutoMapper;
using CareCoordination.Application.Abstracts.DALInterfaces;
using CareCoordination.Application.Models;
using CareCoordination.Domain.Models;
using Dapper;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordination.DAL.Implementation
{
    public class AttachmentDetails : IAttachmentDetails
    {
        private readonly IDbService _dbservice;
        public AttachmentDetails(IDbService dbService)
        {
            _dbservice = dbService;
        }

        public void AddAttachmentDetails(UploadedFileDalModel fileDalModel)

        {
            var parameters = new DynamicParameters();
            parameters.Add("@AMSObjectValetId",string.IsNullOrEmpty(fileDalModel.AMSObjectValetId.ToString()) ? DBNull.Value : fileDalModel.AMSObjectValetId.ToString(),DbType.String);
            parameters.Add("@AttachmentName", string.IsNullOrEmpty(fileDalModel.AttachmentName) ? DBNull.Value : fileDalModel.AttachmentName, DbType.String);
            parameters.Add("@DocumentType", string.IsNullOrEmpty(fileDalModel.DocumentType) ? DBNull.Value : fileDalModel.DocumentType, DbType.String);
            parameters.Add("@EpisodeId", string.IsNullOrEmpty(fileDalModel.EpisodeId) ? DBNull.Value : fileDalModel.EpisodeId, DbType.String);
            parameters.Add("@UserId", string.IsNullOrEmpty(fileDalModel.UserId) ? DBNull.Value : fileDalModel.UserId, DbType.String);
            
            _dbservice.ExecuteAsync("CC_AddAttachmentDetails", parameters, commandType: CommandType.StoredProcedure);
        }
        public async Task<bool> DeleteAttachmentDetails(DeleteFilePropertiesViewModel deleteFilePropertiesViewModel)

        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@ObjectId",deleteFilePropertiesViewModel.ObjectId);
                parameters.Add("@EpisodeId",deleteFilePropertiesViewModel.EpisodeId);
                var result = await _dbservice.ExecuteAsync("CC_DeleteAttachmentDetails",parameters,commandType: CommandType.StoredProcedure);
                return result > 0;
            }
            catch (Exception)
            {
                return false;
            }   
        }
        public int  GetAttachmentCount(string EpisodeId)
        {
            int result = 0;
            var parameter = new DynamicParameters();
            parameter.Add("@EpisodeId",string.IsNullOrWhiteSpace(EpisodeId)?DBNull.Value:EpisodeId, DbType.String);
            result =  _dbservice.QueryFirstOrDefault<int>("CC_GetAttachmentCount", parameter, commandType: CommandType.StoredProcedure);
            return result;
        }
    }
}

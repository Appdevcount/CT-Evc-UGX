﻿using Dapper;
using System.Data;
using CareCoordination.Domain.Entities;
using CareCoordination.Application.Abstracts.DALInterfaces;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using CareCoordination.Domain.Models;
using AutoMapper;
using System.Diagnostics.CodeAnalysis;

namespace CareCoordination.DAL.Implementation
{
    [ExcludeFromCodeCoverage]
    public class PatientRepository(IConfiguration configuration): IPatientRepository
    {
        private readonly string _connectionString = configuration.GetConnectionString("OAOData") ?? string.Empty;
               
        public bool IsRestrictedMember(string PatientId)
        {
            bool isRestrictedMember = false;
            var parameters = new DynamicParameters();
            parameters.Add("@PatientId", string.IsNullOrEmpty(PatientId) ? DBNull.Value : PatientId, DbType.String);
            using (var connection = new SqlConnection(_connectionString))
            {
                try
                {
                    connection.Open();
                    isRestrictedMember = (connection.QuerySingleOrDefault<bool>("isRestrictedMember", parameters, commandType: CommandType.StoredProcedure));
                }
                catch (Exception)
                {
                    throw;
                }
            }
            return isRestrictedMember;
        }
    }
}

﻿using AutoMapper;
using CareCoordination.Application.Abstracts.DALInterfaces;
using CareCoordination.Application.Models.SiteRequestModels;
using CareCoordination.Domain.Models;
using Dapper;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System.Data;
using System.Diagnostics.CodeAnalysis;

namespace CareCoordination.DAL.Implementation
{
    [ExcludeFromCodeCoverage]
    public class SiteRepository(IConfiguration configuration):ISiteRepository
    {
        private readonly string _connectionString = configuration.GetConnectionString("PreAuthin") ?? string.Empty;
        private readonly string _connectionStringOAOData = configuration.GetConnectionString("OAODATA") ?? string.Empty;

        public string UpsertSiteDetails(UpdateSiteDetailsRequestModel updateSiteDetailsRequestModel)
        {
            using var connection = new SqlConnection(_connectionString);
            using(var command = new SqlCommand("UpsertSiteDetails_1",connection))
            {
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@CareCoordinationEpisodeId",string.IsNullOrEmpty(updateSiteDetailsRequestModel.CareCoordinationEpisodeId) ? DBNull.Value : updateSiteDetailsRequestModel.CareCoordinationEpisodeId);
                command.Parameters.AddWithValue("@OAOSiteID",string.IsNullOrEmpty(updateSiteDetailsRequestModel.OAOSiteID) ? DBNull.Value : updateSiteDetailsRequestModel.OAOSiteID);
                command.Parameters.AddWithValue("@NonParSiteID",string.IsNullOrEmpty(updateSiteDetailsRequestModel.NonParSiteID) ? DBNull.Value : updateSiteDetailsRequestModel.NonParSiteID);
                command.Parameters.AddWithValue("@OldSiteID",string.IsNullOrEmpty(updateSiteDetailsRequestModel.OldSiteID) ? DBNull.Value : updateSiteDetailsRequestModel.OldSiteID);
                command.Parameters.AddWithValue("@SiteName",string.IsNullOrEmpty(updateSiteDetailsRequestModel.SiteName) ? DBNull.Value : updateSiteDetailsRequestModel.SiteName);
                command.Parameters.AddWithValue("@SiteAddr1",string.IsNullOrEmpty(updateSiteDetailsRequestModel.SiteAddr1) ? DBNull.Value : updateSiteDetailsRequestModel.SiteAddr1);
                command.Parameters.AddWithValue("@SiteAddr2",string.IsNullOrEmpty(updateSiteDetailsRequestModel.SiteAddr2) ? DBNull.Value : updateSiteDetailsRequestModel.SiteAddr2);
                command.Parameters.AddWithValue("@SiteCity",string.IsNullOrEmpty(updateSiteDetailsRequestModel.SiteCity) ? DBNull.Value : updateSiteDetailsRequestModel.SiteCity);
                command.Parameters.AddWithValue("@SiteState",string.IsNullOrEmpty(updateSiteDetailsRequestModel.SiteState) ? DBNull.Value : updateSiteDetailsRequestModel.SiteState);
                command.Parameters.AddWithValue("@SiteZip",string.IsNullOrEmpty(updateSiteDetailsRequestModel.SiteZip) ? DBNull.Value : updateSiteDetailsRequestModel.SiteZip);
                command.Parameters.AddWithValue("@SitePhone",string.IsNullOrEmpty(updateSiteDetailsRequestModel.SitePhone) ? DBNull.Value : updateSiteDetailsRequestModel.SitePhone);
                command.Parameters.AddWithValue("@SiteFax",string.IsNullOrEmpty(updateSiteDetailsRequestModel.SiteFax) ? DBNull.Value : updateSiteDetailsRequestModel.SiteFax);
                command.Parameters.AddWithValue("@SiteSpec1",string.IsNullOrEmpty(updateSiteDetailsRequestModel.SiteSpec1) ? DBNull.Value : updateSiteDetailsRequestModel.SiteSpec1);
                command.Parameters.AddWithValue("@SiteSpec2",string.IsNullOrEmpty(updateSiteDetailsRequestModel.SiteSpec2) ? DBNull.Value : updateSiteDetailsRequestModel.SiteSpec2);
                command.Parameters.AddWithValue("@SiteSpecDesc1",string.IsNullOrEmpty(updateSiteDetailsRequestModel.SiteSpecDesc1) ? DBNull.Value : updateSiteDetailsRequestModel.SiteSpecDesc1);
                command.Parameters.AddWithValue("@SiteSpecDesc2",string.IsNullOrEmpty(updateSiteDetailsRequestModel.SiteSpecDesc2) ? DBNull.Value : updateSiteDetailsRequestModel.SiteSpecDesc2);
                command.Parameters.AddWithValue("@SiteAlternateID",string.IsNullOrEmpty(updateSiteDetailsRequestModel.SiteAlternateID) ? DBNull.Value : updateSiteDetailsRequestModel.SiteAlternateID);
                command.Parameters.AddWithValue("@SiteNYMIPar",string.IsNullOrEmpty(updateSiteDetailsRequestModel.SiteNYMIPar) ? DBNull.Value : updateSiteDetailsRequestModel.SiteNYMIPar);
                command.Parameters.AddWithValue("@SteeragePosition",updateSiteDetailsRequestModel.SteeragePosition == null ? DBNull.Value : updateSiteDetailsRequestModel.SteeragePosition);
                command.Parameters.AddWithValue("@NPI",string.IsNullOrEmpty(updateSiteDetailsRequestModel.NPI) ? DBNull.Value : updateSiteDetailsRequestModel.NPI);
                command.Parameters.AddWithValue("@SiteIdent",updateSiteDetailsRequestModel.SiteIdent);
                command.Parameters.AddWithValue("@SelectionMethodID",updateSiteDetailsRequestModel.SelectionMethodID);
                command.Parameters.AddWithValue("@Email",string.IsNullOrEmpty(updateSiteDetailsRequestModel.Email) ? DBNull.Value : updateSiteDetailsRequestModel.Email);
                command.Parameters.AddWithValue("@PUSRDF",string.IsNullOrEmpty(updateSiteDetailsRequestModel.PUSRDF) ? DBNull.Value : updateSiteDetailsRequestModel.PUSRDF);
                command.Parameters.AddWithValue("@SiteIPA",string.IsNullOrEmpty(updateSiteDetailsRequestModel.SiteIPA) ? DBNull.Value : updateSiteDetailsRequestModel.SiteIPA);
                command.Parameters.AddWithValue("@SiteEntity",string.IsNullOrEmpty(updateSiteDetailsRequestModel.SiteEntity) ? DBNull.Value : updateSiteDetailsRequestModel.CareCoordinationEpisodeId);
                command.Parameters.AddWithValue("@SiteType",string.IsNullOrEmpty(updateSiteDetailsRequestModel.SiteType) ? DBNull.Value : updateSiteDetailsRequestModel.SiteType);
                command.Parameters.AddWithValue("@UserId", string.IsNullOrEmpty(updateSiteDetailsRequestModel.UserId) ? DBNull.Value : updateSiteDetailsRequestModel.UserId);
                command.Parameters.AddWithValue("@PhysicianName", string.IsNullOrEmpty(updateSiteDetailsRequestModel.PhysicianName) ? DBNull.Value : updateSiteDetailsRequestModel.PhysicianName);

                SqlParameter outputParameter = new SqlParameter("@ResultMessage",SqlDbType.VarChar,50)
                {
                    Direction = ParameterDirection.Output
                };

                command.Parameters.Add(outputParameter);

                connection.Open();
                command.ExecuteNonQuery();
                return !string.IsNullOrEmpty(outputParameter.Value.ToString()) ? outputParameter.Value.ToString() : string.Empty;
            }
        }

        public CaseDetailsEntity GetDetailsForSiteLookupRequestModel(string episodeId)
        {
            CaseDetailsEntity response = new CaseDetailsEntity();
            var parameters = new DynamicParameters();
            parameters.Add("@EpisodeId",string.IsNullOrEmpty(episodeId) ? DBNull.Value : episodeId,DbType.String);
            using(var connection = new SqlConnection(_connectionString))
            {
                try
                {
                    connection.Open();
                    var spResult = (connection.Query<CaseDetailsEntity>("USP_GetCCEpisodeDetails",parameters,commandType: CommandType.StoredProcedure));
                    if(spResult.Any())
                    {
                        response = spResult.First();
                    }
                }
                catch(Exception)
                {
                    throw;
                }
            }
            return response;
        }

        public async Task<List<GetSitesResponse>> GetSites(GetSitesRequestModel request)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@MbrZip", string.IsNullOrEmpty(request?.MbrZip) ? string.Empty : request.MbrZip, DbType.String);
            parameters.Add("@Carrier", string.IsNullOrEmpty(request?.Carrier) ? string.Empty : request.Carrier, DbType.String);
            parameters.Add("@CPTCode", string.IsNullOrEmpty(request?.CPTCode) ? string.Empty : request.CPTCode, DbType.String);
            parameters.Add("@MemberIPA", string.IsNullOrEmpty(request?.MemberIPA) ? string.Empty : request.MemberIPA, DbType.String);
            parameters.Add("@PatientEntity", string.IsNullOrEmpty(request?.PatientEntity) ? string.Empty : request.PatientEntity, DbType.String);
            parameters.Add("@MemberPlanType", string.IsNullOrEmpty(request?.MemberPlanType) ? string.Empty : request.MemberPlanType, DbType.String);
            parameters.Add("@SiteID", string.IsNullOrEmpty(request?.SiteID) ? string.Empty : request.SiteID, DbType.String);
            parameters.Add("@SiteName", string.IsNullOrEmpty(request?.SiteName) ? string.Empty : request.SiteName, DbType.String);
            parameters.Add("@Sitecity", string.IsNullOrEmpty(request?.SiteCity) ? string.Empty : request.SiteCity, DbType.String);
            parameters.Add("@SiteZip", string.IsNullOrEmpty(request?.SiteZip) ? string.Empty : request.SiteZip, DbType.String);
            parameters.Add("@AltID", string.IsNullOrEmpty(request?.AltID) ? string.Empty : request.AltID, DbType.String);
            parameters.Add("@PatientPlanCode", string.IsNullOrEmpty(request?.PatientPlanCode) ? string.Empty : request.PatientPlanCode, DbType.String);
            parameters.Add("@CaseProviderTypeID", 0, DbType.Int32);
            parameters.Add("@AllEntity", string.IsNullOrEmpty(request?.AllEntity) ? string.Empty : request.AllEntity, DbType.String);
            parameters.Add("@AllIpaCode", string.IsNullOrEmpty(request?.AllIPACode) ? string.Empty : request.AllIPACode, DbType.String);
            parameters.Add("@PatPUSRDF", string.IsNullOrEmpty(request?.PatPUSRDF) ? string.Empty : request.PatPUSRDF, DbType.String);
            parameters.Add("@ssnum", string.IsNullOrEmpty(request?.ssnum) ? string.Empty : request.ssnum, DbType.String);
            parameters.Add("@NetworkId", string.IsNullOrEmpty(request?.NetworkId) ? string.Empty : request.NetworkId, DbType.String);

            using (var connection = new SqlConnection(_connectionStringOAOData))
            {
                await connection.OpenAsync();
                return (await connection.QueryAsync<GetSitesResponse>("CCT_SiteLookup_UserSearch_GeoZip_7_0_CIGNA_CCPNR", parameters, commandTimeout: 90, commandType: CommandType.StoredProcedure)).ToList();
            }
        }
    }
}

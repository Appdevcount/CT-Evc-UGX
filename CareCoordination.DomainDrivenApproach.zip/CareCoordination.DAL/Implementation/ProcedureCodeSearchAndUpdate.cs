﻿using AutoMapper;
using CareCoordination.Application.Abstracts.DALInterfaces;
using CareCoordination.Application.Models;
using CareCoordination.Domain.Models;
using Dapper;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordination.DAL.Implementation
{
    public class ProcedureCodeSearchAndUpdate : IProcedureCodeSearchAndUpdate
    {
        private readonly IMapper _mapper;
        private readonly IDbService _dbservice; 
        public ProcedureCodeSearchAndUpdate(IMapper mapper, IDbService dbService)
        {
            _mapper = mapper;
            _dbservice = dbService;
        }


        public async Task<ProcedureCodeSearchResponseModel> GetProcedureCodes(ProcedureCodeSearchRequestModel request)

        {
            List<ProcedureCodeDetails> toRet = new List<ProcedureCodeDetails>();
            ProcedureCodeSearchResponseModel response = new ProcedureCodeSearchResponseModel();
            var parameters = new DynamicParameters();
            parameters.Add("@ProcedureCodeIDorDesc", string.IsNullOrEmpty(request?.ProcedureCodeIDorDesc) ? DBNull.Value : request.ProcedureCodeIDorDesc, DbType.String);
            parameters.Add("@InsCarrier", string.IsNullOrEmpty(request?.InsCarrier) ? DBNull.Value : request.InsCarrier, DbType.String);
            parameters.Add("@CompanyID", string.IsNullOrEmpty(request?.CompanyID.ToString()) ? DBNull.Value : request.CompanyID, DbType.Int32);

            try
            {
                var spResult = (await _dbservice.QueryAsync<ProcedureCodeSearchResponseEntity>("CCT_GetCPTProcedureByCarrier", parameters, commandType: CommandType.StoredProcedure)).ToList();
                toRet = _mapper.Map<List<ProcedureCodeDetails>>(spResult);
                response.ProcedureCodeDetails = toRet;
                response.IsSuccess = true;
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Error = ex.Message;
                throw;
            }

            return response;
        }
        public async Task<ProcedureCodeAddOrRemoveResponseModel> AddProcedureCode(ProcedureCodeAddOrRemoveRequestModel request)
        {
            ProcedureCodeAddOrRemoveResponseModel response = new ProcedureCodeAddOrRemoveResponseModel();
            var parameters = CreateParameters(request);
            try
            {

                await _dbservice.ExecuteAsync("CC_AddProcedureCodes", parameters, commandType: CommandType.StoredProcedure);
                response.IsSuccess = true;


            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Error = ex.Message;
                throw;
            }
            return response;


        }
        public async Task<ProcedureCodeAddOrRemoveResponseModel> RemoveProcedureCode(ProcedureCodeAddOrRemoveRequestModel request)
        {
            ProcedureCodeAddOrRemoveResponseModel response = new ProcedureCodeAddOrRemoveResponseModel();
            var parameters = CreateParameters(request);
            try
            {
                await _dbservice.ExecuteAsync("CC_RemoveProcedureCodes", parameters, commandType: CommandType.StoredProcedure);
                response.IsSuccess = true;

            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Error = ex.Message;
                throw;
            }
            return response;
        }
        public static DynamicParameters CreateParameters(ProcedureCodeAddOrRemoveRequestModel request)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@EpisodeID", string.IsNullOrEmpty(request?.EpisodeID) ? DBNull.Value : request.EpisodeID, DbType.String);
            parameters.Add("@ProcedureDesc", string.IsNullOrEmpty(request?.ProcedureDesc) ? DBNull.Value : request.ProcedureDesc, DbType.String);
            parameters.Add("@ProcedureCode", string.IsNullOrEmpty(request?.ProcedureCode) ? DBNull.Value : request.ProcedureCode, DbType.String);
            parameters.Add("@UserId", string.IsNullOrEmpty(request?.UserId) ? DBNull.Value : request.UserId, DbType.String);
            parameters.Add("@PrivateDutyNurse", request?.PrivateDutyNurse == null ? DBNull.Value : request.PrivateDutyNurse, DbType.Boolean);
            parameters.Add("@CustomNeed", request?.CustomNeed == null ? DBNull.Value : request.CustomNeed, DbType.Boolean);

            return parameters;
        }
    }
}

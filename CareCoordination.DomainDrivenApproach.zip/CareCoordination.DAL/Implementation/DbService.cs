﻿using CareCoordination.Application.Abstracts.DALInterfaces;
using CareCoordination.Application.Models;
using CareCoordination.Domain.Models;
using Dapper;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordination.DAL.Implementation
{
    [ExcludeFromCodeCoverage]
    public class DbService : IDbService 
    {
        private readonly IDbConnection _db;

        public DbService(IConfiguration config)
        {
            _db = new SqlConnection(config.GetConnectionString("PreAuthin"));
        }

        public async Task<IEnumerable<T>> QueryAsync<T>(string command, object? parms, CommandType? commandType, IDbTransaction? transaction = null, int? commandTimeout = null)
        {
            return await _db.QueryAsync<T>(command, parms, transaction, commandTimeout, commandType);
        }

        public async Task<T?> QueryFirstOrDefaultAsync<T>(string command, object? parms, CommandType? commandType, IDbTransaction? transaction = null, int? commandTimeout = null)
        {
            return await _db.QueryFirstOrDefaultAsync<T>(command, parms, transaction, commandTimeout, commandType) ?? default;
        }
        public  T? QueryFirstOrDefault<T>(string command, object? parms, CommandType? commandType, IDbTransaction? transaction = null, int? commandTimeout = null)
        {
            return  _db.QueryFirstOrDefault<T>(command, parms, transaction, commandTimeout, commandType) ?? default;
        }

        public async Task<int> ExecuteAsync(string command, object? parms, CommandType? commandType, IDbTransaction? transaction = null, int? commandTimeout = null)
        {
            return await _db.ExecuteAsync(command, parms, transaction, commandTimeout, commandType);
        }
        public async Task<IGridReaderWrapper> QueryMultipleAsync(string command, object? parms, CommandType? commandType, IDbTransaction? transaction = null, int? commandTimeout = null)
        {
            var multi = await _db.QueryMultipleAsync(command, parms, transaction, commandTimeout, commandType);
            return new GridReaderWrapper(multi);
        }

        public async Task<GetRequestDetailsByIdResultModel?> QueryMultipleAsyncForRequestDetails(string command, object? parms, CommandType? commandType, IDbTransaction? transaction = null, int? commandTimeout = null)
        {
            var multi = await _db.QueryMultipleAsync(command, parms, transaction, commandTimeout, commandType);
            return new GetRequestDetailsByIdResultModel
            {
                RequestEntity = await multi.ReadSingleOrDefaultAsync<CareCoordinationRequestEntity>(),
                AttachmentsEntity = await multi.ReadAsync<AttachmentEntity>(),
                NotesEntity = await multi.ReadAsync<NoteEntity>(),
                CptCodesEntity = await multi.ReadAsync<CptCodeEntity>(),
                ActivitiesEntity = await multi.ReadAsync<CareCoordinationActivityEntity>()
            };
        }
    }
}

﻿using AutoMapper;
using CareCoordination.Application.Abstracts.DALInterfaces;
using CareCoordination.Application.Models;
using CareCoordination.Domain.Models;
using Dapper;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Mail;
using System.Transactions;
using System.Data.Common;
using Azure.Core;
using System.Text.RegularExpressions;
using CareCoordination.Api.Helpers;

namespace CareCoordination.DAL.Implementation
{
    public class DashboardView : IDashboardView
    {
        private readonly IDbService _dbservice;
        public DashboardView(IDbService dbService)
        {
            _dbservice = dbService;
        }
        public async Task<DashboardLoadResponseModel> GetDashboardDetails(DashboardLoadRequestModel request)
        {
            DashboardLoadResponseModel toRet = new DashboardLoadResponseModel();
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@UserName", string.IsNullOrEmpty(request?.UserName) ? DBNull.Value : request.UserName, DbType.String);
                parameters.Add("@PageSize", request?.PageSize == null ? (object)DBNull.Value : request.PageSize, DbType.Int32);
                parameters.Add("@PageIndex", request?.PageIndex == null ? (object)DBNull.Value : request.PageIndex, DbType.Int32);
                parameters.Add("@IsFirstLoad", request?.IsFirstLoad == null ? (object)DBNull.Value : (object)request.IsFirstLoad, DbType.Boolean);
                DataTable filterDetailsDataTable = new DataTable();
                filterDetailsDataTable.Columns.Add("FilterKey", typeof(string));
                filterDetailsDataTable.Columns.Add("FilterValue", typeof(string));

                if (request?.FilterDetails?.Count > 0)
                {
                    filterDetailsDataTable = ConvertFilterDictionaryToDataTable(request?.FilterDetails);
                    if (filterDetailsDataTable.Rows.Count == 0)
                    {
                        toRet.IsSuccess = false;
                        toRet.Error = "SQL Injection detected. Cancelling the execution.";
                        return toRet;
                    }
                }
                parameters.Add("@FilterDetails", filterDetailsDataTable.AsTableValuedParameter("FilterDetailsType"));
                using (var multi = await _dbservice.QueryMultipleAsync("CC_GetDashboardDetails", parameters, commandType: CommandType.StoredProcedure))
                {

                    var dashboardDetails = (await multi.ReadAsync<DashboardDetail>()).ToList();
                    toRet.DashboardDetails = dashboardDetails;
                    toRet.TotalRecords = await multi.ReadSingleOrDefaultAsync<int>();
                    toRet.IsSupervisor = await multi.ReadSingleOrDefaultAsync<bool>();
                    if (request != null && request.IsFirstLoad)
                    {
                        var casesOpen = await multi.ReadSingleOrDefaultAsync<int>();
                        var isEscalated = await multi.ReadSingleOrDefaultAsync<int>();
                        var isNotEscalated = await multi.ReadSingleOrDefaultAsync<int>();
                        var missedStartOfCare = await multi.ReadSingleOrDefaultAsync<int>();
                        var assigned = await multi.ReadSingleOrDefaultAsync<int>();
                        var assigneeId = await multi.ReadSingleOrDefaultAsync<int>();
                        var homeHealth = await multi.ReadSingleOrDefaultAsync<int>();
                        var dme = await multi.ReadSingleOrDefaultAsync<int>();
                        var sleep = await multi.ReadSingleOrDefaultAsync<int>();
                        var onP = await multi.ReadSingleOrDefaultAsync<int>();
                        var homwInfusionTherapy = await multi.ReadSingleOrDefaultAsync<int>();
                        var memberEscalation = await multi.ReadSingleOrDefaultAsync<int>();
                        var missedServices = await multi.ReadSingleOrDefaultAsync<int>();
                        var findServiceProvider = await multi.ReadSingleOrDefaultAsync<int>();
                        var otherReason = await multi.ReadSingleOrDefaultAsync<int>();
                        var noneReason = await multi.ReadSingleOrDefaultAsync<int>();
                        var closed = await multi.ReadSingleOrDefaultAsync<int>();
                        var unassigned = await multi.ReadSingleOrDefaultAsync<int>();

                        var dashboardCounts = new Application.Models.DashboardCounts
                        {
                            CasesOpen = casesOpen,
                            IsEscalated = isEscalated,
                            IsNotEscalated = isNotEscalated,
                            MissedStartOfCare = missedStartOfCare,
                            Assigned = assigned,
                            AssigneeId = assigneeId,
                            HomeHealth = homeHealth,
                            DME = dme,
                            Sleep = sleep,
                            OnP = onP,
                            HomeInfusionTherapy=homwInfusionTherapy,
                            MemberEscalation = memberEscalation,
                            MissedServices = missedServices,
                            FindServiceProvider = findServiceProvider,
                            OtherReason = otherReason,
                            NoneReason = noneReason,
                            Closed = closed,
                            Unassigned = unassigned
                        };
                        toRet.DashboardCounts = dashboardCounts;
                    }

                    toRet.IsSuccess = true;
                }
            }
            catch (Exception ex)
            {
                toRet.IsSuccess = false;
                toRet.Error = ex.Message;
            }
            return toRet;
        }
        public static DataTable ConvertFilterDictionaryToDataTable(Dictionary<string, string>? filterDetails)
        {
            var dataTable = new DataTable();
            dataTable.Columns.Add("FilterKey", typeof(string));
            dataTable.Columns.Add("FilterValue", typeof(string));

            if (filterDetails != null)
            {
                foreach (var filter in filterDetails)
                {
                    if (IsSafeInput(filter.Value) && (!SecurityHelper.IsPotentialXss(filter.Value)))        
                    {
                        dataTable.Rows.Add(filter.Key, filter.Value);
                    }
                    else
                    {
                        return new DataTable();
                    }
                }
            }

            return dataTable;
        }
        public static bool IsSafeInput(string input)
        {
            string pattern = @"\b(WAITFOR|DELAY|SLEEP|EXEC|UNION|SELECT|INSERT|DELETE|UPDATE|DROP|--|;)\b";
            return !Regex.IsMatch(input, pattern, RegexOptions.IgnoreCase, TimeSpan.FromMilliseconds(500));
        }
        public async Task<DashboardCaseAssignmentResponseModel> DashboardCaseAssignment(DashboardCaseAssignmentRequestModel request)
        {
            DashboardCaseAssignmentResponseModel response = new DashboardCaseAssignmentResponseModel();

            DataTable episodeIDTable = new DataTable();
            episodeIDTable.Columns.Add("EpisodeID", typeof(string));
            if (request != null && request.CareCoordinationEpisodeIDs != null)
            {
                foreach (var episodeID in request.CareCoordinationEpisodeIDs)
                {
                    episodeIDTable.Rows.Add(episodeID);
                }
            }
            var parameters = new DynamicParameters();
            // Add the table-valued parameter to the DynamicParameters
            parameters.Add("@EpisodeIDList", episodeIDTable.AsTableValuedParameter("EpisodeIDListType"));
            parameters.Add("@AssigneeName", string.IsNullOrEmpty(request?.AssigneeName) ? DBNull.Value : request.AssigneeName, DbType.String);
            try
            {

                await _dbservice.ExecuteAsync("CC_CaseAssignment", parameters, commandType: CommandType.StoredProcedure);
                response.IsSuccess = true;


            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Error = ex.Message;
                throw;
            }
            return response;

        }

        public async Task<AssigneeDetailsResponse> GetAssigneeDetails(string UserName)
        {
            AssigneeDetailsResponse response = new AssigneeDetailsResponse();
            var parameters = new DynamicParameters();
            parameters.Add("@UserName", string.IsNullOrEmpty(UserName) ? DBNull.Value : UserName, DbType.String);
            try
            {
                var res= await _dbservice.QueryAsync<AssigneeDetailsResponseModel>("CC_GetAssigneeDetails", parameters, commandType: CommandType.StoredProcedure);
                response.AssigneeUser=res.Select(x => x.AssigneeUser).ToList()!;
                response.AssigneeName=res.Select(x =>x.AssigneeName).ToList()!;
                response.IsSuccess=true;

            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Error = ex.Message;
                throw;
            }
            return response;
        }
    }
}



﻿using AutoMapper;
using CareCoordination.Application.Abstracts.DALInterfaces;
using CareCoordination.Application.Models;
using CareCoordination.Domain.Models;
using Dapper;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics.CodeAnalysis;

namespace CareCoordination.DAL.Implementation
{
    public class RequestSearch : IRequestSearch
    {
        private readonly IMapper _mapper;
        private readonly IDbService _dbservice;
        public RequestSearch(IMapper mapper, IDbService dbService)
        {
            _mapper = mapper;
            _dbservice = dbService;
        }

        public async Task<List<RequestSearchResult>> GetRequests(GetCareCoordinationRequestModel request)
        {
            List<RequestSearchResult> toRet;

            var parameters = new DynamicParameters();
            parameters.Add("@Id", string.IsNullOrEmpty(request?.Id) ? DBNull.Value : request.Id, DbType.String);
            parameters.Add("@FirstName", string.IsNullOrEmpty(request?.FirstName) ? DBNull.Value : request.FirstName, DbType.String);
            parameters.Add("@LastName", string.IsNullOrEmpty(request?.LastName) ? DBNull.Value : request.LastName, DbType.String);
            parameters.Add("@Dob", string.IsNullOrEmpty(request?.DateOfBirth) ? DBNull.Value : request.DateOfBirth, DbType.DateTime);
            parameters.Add("@Status", string.IsNullOrEmpty(request?.Status) ? DBNull.Value : request.Status, DbType.String);

            var spResult = (await _dbservice.QueryAsync<RequestSearchResultEntity>("usp_GetCCrequests", parameters, commandType: CommandType.StoredProcedure)).ToList();
            toRet = _mapper.Map<List<RequestSearchResult>>(spResult);
            return toRet;
        }

        public async Task<CareCoordinationDetails> GetRequestDetailsById(string Id)
        {
            CareCoordinationDetails toRet = new CareCoordinationDetails();
            var parameters = new DynamicParameters();
            parameters.Add("@Id", string.IsNullOrEmpty(Id) ? DBNull.Value : Id, DbType.String);
            GetRequestDetailsByIdResultModel? spResult = await _dbservice.QueryMultipleAsyncForRequestDetails("usp_GetCCrequestById", parameters, commandType: CommandType.StoredProcedure);
            var Result = _mapper.Map<CareCoordinationDetails>(spResult?.RequestEntity);
            if (Result != null)
            {
                Result.Notes = _mapper.Map<List<Note>>(spResult?.NotesEntity);
                Result.Attachments = _mapper.Map<List<Attachment>>(spResult?.AttachmentsEntity);
                Result.CPTCodes = _mapper.Map<List<CptCodeModel>>(spResult?.CptCodesEntity);
                Result.Activity = _mapper.Map<List<CareCoordinationActivity>>(spResult?.ActivitiesEntity);
                return Result;
            }
            return toRet;
        }
    }
}

﻿namespace CareCoordination.DAL;

public class Class1
{

}

﻿using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics.CodeAnalysis;

namespace CareCoordination.Api.Helpers
{
    public class XssFilterAttribute : ActionFilterAttribute
    {
        [ExcludeFromCodeCoverage]
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            foreach (var argument in context.ActionArguments.Values)
            {

                if (argument is string input && SecurityHelper.IsPotentialXss(input))
                {
                    context.Result = new BadRequestObjectResult("Malicious value detected. Cancelling the request.");
                    return;
                }
                if (argument != null)
                {
                    var properties = argument.GetType().GetProperties();
                    foreach (var property in properties)
                    {
                        
                            if (property.PropertyType == typeof(string))
                            {
                                var value = property.GetValue(argument) as string;
                                if (!string.IsNullOrWhiteSpace(value) && SecurityHelper.IsPotentialXss(value!))
                                {
                                    context.Result = new BadRequestObjectResult("Malicious value detected. Cancelling the request.");
                                    return;
                                }
                            }
                        
                    }

                }

                base.OnActionExecuting(context);
            }
        }

    }
}


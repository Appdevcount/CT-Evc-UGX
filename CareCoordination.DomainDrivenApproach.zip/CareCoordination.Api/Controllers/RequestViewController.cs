﻿using AutoMapper;
using CareCoordination.Api.DTOs;
using CareCoordination.Api.Helpers;
using CareCoordination.Application.Abstracts.HandlerInterfaces;
using CareCoordination.Application.Logger;
using CareCoordination.Application.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.IdentityModel.Tokens.Jwt;
using System.Net;

namespace CareCoordination.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RequestViewController : Controller
    {
        private readonly IApplicationLogger _logger;
        private readonly IMapper _mapper;
        private readonly IRequestViewLookupManagement _reqViewLookupManagement;
        public RequestViewController(IApplicationLogger logger, IMapper mapper, IRequestViewLookupManagement reqViewLookupManagement)
        {
            _logger = logger;
            _mapper = mapper;
            _reqViewLookupManagement = reqViewLookupManagement ?? throw new ArgumentNullException(nameof(reqViewLookupManagement));
        }
        [Authorize]
        [HttpPost("GetProcedureCodes")]
        public async Task<IActionResult> GetProcedureCodes(ProcedureCodeSearchRequest request)
        {
            ProcedureCodeSearchResponseModel response = new ProcedureCodeSearchResponseModel();
            try
            {
                _logger.LogInformation($"{typeof(RequestViewController).Name}: GetProcedureCodes Started.");

                if((request ==null)|| string.IsNullOrEmpty(request.InsCarrier) || string.IsNullOrEmpty(request.CompanyID.ToString()) || string.IsNullOrEmpty(request.ProcedureCodeIDorDesc))
                {
                    response.IsSuccess= false;
                    _logger.LogError($"{typeof(RequestViewController).Name}: GetProcedureCodes: Validation Failed");
                    return BadRequest(response);
                }
                ProcedureCodeSearchRequestModel req = _mapper.Map<ProcedureCodeSearchRequestModel>(request);

                _logger.LogInformation($"{typeof(RequestViewController).Name}: GetProcedureCodes - Internal Method Started for ProcedureCodeID - {request.ProcedureCodeIDorDesc}.");

                response = await _reqViewLookupManagement.GetProcedureCodes(req);

                _logger.LogInformation($"{typeof(RequestViewController).Name}: GetProcedureCodes - Internal Method Ended for ProcedureCodeID - {request.ProcedureCodeIDorDesc}.");
                _logger.LogInformation($"{typeof(RequestViewController).Name}: GetProcedureCodes Ended for ProcedureCodeID - {request.ProcedureCodeIDorDesc}.");

                return Ok(response);
               
            }
            catch (Exception ex)
            {
                _logger.LogException($"{typeof(RequestViewController).Name}: GetProcedureCodes Error for ProcedureCodeID - {request.ProcedureCodeIDorDesc}.",ex);
                response.IsSuccess = false;
                response.Error= ex.Message;
                return StatusCode((int)HttpStatusCode.InternalServerError,response);
            }

        }

        [Authorize]
        [HttpPost("AddProcedureCode")]
        public async Task<IActionResult> AddProcedureCode(ProcedureCodeAddOrRemoveRequest request)
        {
            ProcedureCodeAddOrRemoveResponseModel response= new ProcedureCodeAddOrRemoveResponseModel();
            try
            {
                string userid = JwtHelper.GetUserId(Request);
                if ((request == null) || string.IsNullOrEmpty(request.EpisodeID) || string.IsNullOrEmpty(request.ProcedureCode) || string.IsNullOrEmpty(request.ProcedureDesc))
                _logger.LogInformation($"{typeof(RequestViewController).Name}: AddProcedureCode Started.");

                if((request == null) || string.IsNullOrEmpty(request.EpisodeID) || string.IsNullOrEmpty(request.ProcedureCode) || string.IsNullOrEmpty(request.ProcedureDesc))
                {
                    response.IsSuccess = false;
                    _logger.LogError($"{typeof(RequestViewController).Name}: AddProcedureCode: Validation Failed");
                    return BadRequest(response);
                }
                else
                {
                    ProcedureCodeAddOrRemoveRequestModel model = _mapper.Map<ProcedureCodeAddOrRemoveRequestModel>(request);
                    model.UserId = userid;
                    _logger.LogInformation($"{typeof(RequestViewController).Name}: AddProcedureCode - Internal Method Started for RequestId - {request.EpisodeID}.");

                    response = await _reqViewLookupManagement.AddProcedureCode(model);

                    _logger.LogInformation($"{typeof(RequestViewController).Name}: AddProcedureCode - Internal Method Ended for RequestId - {request.EpisodeID}.");
                    _logger.LogInformation($"{typeof(RequestViewController).Name}: AddProcedureCode Ended for RequestId - {request.EpisodeID}.");

                    return Ok(response);
                }

            }
            catch (Exception ex)
            {
                _logger.LogException($"{typeof(RequestViewController).Name}: AddProcedureCode Error for RequestId - {request.EpisodeID}.",ex);
                response.IsSuccess = false;
                response.Error= ex.Message;
                return StatusCode((int)HttpStatusCode.InternalServerError, response);

            }
        }

        [Authorize]
        [HttpPost("RemoveProcedureCode")]
        public async Task<IActionResult> RemoveProcedureCode(ProcedureCodeAddOrRemoveRequest request)
        {
            ProcedureCodeAddOrRemoveResponseModel response = new ProcedureCodeAddOrRemoveResponseModel();
            try
            {
                string userid = JwtHelper.GetUserId(Request);
                if((request == null) || string.IsNullOrEmpty(request.EpisodeID) || string.IsNullOrEmpty(request.ProcedureCode) || string.IsNullOrEmpty(request.ProcedureDesc))
                {
                    response.IsSuccess = false;
                    return BadRequest(response);
                }
                else
                {
                    ProcedureCodeAddOrRemoveRequestModel model = _mapper.Map<ProcedureCodeAddOrRemoveRequestModel>(request);
                    model.UserId = userid;
                    _logger.LogInformation($"{typeof(RequestViewController).Name}: RemoveProcedureCode - Internal Method Started for RequestId - {request.EpisodeID}.");                    
                    response = await _reqViewLookupManagement.RemoveProcedureCode(model);

                    _logger.LogInformation($"{typeof(RequestViewController).Name}: RemoveProcedureCode - Internal Method Ended for RequestId - {request.EpisodeID}.");
                   
                }
                return Ok(response);

            }
            catch (Exception ex)
            {
                _logger.LogException($"{typeof(RequestViewController).Name}: RemoveProcedureCode Error for RequestId - {request.EpisodeID}.",ex);
                response.IsSuccess = false;
                response.Error= ex.Message;
                return StatusCode((int)HttpStatusCode.InternalServerError, response);
            }            

        }        
    }
}

﻿using AutoMapper;
using Azure.Core;
using CareCoordination.Api.DTOs;
using CareCoordination.Application.Abstracts.HandlerInterfaces;
using CareCoordination.Application.Logger;
using CareCoordination.Application.Models;
using CareCoordination.DAL.Implementation;
using CareCoordination.Domain.Models;
using CareCoordination.Domain.Validators;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Net;

namespace CareCoordination.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RequestCreationController : ControllerBase
    {
        private readonly IApplicationLogger _logger;
        private readonly IRequestCreationManagement _requestCreate;
        private readonly IMapper _mapper;

        public RequestCreationController(IApplicationLogger logger, IMapper mapper, IRequestCreationManagement requestCreate)
        {
            _logger = logger;
            _mapper = mapper;
            _requestCreate = requestCreate ?? throw new ArgumentNullException(nameof(requestCreate));
        }

        [Authorize]
        [HttpPost("SaveCareCordinationRequest")]
        public async Task<IActionResult> SaveCareCordinationRequest(CareCoordinationRequest Request)
        {
            try
            {
                _logger.LogInformation($"{typeof(RequestCreationController).Name}: SaveCareCordinationRequest Started.");

                _logger.LogInformation($"{typeof(RequestCreationController).Name}: SaveCareCordinationRequest - ValidateRequest Started.");

                var errors = RequestCreationValidation.ValidateRequest(_mapper.Map<CareCoordinationDomainModel>(Request));
                if (!string.IsNullOrEmpty(errors))
                {
                    _logger.LogError($"{typeof(RequestCreationController).Name}: SaveCareCordinationRequest: {errors}");
                    return BadRequest(errors);
                }
                else
                {
                    _logger.LogInformation($"{typeof(RequestCreationController).Name}: SaveCareCordinationRequest - ValidateRequest Ended.");
                    _logger.LogInformation($"{typeof(RequestCreationController).Name}: SaveCareCordinationRequest - GetNextSequenceNo Started for RequestId - {Request.EpisodeId}.");

                    CareCoordinationRequestModel requestModel = await _requestCreate.GetNextSequenceNo(_mapper.Map<CareCoordinationRequestModel>(Request));

                    _logger.LogInformation($"{typeof(RequestCreationController).Name}: SaveCareCordinationRequest - GetNextSequenceNo Ended for RequestId - {Request.EpisodeId}.");
                    _logger.LogInformation($"{typeof(RequestCreationController).Name}: SaveCareCordinationRequest - SaveCareCordinationRequest Started for RequestId - {Request.EpisodeId}.");

                    var response = await _requestCreate.SaveCareCordinationRequest(requestModel);

                    _logger.LogInformation($"{typeof(RequestCreationController).Name}: SaveCareCordinationRequest - SaveCareCordinationRequest Ended for RequestId - {Request.EpisodeId}.");

                    if(response.IsSuccess)
                    {
                        _logger.LogInformation($"{typeof(RequestCreationController).Name}: SaveCareCordinationRequest Ended for RequestId - {Request.EpisodeId}.");
                        return Ok(response);
                    }
                    else
                    {
                        _logger.LogError($"{typeof(RequestCreationController).Name}: SaveCareCordinationRequest: {response.Error}");
                        return BadRequest(response.Error);
                    }   
                }
            }
            catch (Exception ex)
            {
                _logger.LogException($"{typeof(RequestCreationController).Name}: SaveCareCordinationRequest Error for RequestId - {Request.EpisodeId}.",ex);
                return StatusCode((int)HttpStatusCode.InternalServerError,ex.Message);
                throw;
            }
        }
    }
}

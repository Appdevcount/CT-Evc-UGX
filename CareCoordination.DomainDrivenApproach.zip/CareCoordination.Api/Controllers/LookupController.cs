using AutoMapper;
using Azure.Core;
using CareCoordination.Api.DTOs;
using CareCoordination.Api.Helpers;
using CareCoordination.Application.Abstracts.HandlerInterfaces;
using CareCoordination.Application.Logger;
using CareCoordination.Application.Models;
using CareCoordination.Application.Models.SiteRequestModels;
using CareCoordination.Domain.Models;
using CareCoordination.Domain.Validators;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.IdentityModel.Tokens.Jwt;
using System.Net;

namespace CareCoordination.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LookupController : ControllerBase
    {
        private readonly IApplicationLogger _logger;
        private readonly IMapper _mapper;
        private readonly IPatientLookupManagement _memberLookupService;
        private readonly ISiteLookupManagement _siteLookupManagement;
        public LookupController(IApplicationLogger logger, IMapper mapper, IPatientLookupManagement memberLookupService, ISiteLookupManagement siteLookupManagement)
        {
            _logger = logger;
            _mapper = mapper;
            _memberLookupService = memberLookupService ?? throw new ArgumentNullException(nameof(memberLookupService));
            _siteLookupManagement = siteLookupManagement ?? throw new ArgumentNullException(nameof(siteLookupManagement));
        }

        [Authorize]
        [HttpPost("GetMemberDetails")]
        public async Task<IActionResult> GetMemberDetails(PatientLookupRequest request)
        {
            List<PatientDetailsResponse> response = new List<PatientDetailsResponse>();
            try
            {
                _logger.LogInformation($"{typeof(LookupController).Name}: GetMemberDetails Started.");

                _logger.LogInformation($"{typeof(LookupController).Name}: GetMemberDetails - ValidateRequest Started.");
                var errors = PatientLookupValidation.ValidateRequest(request?.PatientID, request?.PatientLastName, request?.PatientDob, request?.PatientFirstName);
                if (!string.IsNullOrEmpty(errors))
                {
                    _logger.LogError($"{typeof(LookupController).Name}: GetMemberDetails: {errors}");
                    return BadRequest(errors);
                }
                else
                {
                    _logger.LogInformation($"{typeof(LookupController).Name}: GetMemberDetails - ValidateRequest Ended for PatientId - {request.PatientID}.");
                    PatientLookupRequestModel model = _mapper.Map<PatientLookupRequestModel>(request);

                    _logger.LogInformation($"{typeof(LookupController).Name}: GetMemberDetails - Internal Method Started for PatientId - {request.PatientID}.");
                    response = (await _memberLookupService.GetMemberDetails(model));
                    _logger.LogInformation($"{typeof(LookupController).Name}: GetMemberDetails - Internal Method Ended for PatientId - {request.PatientID}.");

                    if(response[0].IsSuccess)
                    {
                        _logger.LogInformation($"{typeof(LookupController).Name}: GetMemberDetails Ended for PatientId - {request.PatientID}.");
                        return Ok(response);
                    }
                    else
                    {
                        _logger.LogError($"{typeof(LookupController).Name}: GetMemberDetails for PatientId - {request.PatientID}: Bad Request");
                        return BadRequest(response);
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogException($"{typeof(LookupController).Name}: GetMemberDetails Error for PatientId - {request.PatientID}.",ex);
                return StatusCode((int)HttpStatusCode.InternalServerError,ex.Message);
                throw;
            }

        }
        [Authorize]
        [HttpPost("MemberEligible")]
        public async Task<IActionResult> GetMemberEligibility(MemberEligibilityRequestModel request)
        {
            try
            {
                _logger.LogInformation($"{typeof(LookupController).Name}: GetMemberEligibility Started.");

                if(request == null || request.Qualifiers == null)
                {
                    _logger.LogError($"{typeof(LookupController).Name}: GetMemberEligibility - Invalid request format");
                    return BadRequest(new { message = "Invalid request format" });
                }

                _logger.LogInformation($"{typeof(LookupController).Name}: GetMemberEligibility Internal Method Started for PatientId - {request.Qualifiers.PatientID}.");
                var response = await _memberLookupService.GetMemberEligibility(request);
                _logger.LogInformation($"{typeof(LookupController).Name}: GetMemberEligibility Internal Method Ended for PatientId - {request.Qualifiers.PatientID}.");

                if(response!= null)
                {
                    _logger.LogInformation($"{typeof(LookupController).Name}: GetMemberEligibility Ended for PatientId - {request.Qualifiers.PatientID}.");
                    return Ok(response);
                }
                else
                {
                    _logger.LogError($"{typeof(LookupController).Name}: GetMemberEligibility - Member's eligibility not completed");
                    return BadRequest("Member's eligibility not completed");
                }
            }
            catch (Exception ex)
            {
                _logger.LogException($"{typeof(LookupController).Name}: GetMemberEligibility Error for PatientId - {request.Qualifiers.PatientID}.",ex);
                return StatusCode((int)HttpStatusCode.InternalServerError,ex.Message);
                throw;
            }
        }

        [Authorize]
        [HttpPost("GetSiteDetails")]
        public async Task<IActionResult> GetSiteDetails(GetSiteDetailsRequestModel request)
        {
            try
            {
                _logger.LogInformation($"{typeof(LookupController).Name}: GetSiteDetails Started.");

                if(request == null)
                {
                    _logger.LogError($"{typeof(LookupController).Name}: GetSiteDetails - Invalid request format");
                    return BadRequest("Invalid request format");
                }

                _logger.LogInformation($"{typeof(LookupController).Name}: GetSiteDetails Internal Method Started for RequestId - {request.RequestId}.");
                var response = await _siteLookupManagement.GetSiteDetails(request);
                _logger.LogInformation($"{typeof(LookupController).Name}: GetSiteDetails Internal Method Ended for RequestId - {request.RequestId}.");

                if(response != null)
                {
                    _logger.LogInformation($"{typeof(LookupController).Name}: GetSiteDetails Ended for RequestId - {request.RequestId}.");
                    return Ok(response);
                }
                else
                {
                    _logger.LogError($"{typeof(LookupController).Name}: GetSiteDetails for RequestId - {request.RequestId} - Sites not found");
                    return BadRequest("Sites not found");
                }
            }
            catch (Exception ex)
            {
                _logger.LogException($"{typeof(LookupController).Name}: GetSiteDetails Error for RequestId - {request.RequestId}.",ex);
                return StatusCode((int)HttpStatusCode.InternalServerError,ex.Message);
                throw;
            }

        }

        [Authorize]
        [HttpPost("UpsertSiteDetails")]
        public async Task<IActionResult> UpsertSiteDetails(UpdateSiteDetailsRequestModel updateSiteDetailsRequestModel)
        {
            try
            {
                string userid = JwtHelper.GetUserId(Request);
                _logger.LogInformation($"{typeof(LookupController).Name}: UpsertSiteDetails Started.");

                if(updateSiteDetailsRequestModel == null)
                {
                    _logger.LogError($"{typeof(LookupController).Name}: UpsertSiteDetails - Invalid request format");
                    return BadRequest("Invalid request format");
                }

                _logger.LogInformation($"{typeof(LookupController).Name}: UpsertSiteDetails Internal Method Started for RequestId - {updateSiteDetailsRequestModel.CareCoordinationEpisodeId}.");
                updateSiteDetailsRequestModel.UserId = userid;  
                var response = _siteLookupManagement.UpsertSiteDetails(updateSiteDetailsRequestModel);
                _logger.LogInformation($"{typeof(LookupController).Name}: UpsertSiteDetails Internal Method Ended for RequestId - {updateSiteDetailsRequestModel.CareCoordinationEpisodeId}.");

                if(!string.IsNullOrEmpty(response) && response.Equals("SUCCESS"))
                {
                    _logger.LogInformation($"{typeof(LookupController).Name}: UpsertSiteDetails Ended for RequestId - {updateSiteDetailsRequestModel.CareCoordinationEpisodeId}.");
                    return Ok(response);
                }
                else
                {
                    _logger.LogError($"{typeof(LookupController).Name}: UpsertSiteDetails for RequestId - {updateSiteDetailsRequestModel.CareCoordinationEpisodeId} - Upserting Site Details Failed");
                    return BadRequest("Upserting Site Details Failed.");
                }
            }
            catch(Exception ex)
            {
                _logger.LogException($"{typeof(LookupController).Name}: UpsertSiteDetails Error for RequestId - {updateSiteDetailsRequestModel.CareCoordinationEpisodeId}.",ex);
                return StatusCode((int)HttpStatusCode.InternalServerError,ex.Message);
                throw;
            }

        }

    }
}

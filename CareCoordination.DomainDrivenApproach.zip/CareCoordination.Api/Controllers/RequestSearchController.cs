﻿using Microsoft.AspNetCore.Mvc;
using CareCoordination.Api.DTOs;
using Newtonsoft.Json;
using CareCoordination.Application.Models;
using AutoMapper;
using System.Net;
using System.Globalization;
using CareCoordination.Application.Abstracts.HandlerInterfaces;
using CareCoordination.Application.Logger;
using Azure.Core;
using CareCoordination.Domain.Models;
using Microsoft.AspNetCore.Authorization;
using CareCoordination.Api.Helpers;

namespace CareCoordination.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RequestSearchController : ControllerBase
    {
        private readonly IApplicationLogger _logger;
        private readonly IRequestSearchManagement _requestSearch;
        private readonly IMapper _mapper;
        public RequestSearchController(IApplicationLogger logger, IMapper mapper, IRequestSearchManagement requestSearch)
        {
            _logger = logger;
            _mapper = mapper;
            _requestSearch = requestSearch ?? throw new ArgumentNullException(nameof(requestSearch));
        }
        [Authorize]
        [HttpPost("GetRequests")]
        public async Task<IActionResult> GetRequests(SearchCareCoordinationRequest request)
        {
            RequestSearchResponse response = new RequestSearchResponse();
            try
            {
                string userid = JwtHelper.GetUserId(Request);
                _logger.LogInformation($"{typeof(RequestSearchController).Name}: GetRequests Started.");

                if(!string.IsNullOrEmpty(request?.DateOfBirth) && !DateTime.TryParseExact(request.DateOfBirth, "MM/dd/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out _))
                {
                    response.IsSuccess = false;
                    response.Error = "Invalid date format. Expected MM/dd/yyyy.";
                    _logger.LogError($"{typeof(RequestSearchController).Name}: GetRequests: {response.Error}");
                    return BadRequest(response);
                }
                if(request == null || (string.IsNullOrEmpty(request.Id) && string.IsNullOrEmpty(request.FirstName) && string.IsNullOrEmpty(request.LastName) && string.IsNullOrEmpty(request.DateOfBirth)))
                {
                    response.IsSuccess = false;
                    response.Error = "Invalid input.";
                    _logger.LogError($"{typeof(RequestSearchController).Name}: GetRequests: {response.Error}");
                    return BadRequest(response);
                }
                request.UserName = userid;
                _logger.LogInformation($"{typeof(RequestSearchController).Name}: GetRequests - Internal Method Started for PatientId - {request.Id}.");
                response.SearchResults = await _requestSearch.GetRequests(_mapper.Map<GetCareCoordinationRequestModel>(request));
                _logger.LogInformation($"{typeof(RequestSearchController).Name}: GetRequests - Internal Method Ended for PatientId - {request.Id}.");

                response.IsSuccess = true;
                _logger.LogInformation($"{typeof(RequestSearchController).Name}: GetRequests Ended for PatientId - {request.Id}.");
            }
            catch (Exception ex)
            {
                _logger.LogException($"{typeof(RequestSearchController).Name}: GetRequests Error for PatientId - {request.Id}.",ex);
                response.IsSuccess = false;
                response.Error = ex.Message;
                return StatusCode((int)HttpStatusCode.InternalServerError, response);
            }
            return Ok(response);
        }

        [Authorize]
        [HttpGet("GetRequestDetailsById")]
        public async Task<IActionResult> GetRequestDetailsById(string Id)
        {
            CareCoordinationDetails response;
            try
            {
                _logger.LogInformation($"{typeof(RequestSearchController).Name}: GetRequestDetailsById Started.");

                if(string.IsNullOrEmpty(Id))
                {
                    _logger.LogError($"{typeof(RequestSearchController).Name}: GetRequestDetailsById: Id is required");
                    return BadRequest("Id is required");
                }
                _logger.LogInformation($"{typeof(RequestSearchController).Name}: GetRequestDetailsById - Internal Method Started for PatientId - {Id}.");
                response = await _requestSearch.GetRequestDetailsById(Id);
                _logger.LogInformation($"{typeof(RequestSearchController).Name}: GetRequestDetailsById - Internal Method Ended for PatientId - {Id}.");
            }
            catch (Exception ex)
            {
                _logger.LogException($"{typeof(RequestSearchController).Name}: GetRequestDetailsById Error for PatientId - {Id}.",ex);
                return Problem(ex.Message);
            }
            _logger.LogInformation($"{typeof(RequestSearchController).Name}: GetRequestDetailsById Ended for PatientId - {Id}.");
            return Ok(response);
        }
    }
}

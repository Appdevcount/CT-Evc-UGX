﻿using AutoMapper;
using Azure.Core;
using CareCoordination.Api.DTOs;
using CareCoordination.Api.Helpers;
using CareCoordination.Application.Abstracts.HandlerInterfaces;
using CareCoordination.Application.Logger;
using CareCoordination.Application.Models;
using CareCoordination.Domain.Models;
using CareCoordination.Domain.Validators;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.IdentityModel.Tokens.Jwt;
using System.Net;

namespace CareCoordination.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CaseManagementController : ControllerBase
    {
        private readonly IApplicationLogger _logger;
        private readonly IMapper _mapper;
        private readonly ICaseManagement _requestHandle;

        public CaseManagementController(IApplicationLogger logger, IMapper mapper, ICaseManagement requestHandle)
        {
            _logger = logger;
            _mapper = mapper;
            _requestHandle = requestHandle ?? throw new ArgumentNullException(nameof(requestHandle));
        }
        [Authorize]
        [HttpPost("UpdateMSOCorDOS")]
        public async Task<IActionResult> UpdateMissedStartOfCareAsync(CaseManagement request)
        {
            try
            {
                string userid = JwtHelper.GetUserId(Request);
                CaseManagementEntity entity = _mapper.Map<CaseManagementEntity>(request);

                _logger.LogInformation($"{typeof(CaseManagementController).Name}: UpdateMissedStartOfCareAsync - ValidateMSOCRequest Started.");
                var errors = CaseManagmentValidation.ValidateMSOCRequest(entity);
                
                if (!string.IsNullOrEmpty(errors))
                {
                    _logger.LogError($"{typeof(CaseManagementController).Name}: UpdateMissedStartOfCareAsync: {errors}");
                    return BadRequest(errors);
                }
                else
                {
                    _logger.LogInformation($"{typeof(CaseManagementController).Name}: UpdateMissedStartOfCareAsync - ValidateMSOCRequest Ended for RequestId - {request.RequestId}.");
                    CaseManagementModel model = _mapper.Map<CaseManagementModel>(request);
                    model.UserId = userid;
                    _logger.LogInformation($"{typeof(CaseManagementController).Name}: UpdateMissedStartOfCareAsync - Internal Method Started for RequestId - {request.RequestId}.");
                    await _requestHandle.UpdateMissedStartOfCareAsync(model);
                    _logger.LogInformation($"{typeof(CaseManagementController).Name}: UpdateMissedStartOfCareAsync - Internal Method Ended for RequestId - {request.RequestId}.");

                    return Ok("Status updated successfully");
                }
            }
            catch (Exception ex)
            {
                _logger.LogException($"{typeof(CaseManagementController).Name}: UpdateMissedStartOfCareAsync Error for RequestId - {request.RequestId}.",ex);
                return StatusCode((int)HttpStatusCode.InternalServerError,ex.Message);
                throw;
            }
        }

        [Authorize]
        [HttpPost("UpdateCaseStatus")]
        public async Task<IActionResult> UpdateCaseStatusAsync(CaseManagement request)
        {
            try
            {
                string userid = JwtHelper.GetUserId(Request);
                CaseManagementEntity entity = _mapper.Map<CaseManagementEntity>(request);

                _logger.LogInformation($"{typeof(CaseManagementController).Name}: UpdateCaseStatusAsync - ValidateCaseStatusRequest.");
                var errors = CaseManagmentValidation.ValidateCaseStatusRequest(entity);
                if (!string.IsNullOrEmpty(errors))
                {
                    _logger.LogError($"{typeof(CaseManagementController).Name}: UpdateCaseStatusAsync: {errors}");
                    return BadRequest(errors);
                }
                else
                {
                    _logger.LogInformation($"{typeof(CaseManagementController).Name}: UpdateCaseStatusAsync - ValidateCaseStatusRequest Ended for RequestId - {request.RequestId}.");
                    CaseManagementModel model = _mapper.Map<CaseManagementModel>(request);
                    model.UserId = userid;

                    _logger.LogInformation($"{typeof(CaseManagementController).Name}: UpdateCaseStatusAsync - Internal Method Started for RequestId - {request.RequestId}.");
                    await _requestHandle.UpdateCaseStatusAsync(model);
                    _logger.LogInformation($"{typeof(CaseManagementController).Name}: UpdateCaseStatusAsync - Internal Method Ended for RequestId - {request.RequestId}.");

                    return Ok("Request updated successfully");
                }
            }
            catch (Exception ex)
            {
                _logger.LogException($"{typeof(CaseManagementController).Name}: UpdateCaseStatusAsync Error for RequestId - {request.RequestId}.",ex);
                return StatusCode((int)HttpStatusCode.InternalServerError,ex.Message);
                throw;
            }
        }

        [Authorize]
        [HttpPost("UpdateIsEscalateRequest")]
        public async Task<IActionResult> UpdateIsEscalateRequestAsync(CaseManagement request)
        {
            try
            {
                string userid = JwtHelper.GetUserId(Request);
                _logger.LogInformation($"{typeof(CaseManagementController).Name}: UpdateIsEscalateRequestAsync Started.");
                CaseManagementEntity entity = _mapper.Map<CaseManagementEntity>(request);

                _logger.LogInformation($"{typeof(CaseManagementController).Name}: UpdateIsEscalateRequestAsync - ValidateEscalateRequest Started.");
                var errors = CaseManagmentValidation.ValidateEscalateRequest(entity);
                if (!string.IsNullOrEmpty(errors))
                {
                    _logger.LogError($"{typeof(CaseManagementController).Name}: UpdateIsEscalateRequestAsync: {errors}");
                    return BadRequest(errors);
                }
                else
                {
                    _logger.LogInformation($"{typeof(CaseManagementController).Name}: UpdateIsEscalateRequestAsync - ValidateEscalateRequest Ended for RequestId - {request.RequestId}.");
                    CaseManagementModel model = _mapper.Map<CaseManagementModel>(request);
                    model.UserId = userid;

                    _logger.LogInformation($"{typeof(CaseManagementController).Name}: UpdateIsEscalateRequestAsync - Internal Method Started for RequestId - {request.RequestId}.");
                    await _requestHandle.UpdateIsEscalateRequestAsync(model);
                    _logger.LogInformation($"{typeof(CaseManagementController).Name}: UpdateIsEscalateRequestAsync - Internal Method Ended for RequestId - {request.RequestId}.");

                    if(request?.IsEscalated is true)
                    {
                        _logger.LogInformation($"{typeof(CaseManagementController).Name}: UpdateIsEscalateRequestAsync Ended - Request escalated successfully for RequestId - {request.RequestId}");
                        return Ok("Request escalated successfully");
                    }
                    else
                    {
                        _logger.LogInformation($"{typeof(CaseManagementController).Name}: UpdateIsEscalateRequestAsync Ended - Request updated successfully for RequestId - {request.RequestId}");
                        return Ok("Request updated successfully");
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogException($"{typeof(CaseManagementController).Name}: UpdateIsEscalateRequestAsync Error for RequestId - {request.RequestId}.",ex);
                return StatusCode((int)HttpStatusCode.InternalServerError,ex.Message);
                throw;
            }

        }
        [Authorize]
        [HttpPost("UpdateFollowUPDate")]
        public async Task<IActionResult> UpdateFollowUPDateAsync(CaseManagement request)
        {
            try
            {
                string userid = JwtHelper.GetUserId(Request);
                _logger.LogInformation($"{typeof(CaseManagementController).Name}: UpdateFollowUPDateAsync Started.");
                CaseManagementEntity entity = _mapper.Map<CaseManagementEntity>(request);

                _logger.LogInformation($"{typeof(CaseManagementController).Name}: UpdateFollowUPDateAsync - ValidateFollowUPDate Started.");
                var errors = CaseManagmentValidation.ValidateFollowUPDate(entity);
                if (!string.IsNullOrEmpty(errors))
                {
                    _logger.LogError($"{typeof(CaseManagementController).Name}: UpdateFollowUPDateAsync: {errors}");
                    return BadRequest(errors);
                }
                else
                {
                    _logger.LogInformation($"{typeof(CaseManagementController).Name}: UpdateFollowUPDateAsync - ValidateFollowUPDate Ended for RequestId - {request.RequestId}.");
                    CaseManagementModel model = _mapper.Map<CaseManagementModel>(request);
                    model.UserId = userid;

                    _logger.LogInformation($"{typeof(CaseManagementController).Name}: UpdateFollowUPDateAsync - Internal Method Started for RequestId - {request.RequestId}.");
                    await _requestHandle.UpdateFollowUpDateAsync(model);
                    _logger.LogInformation($"{typeof(CaseManagementController).Name}: UpdateFollowUPDateAsync - Internal Method Ended for RequestId - {request.RequestId}.");
                    _logger.LogInformation($"{typeof(CaseManagementController).Name}: UpdateFollowUPDateAsync Ended for RequestId - {request.RequestId}.");

                    return Ok("Request updated successfully");
                }
            }
            catch (Exception ex)
            {
                _logger.LogException($"{typeof(CaseManagementController).Name}: UpdateFollowUPDateAsync Error for RequestId - {request.RequestId}.",ex);
                return StatusCode((int)HttpStatusCode.InternalServerError,ex.Message);
                throw;
            }

        }
        [Authorize]
        [HttpPost("AddNote")]
        public async Task<IActionResult> AddNoteAsync(CaseManagement request)
        {
            try
            {
                string userid = JwtHelper.GetUserId(Request);
                _logger.LogInformation($"{typeof(CaseManagementController).Name}: AddNoteAsync Started.");
                CaseManagementEntity entity = _mapper.Map<CaseManagementEntity>(request);

                _logger.LogInformation($"{typeof(CaseManagementController).Name}: AddNoteAsync - ValidateAddedNotes Started.");
                var errors = CaseManagmentValidation.ValidateAddedNotes(entity);

                if(!string.IsNullOrEmpty(errors))
                {
                    _logger.LogError($"{typeof(CaseManagementController).Name}: AddNoteAsync: {errors}");
                    return BadRequest(errors);
                }
                else
                {
                    _logger.LogInformation($"{typeof(CaseManagementController).Name}: AddNoteAsync - ValidateAddedNotes Ended for RequestId - {request.RequestId}.");
                    CaseManagementModel model = _mapper.Map<CaseManagementModel>(request);
                    model.UserId = userid;

                    _logger.LogInformation($"{typeof(CaseManagementController).Name}: AddNoteAsync - Internal Method Started for RequestId - {request.RequestId}.");
                    var result = await _requestHandle.AddNoteAsync(model);
                    _logger.LogInformation($"{typeof(CaseManagementController).Name}: AddNoteAsync - Internal Method Ended for RequestId - {request.RequestId}.");

                    if(result.IsSuccess)
                    {
                        _logger.LogInformation($"{typeof(CaseManagementController).Name}: AddNoteAsync Ended for RequestId - {request.RequestId}.");
                        return Ok(new { Message = "Request has been successfully created", Data = result });
                    }
                    else
                    {
                        _logger.LogError($"{typeof(CaseManagementController).Name}: AddNoteAsync for RequestId - {request.RequestId}: {result.Error}");
                        return BadRequest(result.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogException($"{typeof(CaseManagementController).Name}: AddNoteAsync Error.",ex);
                return StatusCode((int)HttpStatusCode.InternalServerError,ex.Message);
                throw;
            }

        }
        [Authorize]
        [HttpPost("UpdateCaseManager")]
        public async Task<IActionResult> UpdateCaseManagerAsync(CaseManagement request)
        {
            try
            {
                string userid = JwtHelper.GetUserId(Request);
                _logger.LogInformation($"{typeof(CaseManagementController).Name}: UpdateCaseManagerAsync Started.");
                CaseManagementEntity entity = _mapper.Map<CaseManagementEntity>(request);

                _logger.LogInformation($"{typeof(CaseManagementController).Name}: UpdateCaseManagerAsync - ValidateCaseManager Started.");
                var errors = CaseManagmentValidation.ValidateCaseManager(entity);
                if (!string.IsNullOrEmpty(errors))
                {
                    _logger.LogError($"{typeof(CaseManagementController).Name}: UpdateCaseManagerAsync: {errors}");
                    return BadRequest(errors);
                }
                else
                {
                    _logger.LogInformation($"{typeof(CaseManagementController).Name}: UpdateCaseManagerAsync - ValidateCaseManager Ended for RequestId - {request.RequestId}.");
                    
                    CaseManagementModel model = _mapper.Map<CaseManagementModel>(request);
                    model.UserId = userid;

                    _logger.LogInformation($"{typeof(CaseManagementController).Name}: UpdateCaseManagerAsync - Internal Method Started for RequestId - {request.RequestId}.");
                    
                    var result = await _requestHandle.UpdateCaseManagerAsync(model);
                    
                    _logger.LogInformation($"{typeof(CaseManagementController).Name}: UpdateCaseManagerAsync - Internal Method Ended for RequestId - {request.RequestId}.");
                    _logger.LogInformation($"{typeof(CaseManagementController).Name}: UpdateCaseManagerAsync Ended for RequestId - {request.RequestId}.");
                    
                    return Ok(new { Message = "Request has been successfully created", Data = result });
                }
            }
            catch (Exception ex)
            {
                _logger.LogException($"{typeof(CaseManagementController).Name}: UpdateCaseManagerAsync Error for RequestId - {request.RequestId}.",ex);
                return StatusCode((int)HttpStatusCode.InternalServerError,ex.Message);
                throw;
            }

        }
        [Authorize]
        [HttpPost("GetActivity")]
        public async Task<IActionResult> GetActivityAsync(string careCoordinationEpisodeId)
        {
            try
            {
                _logger.LogInformation($"{typeof(CaseManagementController).Name}: GetActivityAsync Started.");
                _logger.LogInformation($"{typeof(CaseManagementController).Name}: GetActivityAsync - ValidateActivityDetails Started.");
                var errors = CaseManagmentValidation.ValidateActivityDetails(careCoordinationEpisodeId);
                if (!string.IsNullOrEmpty(errors))
                {
                    _logger.LogError($"{typeof(CaseManagementController).Name}: GetActivityAsync: {errors}");
                    return BadRequest(errors);
                }
                else
                {
                    _logger.LogInformation($"{typeof(CaseManagementController).Name}: GetActivityAsync - ValidateActivityDetails Ended for RequestId - {careCoordinationEpisodeId}.");
                    _logger.LogInformation($"{typeof(CaseManagementController).Name}: GetActivityAsync - Internal Method Started for RequestId - {careCoordinationEpisodeId}.");

                    var result = await _requestHandle.GetActivityAsync(careCoordinationEpisodeId);

                    _logger.LogInformation($"{typeof(CaseManagementController).Name}: GetActivityAsync - Internal Method Ended for RequestId - {careCoordinationEpisodeId}.");
                    _logger.LogInformation($"{typeof(CaseManagementController).Name}: GetActivityAsync Ended for RequestId - {careCoordinationEpisodeId}.");

                    return Ok(new { Message = "Activity details has been successfully returned", Data = result });
                }
            }
            catch (Exception ex)
            {
                _logger.LogException($"{typeof(CaseManagementController).Name}: GetActivityAsync Error for RequestId - {careCoordinationEpisodeId}.",ex);
                return StatusCode((int)HttpStatusCode.InternalServerError,ex.Message);
                throw;
            }
        }
    }
}

﻿using AutoMapper;
using Azure;
using CareCoordination.Api.DTOs;
using CareCoordination.Api.Helpers;
using CareCoordination.Application.Abstracts.HandlerInterfaces;
using CareCoordination.Application.Abstracts.ServiceInterfaces;
using CareCoordination.Application.Logger;
using CareCoordination.Application.Models;
using CareCoordination.Domain.Validators;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.StaticFiles;
using Microsoft.Extensions.Logging;
using System.Net;

namespace CareCoordination.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AttachmentsController : ControllerBase
    {
        private readonly IApplicationLogger _logger;
        private readonly IAttachmentManagement _attachmentManagement;
        private readonly IMapper _mapper;

        public AttachmentsController(IApplicationLogger logger, IMapper mapper, IAttachmentManagement attachmentManagement)
        {
            _logger = logger;
            _mapper = mapper;
            _attachmentManagement = attachmentManagement ?? throw new ArgumentNullException(nameof(attachmentManagement));

        }

        [Authorize]
        [HttpPost("UploadFile")]
        [ApiExplorerSettings(IgnoreApi = true)]
        public IActionResult UploadFile([FromForm] string requestId, [FromForm] IFormFile file,
             [FromForm] string fileName, [FromForm] string createdBy, [FromForm] string documentType)
        {
            string userid = JwtHelper.GetUserId(Request);
            if (requestId == null)
            {
                return BadRequest();
            }
            else if (string.IsNullOrEmpty(requestId))
            {
                return BadRequest(new { Message = "File Not found - size invalid" });
            }
            else
            {
                try
                {
                    string error = AttachmentValidation.ValidateAttachment(file);
                    if(error != string.Empty)
                    {
                        return BadRequest(error);
                    }
                    var request = new UploadedFileModel
                    {
                        EpisodeId = requestId,
                        file = file,
                        Filename = file.FileName,
                        DocumentType = documentType,
                        UserName = createdBy,
                        UserId = userid
                    };
                 error = _attachmentManagement.GetAttachmentCount(request.EpisodeId)!;
                    if (!string.IsNullOrEmpty(error))
                    {
                        return BadRequest(error);
                    }
                    _logger.LogInformation($"{typeof(AttachmentsController).Name}: UploadFile Started for  EpisodeId: - {requestId} and  Filename : {fileName}");
                    var UploadedFileProperties = _attachmentManagement.PostToOVEndpoint(request,HttpContext);

                    var result = new { AMSObjectValetId = UploadedFileProperties.AMSObjectValetId.ToString(), FileUploadSuccess = (UploadedFileProperties != null && !string.IsNullOrEmpty(UploadedFileProperties.AMSObjectValetId.ToString())) };
                    _logger.LogInformation($"{typeof(AttachmentsController).Name}: UploadFile completed for  EpisodeId: - {requestId} and  Filename : {fileName}");

                    return Ok(result);
                }
                catch (Exception ex)
                {
                    _logger.LogException($"{typeof(AttachmentsController).Name}: UploadFile error for  EpisodeId: - {requestId}", ex);
                    return StatusCode((int)HttpStatusCode.InternalServerError, ex.Message);
                    throw;
                }
            }
        }
        [Authorize]

        [HttpGet("GetUploadedFiles/{EpisodeId}")]
        public IActionResult GetUploadedFiles([FromRoute] string? EpisodeId)
        {
            if (string.IsNullOrEmpty(EpisodeId))
            {
                return BadRequest();
            }
            else
            {
                try
                {
                    _logger.LogInformation($"{typeof(AttachmentsController).Name}: GetUploadedFiles Started for  EpisodeId: - {EpisodeId}");
                    List<UploadedFileDataModel>? filelist = _attachmentManagement.GetListOfObjects(EpisodeId);

                    if (filelist == null || filelist.Count == 0)
                    {
                        _logger.LogError(" AttachmentController - GetUploadedFiles(). Uploaded File not found : Bad request - No Episode ID found");
                        return BadRequest();
                    }
                    else
                    {
                        var result = new { UploadedFileList = filelist };
                        _logger.LogInformation($"{typeof(AttachmentsController).Name}: GetUploadedFiles completed for  EpisodeId: - {EpisodeId} with Filecount : {filelist.Count}");
                        return Ok(result);
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogException($"{typeof(AttachmentsController).Name}: GetUploadedFiles  Error for  EpisodeId: - {EpisodeId}",ex);
                    return StatusCode((int)HttpStatusCode.InternalServerError, ex.Message);
                    throw;
                }
            }
        }
        [Authorize]
        [HttpGet("DownloadFile/{ObjectId}")]
        public async Task<IActionResult> DownloadFile([FromRoute] Int64 ObjectId)
        {
            if (ObjectId == 0)
            {
                return BadRequest();
            }
            else
            {
                try
                {
                    _logger.LogInformation($"{typeof(AttachmentsController).Name}: DownloadFile Started for  ObjectID: - {ObjectId}");
                    DownloadFilePropertiesModel? fileToReturn = await _attachmentManagement.GetFileByObjectId(ObjectId);
                    if (fileToReturn == null || string.IsNullOrEmpty(fileToReturn.FileName) || fileToReturn.FileStreamContent == null)
                    {
                        _logger.LogError($"{typeof(AttachmentsController).Name}: DownloadFile  Not found  for  ObjectID: - {ObjectId}");
                        return BadRequest(new { Message = "File Not found for the given ObjectId" });
                    }
                    else
                    {
                        fileToReturn.ContentType = "application/octet-stream";
                        fileToReturn.FileStreamContent.Position = 0;
                        //Response.Headers.Add("Access-Control-Expose-Headers","Content-Disposition");
                        _logger.LogInformation($"{typeof(AttachmentsController).Name}: DownloadFile  End for  ObjectID: - {ObjectId}");
                        return File(fileToReturn.FileStreamContent, fileToReturn.ContentType, fileToReturn.FileName);
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogException($"{typeof(AttachmentsController).Name}: DownloadFile  Error for  ObjectID: - {ObjectId}",ex);
                    return StatusCode((int)HttpStatusCode.InternalServerError, ex.Message);
                    throw;
                }
            }
        }
        [Authorize]
        [HttpDelete(("DeleteFile"))]
        public async Task<IActionResult> DeleteFile([FromQuery] DeleteFilePropertiesViewModel deleteFilePropertiesViewModel)
        {
            try
            {
                _logger.LogInformation($"{typeof(AttachmentsController).Name}: DeleteFile Start for ObjectID: - {deleteFilePropertiesViewModel.ObjectId}," +
                    $" Episode ID -{deleteFilePropertiesViewModel.EpisodeId}");

                DeleteFilePropertiesModel? response = await _attachmentManagement.DeleteFile(deleteFilePropertiesViewModel);

                _logger.LogInformation($"{typeof(AttachmentsController).Name}: DeleteFile Completed for  ObjectID: - {deleteFilePropertiesViewModel.ObjectId}," +
                    $" Episode ID -{deleteFilePropertiesViewModel.EpisodeId}");
                return Ok(response);
            }
            catch(ArgumentException ae)
            {
                _logger.LogException($"{typeof(AttachmentsController).Name}: Query parameter can not be null for EpisodeId : {deleteFilePropertiesViewModel.EpisodeId}",ae);
                return BadRequest(ae.Message);
            }
            catch(Exception ex)
            {
                _logger.LogException($"{typeof(AttachmentsController).Name}: " +
                    $"DeleteFile Error for  ObjectID: - {deleteFilePropertiesViewModel.ObjectId},EpisodeId -{deleteFilePropertiesViewModel.EpisodeId}",ex);
                return StatusCode((int)HttpStatusCode.InternalServerError,ex.Message);
                throw;
            }
        }
    }
}

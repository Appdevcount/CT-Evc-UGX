﻿using AutoMapper;
using CareCoordination.Application.Abstracts.HandlerInterfaces;
using CareCoordination.Application.Logger;
using CareCoordination.Application.Models;
using CareCoordination.Domain.Models.HistoricalCaseDataModels;
using CareCoordination.Domain.Validators;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Net;

namespace CareCoordination.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HistoricalCaseController:ControllerBase
    {
        private readonly IApplicationLogger _logger;
        private readonly IHistoricalCaseDataManagement _historicalCaseDataManagement;
        private readonly IMapper _mapper;

        public HistoricalCaseController(IApplicationLogger logger,IHistoricalCaseDataManagement historicalCaseDataManagement, IMapper mapper)
        {
            _logger = logger;
            _historicalCaseDataManagement = historicalCaseDataManagement;
            _mapper = mapper;
        }

        [HttpPost]
        [Route("GetHistoricalCaseData")]
        public async Task<IActionResult> GetHistoricalCaseData(GetHistoricalCaseDataRequestModel request)
        {
            List<CareCoordinationHistoricalRequest> careCordinationRequest = new List<CareCoordinationHistoricalRequest>();
            try
            {
                GetHistoricalCaseDataRequestDomainModel model = new GetHistoricalCaseDataRequestDomainModel();
                model.requestId = request.requestId;
                model.patientId = request.patientId;
                model.firstName = request.firstName;
                model.lastName = request.lastName;
                model.dateOfBirth = request.dateOfBirth;
                var errors = GetHistoricalDataValidation.ValidateRequest(model);
                if (!string.IsNullOrEmpty(errors))
                {
                    _logger.LogError($"{typeof(LookupController).Name}: GetHistoricalCaseData: {errors}");
                    return BadRequest(errors);
                }
                _logger.LogInformation($"{typeof(HistoricalCaseController).Name}: GetHistoricalCaseData Started.");
                careCordinationRequest = await _historicalCaseDataManagement.GetHistoricalCaseData(request);
            }
            catch(Exception ex)
            {
                _logger.LogException($"{typeof(HistoricalCaseController).Name}: GetHistoricalCaseData Error.",ex);
                return StatusCode(Convert.ToInt32(HttpStatusCode.InternalServerError),ex.Message);
            }
            _logger.LogInformation($"{typeof(HistoricalCaseController).Name}: GetHistoricalCaseData Ended.");
            return Ok(JsonConvert.SerializeObject(careCordinationRequest));
        }
    }
}

﻿namespace CareCoordination.Api.DTOs
{
    public class ProcedureCodeAddOrRemoveResponse
    {
        public bool IsSuccess { get; set; }
        public string? Error { get; set; }
    }
}

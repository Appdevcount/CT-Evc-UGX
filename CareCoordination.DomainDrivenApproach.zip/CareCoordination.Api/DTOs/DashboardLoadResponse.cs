﻿using System.Diagnostics.CodeAnalysis;

namespace CareCoordination.Api.DTOs
{
    [ExcludeFromCodeCoverage]
    public class DashboardLoadResponse
    {
        public string? EpisodeID { get; set; }
        public string? PatientID { get; set; }
        public string? PatientName { get; set; }
        public DateTime PatientDOB { get; set; }
        public DateTime CreatedDateTime { get; set; }
        public string? CreatedBy { get; set; }
        public DateTime DateOfClosing { get; set; }
        public string? Status { get; set; }
        public string? AssignmentStatus { get; set; }
        public string? SubServiceType { get; set; }
        public string? AssigneeName { get; set; }
        public string? EscalationStatus { get; set; }
        public string? AssigneeId { get; set; }
        public string? Reason { get; set; }
        public string? InsCarrier { get; set; }
        public string? FollowupNotes { get; set; }
        public DateTime FollowupDate { get; set; }
        public string? PatientCity { get; set; }
        public string? PatientState { get; set; }
        public Attachments? Attachments { get; set; }
        public int CasesOpen { get; set; }
        public int IsEscalated { get; set; }
        public int IsNotEscalated { get; set; }
        public int MSOC { get; set; }
        public int Assigned { get; set; }
        public int AssigneeIdCount { get; set; }
        public int HomeHealth { get; set; }
        public int DME { get; set; }
        
        public int Sleep { get; set; }
        public int OnP { get; set; }
        public int MemberEscalation { get; set; }
        public int MissedServices { get; set; }
        public int FindServiceProvider { get; set; }
        public int OtherReason { get; set; }


    }
    [ExcludeFromCodeCoverage]
    public class Attachments
    {
        public string? CreatedBy { get; set; }
        public string? AttachmentName { get; set; }
        public string?   ReceivedDate { get; set; }

    }
}


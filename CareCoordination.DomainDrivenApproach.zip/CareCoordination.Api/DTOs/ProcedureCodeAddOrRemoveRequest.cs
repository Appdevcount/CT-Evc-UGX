﻿using System.Reflection.Emit;

namespace CareCoordination.Api.DTOs
{
    public class ProcedureCodeAddOrRemoveRequest
    {
        public string? UserId { get; set; }
        public string? EpisodeID { get; set; }
        public string? ProcedureCode { get; set; }
        public string? ProcedureDesc { get; set; }
        public bool? PrivateDutyNurse { get; set; }
        public bool? CustomNeed { get; set; }
    }
}

﻿namespace CareCoordination.Api.DTOs
{
    public class DashboardLoadRequest
    {
        public string? UserName {  get; set; }
        public int PageSize { get; set; }
        public int PageIndex { get; set; }
        public bool IsFirstLoad { get; set; } = true;
        public Dictionary<string,string>? FilterDetails { get; set; }
    }
}
﻿using System.Diagnostics.CodeAnalysis;

namespace CareCoordination.Api.DTOs
{
    [ExcludeFromCodeCoverage]
    public class CareCoordinationRequestCreationResponse 
    {
        public bool IsSuccess { get; set; }
        public string? Error { get; set; }
    }

}

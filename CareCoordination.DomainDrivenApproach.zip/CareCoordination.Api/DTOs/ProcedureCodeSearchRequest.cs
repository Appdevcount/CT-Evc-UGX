﻿namespace CareCoordination.Api.DTOs
{
    public class ProcedureCodeSearchRequest
    {
        public string? ProcedureCodeIDorDesc { get; set; }
        public string? InsCarrier { get; set; }
        public int CompanyID { get; set; }
        

    }
}

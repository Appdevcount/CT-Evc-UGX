﻿using System.Diagnostics.CodeAnalysis;

namespace CareCoordination.Api.DTOs
{
    [ExcludeFromCodeCoverage]
    public class PatientLookupRequest   
    {
               
        public string? Carrier { get; set; }
        public string? Counter { get; set; } 
        public string? PatientState { get; set; }
        public required string PatientID { get; set; }
        public string? PatientGroupNumber { get; set; }
        public required string PatientDob { get; set; }
        public string? PatientFirstName { get; set; }
        public required string PatientLastName { get; set; }
        public string? DOS { get; set; }
        public string? Plan1 { get; set; }
        public string? Plan2 { get; set; }
        public string? CPTcode { get; set; }
        public string? CompanyId { get; set; }
        public string? RequestedBy { get; set; } 
        public string? ProviderNPI { get; set; }
    }
}

﻿namespace CareCoordination.Api.DTOs
{
    public class SearchCareCoordinationRequest
    {
        public string? Id { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? DateOfBirth { get; set; }
        public required string Status { get; set; }
        public required string UserName { get; set; }
    }
}

﻿namespace CareCoordination.Api.DTOs
{
    public class DashboardCaseAssignmentRequest
    {
        public List<string>? CareCoordinationEpisodeIDs { get; set; }
        public string? AssigneeName { get; set; }
    }
}

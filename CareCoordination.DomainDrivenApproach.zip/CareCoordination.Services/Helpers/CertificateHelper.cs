﻿using System.Security.Cryptography.X509Certificates;
using System.Security.Cryptography;
using System.Diagnostics.CodeAnalysis;
using Jose;

namespace CareCoordination.Services.Helpers
{
    [ExcludeFromCodeCoverage]
    public static class CertificateHelper
    {
        public static X509Certificate2 GetCertificate(String subjectName)
        {
            X509Store store = new X509Store(StoreName.TrustedPeople, StoreLocation.LocalMachine);
            X509Certificate2Collection? certificates = null;
            store.Open(OpenFlags.ReadOnly);

            try
            {
                X509Certificate2? result = null;

                // Every time we call store.Certificates property, a new collection will be returned.
                certificates = store.Certificates;

                for (int i = 0; i <= certificates.Count - 1; i++)
                {
                    X509Certificate2 cert = certificates[i];

                    if (string.Equals(cert.SubjectName.Name, subjectName, StringComparison.OrdinalIgnoreCase))
                    {
                        if (result != null)
                            throw new ApplicationException(string.Format("There are multiple certificate for subject Name {0}", subjectName));

                        result = new X509Certificate2(cert);
                    }
                }

                if (result == null)
                    throw new ApplicationException(string.Format("No certificate was found for subject Name {0}", subjectName));

                return result;
            }
            finally
            {
                if (certificates != null)
                {
                    for (int i = 0; i <= certificates.Count - 1; i++)
                    {
                        X509Certificate2 cert = certificates[i];
                        cert.Reset();
                    }
                }
                store.Close();
            }
        }

        public static string GetRSAPublicKey(string subjectName)
        {
            if (subjectName == "CN=Test") return "-----BEGIN PUBLIC KEY-----\r\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA7E7b/PXhCZJVtNP8T1Ms\r\nJag9tJZ2HWMCduRsbtCsM6dhgoebgZQfqva6crzKvcwTCE+hFJA6d2AKhNDPQZI3\r\nRhjJnH2WpHvXBlhCAANmZovUPDfx15nKTsjH5KLg6MRn1sQIeP5d9YTxTV6yMMiW\r\nHtpMBEZXfJr3QED5bHEjswDJs63oWDuqdfBQ7kLNI8HbZto8SD2erVgRSnuvCass\r\neA+nB5twQiewSp4x2hR6+hgPFotjMWwd6SNAy4nKSvziJHqsf6VLI8AxdIiU9yhR\r\nK+QOsyA/X9KgrpuE1LDxIYCu+jRlEM52SJTNbCNgA96nt6DWXvjDKnULazQGNj/N\r\nlwIDAQAB\r\n-----END PUBLIC KEY-----";
            var cert = GetCertificate(subjectName);
            RSA? rsa = cert.GetRSAPublicKey();
            string pem = rsa == null ? string.Empty : rsa.ExportSubjectPublicKeyInfoPem();
            return pem;
        }

        public static string GetRSAPrivateKey(string subjectName)
        {
            if (subjectName == "CN=Test") return "-----BEGIN PRIVATE KEY-----\r\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDsTtv89eEJklW0\r\n0/xPUywlqD20lnYdYwJ25Gxu0Kwzp2GCh5uBlB+q9rpyvMq9zBMIT6EUkDp3YAqE\r\n0M9BkjdGGMmcfZake9cGWEIAA2Zmi9Q8N/HXmcpOyMfkouDoxGfWxAh4/l31hPFN\r\nXrIwyJYe2kwERld8mvdAQPlscSOzAMmzrehYO6p18FDuQs0jwdtm2jxIPZ6tWBFK\r\ne68Jqyx4D6cHm3BCJ7BKnjHaFHr6GA8Wi2MxbB3pI0DLicpK/OIkeqx/pUsjwDF0\r\niJT3KFEr5A6zID9f0qCum4TUsPEhgK76NGUQznZIlM1sI2AD3qe3oNZe+MMqdQtr\r\nNAY2P82XAgMBAAECggEAalyMU+1v3tkIzp1jwWiURFbXf0MB4vQ/lbf2vmIaQB2k\r\nnBXhfo9nOZJYFXC4aHlET8dXn2PTjQujcGh0APWI/3oEtPUqKtq6y9ZJzqu5GYry\r\nejBMIFjOYGuq3VQam2pbuqT9k0gajnnKCqMG3UJLn5NuB7aJhkJR64/TNGYwRU7G\r\nEIKTs3sWsCFD+aqfoKOK6c/GaXbQthZl8Ga8dAFRkNn0wkc8RV83d4x7fCx+cQAD\r\nRnROTdGAm1XzGDt00yZ/cMIB2Mdy8QGsi3wRQUhTK0+Y+sg0J1KMjMzfMeM0SUvm\r\nS+I5gQ0VH3evkp8KBq0klmOu27gIYE451GiDXnvgQQKBgQD3Dofa7B2+G44XesGi\r\niH637Hl6P4dGrB+/BOxgEvSeLmZftfuSQ66plLRmk7M9hOpQyA/WNmW7pyGVoknF\r\nxKguVL733bVT6yDVUW8Eph/zrzgT0nZgfJXK2Zr0uAsHkwS/4n1fgg2MlvYJPGTS\r\nr8xeJaJGUB7X9TudhMwTFEcicQKBgQD03Lh1MzIx5HW7nxVDbv3RdDXQhDb+PkpA\r\nQ/UDgYUXfoSN6H4V4O92vnz0vECNIZmq4UIKPukHfYB51KWQoEStOOMroEb2Qzjs\r\nEc6Op+idd+05DCZzrUkgDoLlwzz4QPLDplEAfuJS4/dUpaVYC2eI10yJkldJ0Y35\r\nf2xgsxDkhwKBgQDJnsYoV4F+YCZ56uiTqCkiGI6awbW4a0gNMAtn7JBNdzh865s/\r\nJpUoN/9xpyAkGJDRFDQ4cXRczGyQHT1vdKp8BRVEW19b+Qt2i1q6xIhW6qwtIRkS\r\nbRohzay0Am6d49GAd2oxw4UjMx/fMbZmaqmyO6xPDZveSng4eOPCvk2/QQKBgGkk\r\nQbxpkFsmG3vF8o5zIWAIA3eW3jpLqvxvcczgl7Kf6/E3bLSeUpTtdKBuGVXAoMhk\r\nU0QtAUjrFfi6W6F/gB3VeI5qEy55bP7JIqXU6ah8L4u4cOZo+SZftMtOC2caFGP4\r\njX2l/i7TnodlXVsyAnIa6M2F3h9fcRQ6J+JZ4Z4PAoGAK6ostty39/e/rifkQfjC\r\nZNTx7PO/K2GGERrg0hLt8MpAycUQTzLox3wyXCI3Ww776NBKHILgrWCEOA5rGOde\r\nSFOlsUeOJjk0GfPPXxEcdcVPS8ekQbjS1OKMfx9Ora8tL2rm6V7Dy/mFQ4CxnsQi\r\nyCoiQ48yQNC6HkcBqMXPCfU=\r\n-----END PRIVATE KEY-----";
            var cert = GetCertificate(subjectName);
            RSA? rsa = cert.GetRSAPrivateKey();
            string pem = rsa == null ? string.Empty : rsa.ExportPkcs8PrivateKeyPem();
            return pem;
        }
    }
}

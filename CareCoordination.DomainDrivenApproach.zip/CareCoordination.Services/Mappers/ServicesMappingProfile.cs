﻿using AutoMapper;
using CareCoordination.Application.Models;
using CareCoordination.Application.Models.SiteRequestModels;
using CareCoordination.Domain.Models;
using CareCoordination.Domain.Models.HistoricalCaseDataModels;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordination.Services.Mappers
{
    [ExcludeFromCodeCoverage]
    public class ServicesMappingProfile : Profile
    {
        public ServicesMappingProfile() {
            ConfigureMappings();
        }

        private void ConfigureMappings()
        {
            CreateGetSitesResponseMapping();
            CreateGetHistoricalCaseDataResponseMapping();
        }

        private void CreateGetSitesResponseMapping()
        {
            CreateMap<GetSitesResponse, SearchResult>()
                .ForMember(dest => dest.MemberIPACode, opt => opt.MapFrom(src => src.IPACODE));
        }

        private void CreateGetHistoricalCaseDataResponseMapping()
        {
            CreateMap<Root, CareCoordinationHistoricalRequest>()
            .ForMember(dest => dest.CareCoordinationId, opt => opt.MapFrom(src => src.careCordinationRequest.ccRequestID))
            .ForMember(dest => dest.StatusDetails, opt => opt.MapFrom(src => new StatusDetails 
            { 
                Status = src.careCordinationRequest.ccCaseStatus 
            }))
            .ForMember(dest => dest.ReasonDetails, opt => opt.MapFrom(src => new ReasonDetails 
            { 
                Reason = src.careCordinationRequest.ccReason, StartOfCareDate = src.careCordinationRequest.socDate 
            }))
            .ForMember(dest => dest.Requester, opt => opt.MapFrom(src => new Requester 
            { 
                FirstName = string.Empty //src.careCordinationRequest.caseManagerName 
            }))
            .ForMember(dest => dest.RequestedServiceDate, opt => opt.MapFrom(src => src.careCordinationRequest.socDate))
            .ForMember(dest => dest.MemberPolicy, opt => opt.MapFrom(src => new MemberPolicyModel
            {
                MemberId = src.careCordinationRequest.member.memberID,
                InsuranceCarrierKey = src.careCordinationRequest.member.memberPolicy.insurer,
            }))
            .ForMember(dest => dest.ProcedureCodes, opt => opt.MapFrom(src => src.careCordinationRequest.procedure))
            .ForMember(dest => dest.Providers, opt => opt.MapFrom(src => new List<Provider>
            {
                new Provider { FirstName = src.careCordinationRequest.servicingProvider.physicianName }
            }))
            .ForMember(dest => dest.Insurer, opt => opt.MapFrom(src => new Insurer
            {
                InsuranceCarrierName = src.careCordinationRequest.member.memberPolicy.insurer ?? string.Empty,
                InsuranceCarrierDisplayName = src.careCordinationRequest.member.memberPolicy.insurer ?? string.Empty
            }))
            .ForMember(dest => dest.RequestedServices, opt => opt.MapFrom(src => new RequestedServices
            {
                Program = src.careCordinationRequest.member.memberPolicy.program ?? string.Empty
            }));

            CreateMap<Procedure, ProcedureCode>()
            .ForMember(dest => dest.Name, opt => opt.MapFrom(src => src.procedureCode))
            .ForMember(dest => dest.SimplifiedDescription, opt => opt.MapFrom(src => src.procedureCodeDescription));
        }
    }
}

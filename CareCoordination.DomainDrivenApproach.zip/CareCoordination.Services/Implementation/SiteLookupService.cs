﻿using CareCoordination.Application.Abstracts.ServiceInterfaces;
using CareCoordination.Application.Models.SiteRequestModels;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System.Diagnostics.CodeAnalysis;
using CareCoordination.Application.Abstracts.DALInterfaces;
using CareCoordination.Application.Models;
using System.Reflection;
using CareCoordination.Domain.Constants;
using CareCoordination.Domain.Models;
using AutoMapper;

namespace CareCoordination.Services.Implementation
{
    public class SiteLookupService : ISiteLookupService
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly ISiteRepository _siteRepository;
        private readonly string memberEligibilityUpadsRequestUrl;
        private readonly string PhysicianlookupUrl;
        private readonly IMapper _mapper;


        public SiteLookupService(IConfiguration config, IHttpClientFactory httpClientFactory,ISiteRepository siteRepository, IMapper mapper)
        {
            IConfiguration _config;
            _config = config;
            _httpClientFactory = httpClientFactory;
            _siteRepository = siteRepository;
            memberEligibilityUpadsRequestUrl = _config.GetSection("MemberEligibility:MemberEligibilityUpadsRequestUrl")?.Value ?? string.Empty;
            PhysicianlookupUrl = _config.GetSection("PhysicianLookup:PhysicianlookupUrl")?.Value ?? string.Empty;
            _mapper = mapper;
        }

        [ExcludeFromCodeCoverage]
        public async Task<SiteSearchResponse> GetSiteDetails(GetSiteDetailsRequestModel request)
        {
            var resp = _siteRepository.GetDetailsForSiteLookupRequestModel(request.RequestId ?? string.Empty);
            resp.PatientIPA = request.MemberIPA ?? string.Empty;
            ProviderNetworkingRulesRequestModel req = CreateProvidingNetworkingRuleRequest(resp);
            ProviderNetworkRulesResponse pnrResponse = await CallPNRPathway(req);
            GetSitesRequestModel getSitesRequestModel = new GetSitesRequestModel()
            {
                MbrZip = resp.PatientZip,
                Carrier = resp.HealthPlan,
                CPTCode = resp.CptCode,
                MemberIPA = request.MemberIPA ?? string.Empty,
                PatientEntity = resp.PatientEntity,
                MemberPlanType = resp.PatientPlanType,
                SiteID = string.Empty,
                SiteName = string.IsNullOrEmpty(request.ProviderName) ? string.Empty : "%" + request.ProviderName + "%",
                SiteCity = request.ProviderCity,
                SiteZip = request.ProviderZip,
                AltID = string.IsNullOrEmpty(request.ProviderNPI) ? request.ProviderTIN : request.ProviderNPI,
                PatientPlanCode = string.Empty,
                SiteState = string.Empty,
                CaseProviderTypeID = 0,
                AllEntity = string.Empty,
                AllIPACode = request.ProviderEligibilityType == "OON" ? "All" : string.Empty,
                PatPUSRDF = string.Empty,
                ssnum = string.Empty,
                NetworkId = string.Empty
            };
            var sites = await _siteRepository.GetSites(getSitesRequestModel);
            var sitesConverted = ConvertAndSetNetworkTypeForSite(sites, pnrResponse);
            var physicianDetails = new List<SearchResult>();
            if (resp.CompanyId == Constants.SleepCompanyId && request.ProviderEligibilityType == "INN")
            {
                physicianDetails = await GetPhysicianDetails(pnrResponse, resp, request);
            }

            return new SiteSearchResponse
            {
                SearchResults = ((sitesConverted ?? Enumerable.Empty<SearchResult>()).Concat(physicianDetails ?? Enumerable.Empty<SearchResult>())).ToList(),
                IsSuccess = true,
                Error = new Error(),
                Status = request.ProviderEligibilityType ?? string.Empty
            };
        }

        public List<SearchResult> ConvertAndSetNetworkTypeForSite(List<GetSitesResponse> sites, ProviderNetworkRulesResponse pnrResponse)
        {
            var sitesConverted = _mapper.Map<List<SearchResult>>(sites);

            var sitePPSRTF = SplitAndTrim(pnrResponse.SiteHCNTRPPPSTRFIncluded);
            var siteIPA = SplitAndTrim(pnrResponse.SiteIPAIncluded);
            var includes = SplitAndTrim(pnrResponse.SiteHPSAIPPRVGRNIncluded);
            var excludes = SplitAndTrim(pnrResponse.SiteHPSAIPPRVGRNExcluded);

            foreach (var site in sitesConverted)
            {
                site.SiteType = DetermineSiteType(site, sitePPSRTF, siteIPA, includes, excludes);
            }
            return sitesConverted;
        }

        private static IEnumerable<string> SplitAndTrim(string? input)
        {
            return string.IsNullOrWhiteSpace(input)
            ? Enumerable.Empty<string>()
            : input.Split(';').Select(id => id.Trim());
        }

        private static string DetermineSiteType(SearchResult site, IEnumerable<string> sitePPSRTF, IEnumerable<string> siteIPA,
        IEnumerable<string> includes, IEnumerable<string> excludes)
        {
            if (sitePPSRTF.Contains(site.PPSTRF) && siteIPA.Contains(site.MemberIPACode))
            {
                var listNetworkIds = string.IsNullOrEmpty(site.NetworkIds)
                ? Enumerable.Empty<string>()
                : site.NetworkIds.Split(',').Select(id => id.Trim());

                bool includeValid = !includes.Any() || includes.Any(id => listNetworkIds.Contains(id));
                bool excludeValid = !excludes.Any() || excludes.Any(id => !listNetworkIds.Contains(id));

                if (includeValid && excludeValid)
                    return Constants.ProviderNetworkTypeINN;
            }

            if (site.PROVIDER_PAR_FLAG == "N" || site.PPSTRF == "5" || string.IsNullOrEmpty(site.NetworkIds))
                return Constants.ProviderNetworkTypeNonPar;

            return Constants.ProviderNetworkTypeOON;
        }

        public string UpsertSiteDetails(UpdateSiteDetailsRequestModel updateSiteDetailsRequestModel)
        {
            return _siteRepository.UpsertSiteDetails(updateSiteDetailsRequestModel);
        }

        public async Task<ProviderNetworkRulesResponse> CallPNRPathway(ProviderNetworkingRulesRequestModel request)
        {
            List<string> queryParams = request.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance)
                .Where(p => p.GetValue(request) != null)
                .Select(p => $"{p.Name}={p.GetValue(request)}").ToList();

            string queryString = string.Join("&", queryParams);
            string fullUrl = $"{memberEligibilityUpadsRequestUrl}?{queryString}";

            var client = _httpClientFactory.CreateClient();
            HttpResponseMessage response = await client.GetAsync(fullUrl);

            response.EnsureSuccessStatusCode();
            string result = await response.Content.ReadAsStringAsync();

            if (string.IsNullOrEmpty(result))
            {
                throw new ArgumentException("Empty response from pathway");
            }

            var ruleset = JsonConvert.DeserializeObject<ProviderNetworkRulesResponse>(result);
            if (ruleset != null)
            {
                return ruleset; 
            }
            else
            {
                throw new JsonException("Deserialize object is null");
            }
        }

        public ProviderNetworkingRulesRequestModel CreateProvidingNetworkingRuleRequest(CaseDetailsEntity req)
        {
            var result = new ProviderNetworkingRulesRequestModel
            {
                ReviewType = Constants.PNRReviewType,
                LookupType = "Both",
                CompanyID = req.CompanyId.ToString(),
                GroupNumber = req.GroupNumber ?? string.Empty,
                MemberIPACode = req.PatientIPA ?? string.Empty,
                Modality = req.Modality,
                CPTCode = req.CptCode,
                InsCarrier = req.HealthPlan,
                ClientSystem = Constants.WorkFlow,
                InsPlanType = string.Empty,
                PatientID = req.PatientID,
                PatientDOB = req.PatientDOB,
                PatientFName = string.Empty,
                PatientLName = string.Empty,
                PatientState = req.PatientState,
                MemberNetworkCode = string.Empty,
                Workflow = Constants.WorkFlow
            };
            return result;
        }
        public async Task<List<SearchResult>> GetPhysicianDetails(ProviderNetworkRulesResponse PNRResponse, CaseDetailsEntity request, GetSiteDetailsRequestModel siteRequest)
        {
            PhysicianLookupRequestModel physicianLookup = new PhysicianLookupRequestModel();
            physicianLookup.PhySrch = "Y";
            physicianLookup.NonParFlag = "N";
            physicianLookup.FullCarrier=request.HealthPlan;
            physicianLookup.CompanyId = request.CompanyId.ToString();
            physicianLookup.PatEntity= request.PatientEntity;
            physicianLookup.PatPlanType = request.PatientPlanType;
            physicianLookup.PhysID = string.Empty;
            physicianLookup.PhysName= siteRequest.ProviderName;
            physicianLookup.PhysZip=siteRequest.ProviderZip;
            physicianLookup.PhysCity= siteRequest.ProviderCity;
            physicianLookup.IPACode = string.Empty;
            physicianLookup.AltID= siteRequest.ProviderNPI;
            physicianLookup.CSNSearch = "N";
            physicianLookup.InsertingApplication = "3";
            physicianLookup.UserName = string.Empty;
            physicianLookup.GroupNumber = request.GroupNumber;
            physicianLookup.TS = DateTime.Now;
            physicianLookup.IsRequestingProvider = false;
            physicianLookup.Steerage = PNRResponse.PhysicianHCNTRPPPSTRFIncluded;
            physicianLookup.MemberIPAs = PNRResponse.PhysicianIPAIncluded;
            physicianLookup.ExcludedNetworkIDs = PNRResponse.PhysicianHPSAIPPRVGRNExcluded;
            physicianLookup.IncludedNetworkIDs = PNRResponse.PhysicianHPSAIPPRVGRNIncluded;

            List<string> queryParams = physicianLookup.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance)
                .Where(p => p.GetValue(physicianLookup) != null)
                .Select(p => $"{p.Name}={Uri.EscapeDataString(p.GetValue(physicianLookup)?.ToString()?? string.Empty)}").ToList();

            string queryString = string.Join("&", queryParams);
            string fullUrl = $"{PhysicianlookupUrl}?{queryString}";

            var client = _httpClientFactory.CreateClient();
            HttpResponseMessage response = await client.GetAsync(fullUrl);

            response.EnsureSuccessStatusCode();
            string result = await response.Content.ReadAsStringAsync();

            if (string.IsNullOrEmpty(result))
            {
                return new List<SearchResult>();
            }

            List<SearchResult> searchResults = result.Split('|').Select(record =>
            {
                var parts = record.Split('*');
                
                return new SearchResult
                {
                    PRVNO = parts.ElementAtOrDefault(0) ?? string.Empty,
                    APRNO = parts.ElementAtOrDefault(1) ?? string.Empty,
                    PhysicianName = parts.ElementAtOrDefault(2) ?? string.Empty,
                    PADD1 = parts.ElementAtOrDefault(3) ?? string.Empty,
                    PCITY = parts.ElementAtOrDefault(4) ?? string.Empty,
                    PADD2 = parts.ElementAtOrDefault(5) ?? string.Empty,
                    PSTAT = parts.ElementAtOrDefault(6) ?? string.Empty,
                    PAZIP = parts.ElementAtOrDefault(7) ?? string.Empty,
                    PPHON = parts.ElementAtOrDefault(8) ?? string.Empty,
                    PFAX = parts.ElementAtOrDefault(9) ?? string.Empty,

                    CONTRACT_EFFECTIVE_DATE = decimal.TryParse(parts.ElementAtOrDefault(13), out var val13) ? val13 : 0,
                    CONTRACT_TERM_DATE = decimal.TryParse(parts.ElementAtOrDefault(14), out var val14) ? val14 : 0,
                    MDPRV = parts.ElementAtOrDefault(15) ?? string.Empty,
                    PSMID = parts.ElementAtOrDefault(16) ?? string.Empty,
                    FFS_VENDOR = parts.ElementAtOrDefault(17) ?? string.Empty,
                    GROUP_CARRIER = parts.ElementAtOrDefault(18) ?? string.Empty,
                    PLAN_TYPE = parts.ElementAtOrDefault(19) ?? string.Empty,
                    PROVIDER_ATTRIBUTE = parts.ElementAtOrDefault(20) ?? string.Empty,
                    PUSRDF = parts.ElementAtOrDefault(21) ?? string.Empty,
                    NPI = parts.ElementAtOrDefault(22) ?? string.Empty,
                    MemberIPACode = parts.ElementAtOrDefault(23) ?? string.Empty,
                    SiteType = Constants.ProviderNetworkTypeINN,
                    //PPSTRF = "0"
                };
            }).Where(m => !(string.IsNullOrEmpty(m.PRVNO))).ToList();
            return searchResults;
        }
    }
}

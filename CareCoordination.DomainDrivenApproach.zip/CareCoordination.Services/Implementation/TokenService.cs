﻿using Jose;
using System.Text;
using System.IdentityModel.Tokens.Jwt;
using CareCoordination.Api.DTOs;
using CareCoordination.Application.Models;
using CareCoordination.Application.Abstracts.DALInterfaces;
using CareCoordination.Application.Abstracts.HandlerInterfaces;
using CareCoordination.Application.Abstracts.ServiceInterfaces;
using Microsoft.Extensions.Configuration;
using System.Security.Cryptography;
using Microsoft.AspNetCore.Mvc;
using CareCoordination.Domain.Constants;
using CareCoordination.Services.Helpers;

namespace CareCoordination.Services.Implementation
{
    public class TokenService: ITokenService
    {
        private readonly IConfiguration _configuration;
        private readonly ITokenRepository _tokenRepository;
        private readonly IUserManagement _userManagement;

        public TokenService(IConfiguration configuration, ITokenRepository tokenRepository, IUserManagement userManagement)
        {
            _configuration = configuration;
            _tokenRepository = tokenRepository;
            _userManagement = userManagement;
        }

        public string GenerateToken(string userName)
        {
            //Validate user from UserManagement
            var user = _userManagement.ValidateUser(userName);
            if(user == null)
            {
                return string.Empty;
            }

            //Generate Access Token
            var payload = new
            {
                sub = user.Username,
                role = user.Role,
                exp = DateTimeOffset.UtcNow.AddMinutes(Convert.ToDouble(_configuration["JwtSettings:AccessToknExpirationMinutes"])).ToUnixTimeSeconds()
            };
            string CertConfigSubject = _configuration["CertConfigSubject"] ?? throw new ArgumentException("CertConfigSubject missing.");
            var privateKeyPem = CertificateHelper.GetRSAPrivateKey(CertConfigSubject);
            var rsa = RSA.Create();
            rsa.ImportFromPem(privateKeyPem.ToCharArray());

            return JWT.Encode(payload,rsa,JwsAlgorithm.RS256);
        }

        private string GenerateRefreshToken()
        {
            return Guid.NewGuid().ToString();
        }

        public string ValidateToken(string token)
        {
            try
            {
                Dictionary<string,string> claimList = new Dictionary<string,string>();
                // Read the token
                var handler = new JwtSecurityTokenHandler();
                var jwtToken = handler.ReadJwtToken(token);
                // Extract claims
                var claims = jwtToken.Claims;

                foreach(var claim in claims)
                {
                    claimList.Add(claim.Type,claim.Value);
                }

                var refreshToken = GenerateRefreshToken();

                _tokenRepository.StoreRefreshToken(claimList["sub"],refreshToken);

                return refreshToken;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public bool ValidateRefreshToken(string userId,string refreshToken)
        {
            try
            {
                var storedToken = _tokenRepository.GetUserToken(userId,refreshToken);
                return storedToken != null && storedToken.Expiration >= DateTime.UtcNow && storedToken.RefreshToken == refreshToken;
            }
            catch(Exception)
            {
                throw;
            }
        }

        public TokenDetailsResponse RefreshTokens(string userName,string oldRefreshToken)
        {
            try
            {
                if(!(ValidateRefreshToken(userName, oldRefreshToken)))
                {
                    throw new UnauthorizedAccessException("Invalid or expired refresh token.");
                }

                TokenDetailsResponse result = new TokenDetailsResponse();
                result.AccessToken = GenerateToken(userName);
                result.RefreshToken = GenerateRefreshToken();
                _tokenRepository.StoreRefreshToken(userName,result.RefreshToken);
                return result;
            }
            catch(Exception)
            {
                throw;
            }
        }

        public TokenResponse GetUserToken(string userName,string refreshToken)
        {
            return _tokenRepository.GetUserToken(userName,refreshToken);
        }
    }
}

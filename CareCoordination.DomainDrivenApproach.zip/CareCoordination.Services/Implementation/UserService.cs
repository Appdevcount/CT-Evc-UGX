﻿using CareCoordination.Domain.Entities;
using CareCoordination.Application.Abstracts.DALInterfaces;
using CareCoordination.Application.Abstracts.ServiceInterfaces;

namespace CareCoordination.Services.Implementation
{
    public class UserService:IUserService
    {
        private readonly IUserRepository _userRepository;

        public UserService(IUserRepository userRepository) 
        {
            _userRepository = userRepository;
        }

        public User ValidateUser(string username)
        {
            return _userRepository.GetUserDetails(username);
        }
    }
}

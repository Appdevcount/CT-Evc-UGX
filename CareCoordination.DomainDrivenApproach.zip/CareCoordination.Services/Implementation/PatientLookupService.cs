﻿using CareCoordination.Application.Abstracts.ServiceInterfaces;
using CareCoordination.Application.Models;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics.CodeAnalysis;
using Microsoft.AspNetCore.Mvc;
using System.Reflection;

namespace CareCoordination.Services.Implementation
{
    public class PatientLookupService : IPatientLookupService
    {
        private readonly string memberProcedureEligibilityApimUrl;
        private readonly string memberProcedureEligibilityApimKey;
        private readonly string memberProcedureEligibilityApimName;
        private readonly string OcpApimSubscriptionKey;
        private readonly string memberEligibilityUpadsRequestUrl;

        private readonly IHttpClientFactory _httpClientFactory;

        [ExcludeFromCodeCoverage]
        public PatientLookupService(IConfiguration config, IHttpClientFactory httpClientFactory)
        {
            IConfiguration _config;
            _config = config;
            _httpClientFactory = httpClientFactory;
            memberProcedureEligibilityApimUrl = _config.GetSection("MemberProcedureEligibility:MemberProcedureEligibilityApimUrl")?.Value ?? string.Empty;
            memberProcedureEligibilityApimKey = _config.GetSection("MemberProcedureEligibility:MemberProcedureEligibilityApimKey")?.Value ?? string.Empty;
            memberProcedureEligibilityApimName = _config.GetSection("MemberProcedureEligibility:memberProcedureEligibilityApimName")?.Value ?? string.Empty;
            OcpApimSubscriptionKey = _config.GetSection("MemberProcedureEligibility:OcpApimSubscriptionKey")?.Value ?? string.Empty;
            memberEligibilityUpadsRequestUrl = _config.GetSection("MemberEligibility:MemberEligibilityUpadsRequestUrl")?.Value ?? string.Empty;
        }
        public async Task<List<PatientDetailsResponse>> GetMemberDetails(PatientLookupRequestModel request)
        {
            List<PatientDetailsResponse> patientlist = new List<PatientDetailsResponse>();
            string membersResult;

            var client = _httpClientFactory.CreateClient();
            client.Timeout = TimeSpan.FromSeconds(30);
            HttpContent content = new StringContent(JsonConvert.SerializeObject(request));
            content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
            content.Headers.Add(OcpApimSubscriptionKey, memberProcedureEligibilityApimKey);
            string fullUrl = memberProcedureEligibilityApimUrl + memberProcedureEligibilityApimName;

            HttpResponseMessage response = await client.PostAsync(fullUrl, content);
            if (response.IsSuccessStatusCode)
            {
                membersResult = await response.Content.ReadAsStringAsync();
                patientlist = JsonConvert.DeserializeObject<List<PatientDetailsResponse>>(membersResult) ?? new List<PatientDetailsResponse>();
            }
            
            return patientlist;
        }
        public async Task<List<MemberEligibilityResponseModel>>GetMemberEligibility(MemberEligibilityRequestModel request)
        {
            if (request?.Qualifiers == null)
            {
                throw new ArgumentException( "No Qualifiers Provided");
            }

            List<string> queryParams = request.Qualifiers.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance)
                .Where(p=>p.GetValue(request.Qualifiers) != null)
                .Select(p=>$"{p.Name}={p.GetValue(request.Qualifiers)}").ToList();

            if (!queryParams.Any())
            {
                throw new ArgumentException("No Valid qualifiers provided");
            }

            string queryString = string.Join("&", queryParams);
            string fullUrl = $"{memberEligibilityUpadsRequestUrl}?{queryString}";

                var client = _httpClientFactory.CreateClient();
                HttpResponseMessage response = await client.GetAsync(fullUrl);

                response.EnsureSuccessStatusCode();
                string result = await response.Content.ReadAsStringAsync();

                if (string.IsNullOrEmpty(result))
                {
                    throw new ArgumentException("Empty response from external API");
                }

                var eligibilityResponse = JsonConvert.DeserializeObject<MemberEligibilityResponseModel>(result);
                if (eligibilityResponse != null)
                {
                    return new List<MemberEligibilityResponseModel> { eligibilityResponse };
                }
                else
                {
                    throw new JsonException("Deserialize object is null");
                }

        }
    }
}

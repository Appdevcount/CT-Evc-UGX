﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordination.Services.Implementation
{
    [ExcludeFromCodeCoverage]
    public static class ClientCertificateHelper
    {
        public static X509Certificate2 GetX509Certificate2(IConfiguration config)
        {
            string name = config.GetSection("SecurityCert:StoreName").Value?.ToString() ?? string.Empty ;//  "TrustedPeople";//" 
            string location = config.GetSection("SecurityCert:StoreLocation").Value?.ToString() ?? string.Empty;// "LocalMachine";// 
            StoreName storeName = Enum.Parse<StoreName>(name ?? string.Empty);
            StoreLocation storeLocation = Enum.Parse<StoreLocation>(location ?? string.Empty);
            string? subjectName = config.GetSection("SecurityCert:SubjectName").Value?.ToString() ?? string.Empty;
            return ClientCertificateHelper.GetX509Certificate2(storeName, storeLocation, subjectName);
        }

        private static X509Certificate2 GetX509Certificate2(StoreName name, StoreLocation location, string subjectName)
        {
            X509Store store = new X509Store(name, location);
            try
            {
                store.Open(OpenFlags.ReadOnly);
                if (store.Certificates == null)
                {
                    throw new InvalidOperationException(string.Format("No certificate in store {0}", name));
                }

                var validCert =  store.Certificates.FirstOrDefault(x => string.Equals(x.SubjectName.Name, subjectName, StringComparison.OrdinalIgnoreCase) && DateTime.Parse(x.GetExpirationDateString()) >= DateTime.Now);
                if (validCert != null)
                {
                    return new X509Certificate2(validCert);
                }
                else 
                {
                    var isCertificateExpired = store.Certificates.FirstOrDefault(x => string.Equals(x.SubjectName.Name, subjectName, StringComparison.OrdinalIgnoreCase)) != null;
                    if (isCertificateExpired)
                    {
                        throw new InvalidOperationException(string.Format("The certificate is expired -  subject Name {0}", subjectName));
                    }
                    else 
                    {
                        throw new InvalidOperationException(string.Format("No certificate was found for subject Name {0}", store.Certificates?.FirstOrDefault()?.SubjectName.Name));
                    }
                }
            }
            finally
            {
                if (store.Certificates != null)
                {
                    foreach (X509Certificate2 certificate in store.Certificates)
                    {
                        certificate.Reset();
                    }

                }

                store.Close();
            }
        }
    }
}

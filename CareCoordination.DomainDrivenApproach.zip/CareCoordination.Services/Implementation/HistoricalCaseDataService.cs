﻿using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System.Net.Http.Headers;
using CareCoordination.Application.Abstracts.ServiceInterfaces;
using CareCoordination.Domain.Models.HistoricalCaseDataModels;
using System.Diagnostics.CodeAnalysis;
using CareCoordination.Application.Models;
using CareCoordination.Domain.Models;
using AutoMapper;

namespace CareCoordination.Services.Implementation
{
    [ExcludeFromCodeCoverage]
    public class HistoricalCaseDataService: IHistoricalCaseDataService
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly string authMigrationApiUrl;
        private readonly IMapper _mapper;

        public HistoricalCaseDataService(IConfiguration config,IHttpClientFactory httpClientFactory, IMapper mapper) 
        {
            IConfiguration _config;
            _config = config;
            _httpClientFactory = httpClientFactory;
            authMigrationApiUrl = _config.GetSection("AetnaAuth:AuthMigrationApiUrl")?.Value ?? string.Empty;
            _mapper = mapper;
        }

        public async Task<List<CareCoordinationHistoricalRequest>> GetHistoricalCaseData(GetHistoricalCaseDataRequestModel request)
        {
            List<Root> careCordinationRequest = new List<Root>();
            List<CareCoordinationHistoricalRequest> result = new List<CareCoordinationHistoricalRequest>();
            try
            {
                var client = _httpClientFactory.CreateClient();
                client.Timeout = TimeSpan.FromSeconds(30);
                HttpContent content = new StringContent(JsonConvert.SerializeObject(request));
                content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                string fullUrl = authMigrationApiUrl + "GetHistoricalCaseData";

                HttpResponseMessage httpResponse = await client.PostAsync(fullUrl, content);
                if (httpResponse.IsSuccessStatusCode)
                {
                    var response = await httpResponse.Content.ReadAsStringAsync();
                    careCordinationRequest = JsonConvert.DeserializeObject<List<Root>>(response) ?? new List<Root>();
                }
                result = _mapper.Map<List<CareCoordinationHistoricalRequest>>(careCordinationRequest);
            }
            catch(Exception ex)
            {
                throw;
            }
            return result;
        }
    }
}

﻿using CareCoordination.Application.Abstracts.ServiceInterfaces;
using CareCoordination.Application.Models;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordination.Services.Implementation
{
    public class ApiTokenCacheClient : IApiTokenCacheClient
    {
        private readonly ILogger<ApiTokenCacheClient> _applicationlogger;
        private static readonly Object _lock = new Object();
        private readonly IConfiguration _config;
        private readonly IMemoryCache _cache;
        private readonly IHttpClientFactory _httpClientFactory;

        public ApiTokenCacheClient(
            IConfiguration config,
            IMemoryCache cache,
            ILogger<ApiTokenCacheClient> applicationLogger, IHttpClientFactory httpClientFactory)
        {
            _config = config;
            _cache = cache;
            _applicationlogger = applicationLogger;
            _httpClientFactory = httpClientFactory;
        }

        public async Task<string?> GetApiToken(string api_name)
        {
            var accessToken = GetFromCache(api_name);

            if (accessToken != null && accessToken.ExpiresIn > DateTime.UtcNow)
            {
                return accessToken.Access_token;
            }
            else
            {
                _applicationlogger.LogInformation("Api token expired, MethodName: GetApiToken");

            }

            _applicationlogger.LogInformation("Addition of new Api token started, MethodName: GetApiToken, Api Name: {api_name}", api_name);

            var newAccessToken = await GetOAuthToken(api_name);

            AddToCache(api_name, newAccessToken);

            _applicationlogger.LogInformation("Addition of new Api token successful, MethodName: GetApiToken, Api Name: {api_name}", api_name);

            return newAccessToken?.Access_token;
        }

        public Dictionary<string, string> CreateOAuthTokenFetchHeaders(string api_name)
        {
            _applicationlogger.LogInformation("Creation of new OAuth token headers started, MethodName: CreateOAuthTokenFetchHeaders, Api Name: {api_name}", api_name);

            OAuthTokenFetchHeaders HeadersFromConfig = new OAuthTokenFetchHeaders
            {
                AccessTokenURL = _config.GetSection("OAuthSettings:OV:AccessTokenUrl").Value,
                ScopeURL = api_name == "OVAccessToken" ? _config.GetSection("OAuthSettings:OV:ScopeUrl").Value ?? String.Empty :
                _config.GetSection("OAuthSettings:OV:UPADSScopeUrl").Value ?? String.Empty,
                GrantType = "client_credentials",
                ClientID = _config.GetSection("OAuthSettings:OV:ClientId").Value ?? String.Empty,
                ClientSecret = _config.GetSection("OAuthSettings:OV:ClientSecret").Value ?? String.Empty,
            };
            Dictionary<string, string> oAuthData = new Dictionary<string, string>();
            oAuthData.Add("grant_type", HeadersFromConfig.GrantType);
            oAuthData.Add("scope", HeadersFromConfig.ScopeURL);
            oAuthData.Add("client_id", HeadersFromConfig.ClientID);
            oAuthData.Add("client_secret", HeadersFromConfig.ClientSecret);

            _applicationlogger.LogInformation("Creation of new OAuth token headers ended, MethodName: CreateOAuthTokenFetchHeaders, Api Name: {api_name}", api_name);

            return oAuthData;

        }
        public async Task<AccessTokenItem?> GetOAuthToken(string api_name)
        {
            var client = _httpClientFactory.CreateClient();
            client.Timeout = TimeSpan.FromSeconds(30);

            AccessTokenItem? oauthResult = null;

            _applicationlogger.LogInformation("creation of new OAuth token started, MethodName: GetOAuthToken, Api Name: {api_name}", api_name);

            Dictionary<string, string> oAuthData = CreateOAuthTokenFetchHeaders(api_name);
            string AccessTokenURL = _config.GetSection("OAuthSettings:OV:AccessTokenUrl").Value ?? String.Empty;
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            HttpResponseMessage response = client.PostAsync(AccessTokenURL, new FormUrlEncodedContent(oAuthData)).Result;
            if (response.IsSuccessStatusCode)
            {
                string resultAsString = await response.Content.ReadAsStringAsync();
                oauthResult = JsonConvert.DeserializeObject<AccessTokenItem>(resultAsString) ?? new AccessTokenItem();
                oauthResult.ExpiresIn = DateTime.UtcNow.AddSeconds(oauthResult.Expires_in);

                _applicationlogger.LogInformation("GetOAuthToken response successful, MethodName: GetOAuthToken, Api Name: {api_name}", api_name);
            }

            return oauthResult;
        }

        private void AddToCache(string key, AccessTokenItem? accessTokenItem)
        {
            var cacheExpiryOptions = new MemoryCacheEntryOptions
            {
                AbsoluteExpiration = DateTime.Now.AddHours(1),
                SlidingExpiration = TimeSpan.FromMinutes(10),
                Priority = CacheItemPriority.High
            };
            lock (_lock)
            {
                _cache.Set(key, accessTokenItem, cacheExpiryOptions);
            }
        }

        private AccessTokenItem? GetFromCache(string key)
        {
            var value = _cache.Get(key);
            if (value != null)
            {
                _applicationlogger.LogInformation("Data fetched from Cache successful, MethodName: GetFromCache");
                return (AccessTokenItem)value;
            }
            return null;
        }

        public async Task<AccessTokenItem?> GetApiCompleteToken(string api_name)
        {

            var accessToken = GetFromCache(api_name);

            if (accessToken != null && accessToken.ExpiresIn > DateTime.UtcNow)
            {
                return accessToken;
            }
            _applicationlogger.LogInformation("Addition of new Api token started, MethodName: GetApiCompleteToken, Api Name: {api_name}", api_name);

            var newAccessToken = await GetOAuthToken(api_name);
            AddToCache(api_name, newAccessToken);

            _applicationlogger.LogInformation("Addition of new Api token ended, MethodName: GetApiCompleteToken, Api Name: {api_name}", api_name);

            return newAccessToken;
        }

    }
}
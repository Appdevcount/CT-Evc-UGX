﻿using CareCoordination.Application.Abstracts.ServiceInterfaces;
using CareCoordination.Application.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using System.Net.Http.Headers;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GeneralDataService;
using CareCoordination.Domain.Constants;
using System.Net.Http;
using CareCoordination.Domain.Models;
using System.Diagnostics.CodeAnalysis;
using CareCoordination.Application.Abstracts.DALInterfaces;


namespace CareCoordination.Services.Implementation
{
    [ExcludeFromCodeCoverage]
    public class FileHandler : IFileHandler
    {
        readonly GeneralDataService.GeneralDataService1_2SoapClient gds = new GeneralDataService.GeneralDataService1_2SoapClient(GeneralDataService.GeneralDataService1_2SoapClient.EndpointConfiguration.GeneralDataService1_2Soap12);
        private readonly IConfiguration config;
        private readonly IApiTokenCacheClient apiTokenCacheClient;
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly IAttachmentDetails _attachmentDetails;


        public FileHandler(IConfiguration configuration, IApiTokenCacheClient apiTokenCacheClient, IHttpClientFactory httpClientFactory,IAttachmentDetails attachmentDetails)
        {
            config = configuration;
            this.apiTokenCacheClient = apiTokenCacheClient;
            _httpClientFactory = httpClientFactory;
            _attachmentDetails = attachmentDetails;
        }


        public UploadedFilePropertiesModel? PostToOVEndpoint(UploadedFileModel uploadedFile,HttpContext httpContext)
        {
            var client = _httpClientFactory.CreateClient();
            client.Timeout = TimeSpan.FromSeconds(30);
            UploadedFilePropertiesModel? res = null;
            string AccessTokenURLAsKey = "OVAccessToken";
            var token = apiTokenCacheClient.GetApiToken(AccessTokenURLAsKey).GetAwaiter().GetResult();

            if (!string.IsNullOrEmpty(token))
            {
                IFormFile? file = uploadedFile.file;

                string FileNameWithoutSpecialCharacters = RemoveSpecialCharacters(file?.FileName ?? "");

                string AMSPostURL = config.GetSection("OAuthSettings:OV:AMSPost").Value ?? string.Empty;

                HttpClientHandler handler = new HttpClientHandler();
                handler.ClientCertificateOptions = ClientCertificateOption.Manual;
                handler.ClientCertificates.Add(ClientCertificateHelper.GetX509Certificate2(config));

                var request = new HttpRequestMessage()
                {
                    RequestUri = new Uri(AMSPostURL),
                    Method = HttpMethod.Post
                };
                string ObjectValetApplication = config.GetSection("OAuthSettings:OV:ObjectValetApplication").Value ?? string.Empty;
                string SystemOfRecord = config.GetSection("OAuthSettings:OV:SystemOfRecord").Value ?? string.Empty;
                string ObjectClass = config.GetSection("OAuthSettings:OV:ObjectClass").Value ?? string.Empty;
                request.Headers.Add("ObjectValetApplication", ObjectValetApplication);
                request.Headers.Add("SystemOfRecord", SystemOfRecord);
                request.Headers.Add("SystemOfRecordContextKey", uploadedFile.EpisodeId);
                request.Headers.Add("ObjectClass", ObjectClass);
                request.Headers.Add("Filename", FileNameWithoutSpecialCharacters);
                request.Headers.Add("Description", String.Concat(FileNameWithoutSpecialCharacters,'|',Guid.NewGuid()));
                request.Headers.Add("CreatedBy", uploadedFile.UserName);
                request.Headers.Add("Authorization", "Bearer " + token);

                Stream uploadfilestream = file?.OpenReadStream() ?? Stream.Null;
                var streamContent = new StreamContent(uploadfilestream);
                streamContent.Headers.ContentType = new MediaTypeHeaderValue("application/octet-stream");
                request.Content = streamContent;

                HttpResponseMessage response = client.SendAsync(request).Result;
                if (response.IsSuccessStatusCode)
                {
                    string resultAsString = response.Content.ReadAsStringAsync().Result;
                    if (!string.IsNullOrEmpty(resultAsString))
                    {
                        res = JsonConvert.DeserializeObject<UploadedFilePropertiesModel>(resultAsString);
                        gds.InsertFileuploadTrackingAsync(uploadedFile.EpisodeId, res?.AMSObjectValetId ?? Guid.Empty, uploadedFile.Filename, Path.GetExtension(uploadedFile.Filename), uploadedFile.UserName, GetClientIP(httpContext),Constants.WorkFlow, FileUploadStatus.New);
                    }
                }
                
            }
            return res;
        }
        [ExcludeFromCodeCoverage]
        public static string GetClientIP(HttpContext httpContext)
        {
            try
            {
                string clientIP = httpContext.Request.Headers["X-Forwarded-For"].FirstOrDefault()!;

                if (string.IsNullOrWhiteSpace(clientIP) || clientIP.ToLower() == "unknown")
                {
                    clientIP = httpContext.Connection.RemoteIpAddress?.ToString()!;
                }

                return clientIP ?? string.Empty;
            }
            catch
            {
                return string.Empty;
            }
        }

        public List<UploadedFileDataModel>? GetListOfObjects(string EpisodeId)
        {
            var client = _httpClientFactory.CreateClient();
            client.Timeout = TimeSpan.FromSeconds(30);

            List<UploadedFileDataModel>? uploadedfiles = null;
            string AccessTokenURLAsKey = "OVAccessToken";
            var token = apiTokenCacheClient.GetApiToken(AccessTokenURLAsKey).Result;

            if (!string.IsNullOrEmpty(token))
            {
                string GetListOfObjects = config.GetSection("OAuthSettings:OV:GetListOfObjects").Value ?? string.Empty;

                HttpClientHandler handler = new HttpClientHandler();
                handler.ClientCertificateOptions = ClientCertificateOption.Manual;
                handler.ClientCertificates.Add(ClientCertificateHelper.GetX509Certificate2(config));

                var request = new HttpRequestMessage()
                {
                    RequestUri = new Uri(GetListOfObjects),
                    Method = HttpMethod.Get
                };
                string ObjectValetApplication = config.GetSection("OAuthSettings:OV:ObjectValetApplication").Value ?? string.Empty;
                string SystemOfRecord = config.GetSection("OAuthSettings:OV:SystemOfRecord").Value ?? string.Empty;
                string ObjectClass = config.GetSection("OAuthSettings:OV:ObjectClass").Value ?? string.Empty;
                request.Headers.Add("ObjectValetApplication", ObjectValetApplication);
                request.Headers.Add("SystemOfRecord", SystemOfRecord);
                request.Headers.Add("SystemOfRecordContextKey", EpisodeId);
                request.Headers.Add("ObjectClass", ObjectClass);
                request.Headers.Add("Authorization", "Bearer " + token);


                HttpResponseMessage response = client.SendAsync(request).Result;
                if (response.IsSuccessStatusCode)
                {
                    string resultAsString = response.Content.ReadAsStringAsync().Result;
                    uploadedfiles = JsonConvert.DeserializeObject<List<UploadedFileDataModel>>(resultAsString);

                }
                
            }
            return uploadedfiles;
        }



        public async Task<DownloadFilePropertiesModel?> GetFileByObjectId(long ObjectId)
        {
            var client = _httpClientFactory.CreateClient();
            client.Timeout = TimeSpan.FromSeconds(30);

            DownloadFilePropertiesModel? fileToReturn = null;
            string AccessTokenURLAsKey = "OVAccessToken";
            var token = await apiTokenCacheClient.GetApiToken(AccessTokenURLAsKey);

            if(!string.IsNullOrEmpty(token))
            {
                var GetFileByObjectId = config.GetSection("OAuthSettings:OV:GetFileByObjectId").Value;

                HttpClientHandler handler = new HttpClientHandler
                {
                    ClientCertificateOptions = ClientCertificateOption.Manual
                };
                handler.ClientCertificates.Add(ClientCertificateHelper.GetX509Certificate2(config));

                var request = new HttpRequestMessage
                {
                    RequestUri = new Uri(GetFileByObjectId + ObjectId.ToString()),
                    Method = HttpMethod.Get
                };
                var ObjectValetApplication = config.GetSection("OAuthSettings:OV:ObjectValetApplication").Value;
                request.Headers.Add("ObjectValetApplication",ObjectValetApplication);
                request.Headers.Add("Authorization","Bearer " + token);

                try
                {
                    HttpResponseMessage response = await client.SendAsync(request);
                    if(response.IsSuccessStatusCode)
                    {
                        var cts = new CancellationTokenSource(TimeSpan.FromSeconds(30));
                        fileToReturn = new DownloadFilePropertiesModel
                        {
                            FileStreamContent = await response.Content.ReadAsStreamAsync(cts.Token),
                            FileName = response.Content.Headers.ContentDisposition?.FileName
                        };
                    }
                }
                catch(Exception ex)
                {
                    // Log the exception or handle it as needed
                    Console.WriteLine($"Error: {ex.Message}");
                }
            }
            return fileToReturn;
        }

      public async Task<DeleteFilePropertiesModel> DeleteFile(DeleteFilePropertiesViewModel deleteFilePropertiesViewModel)
        {
            var client = _httpClientFactory.CreateClient();
            client.Timeout = TimeSpan.FromSeconds(30);

            DeleteFilePropertiesModel? fileStatus = new();
            string AccessTokenURLAsKey = "OVAccessToken";
            var token = apiTokenCacheClient.GetApiToken(AccessTokenURLAsKey).Result;

            if (!string.IsNullOrEmpty(token))
            {

                var GetFileByObjectId = config.GetSection("OAuthSettings:OV:GetFileByObjectId").Value;

                HttpClientHandler handler = new HttpClientHandler();
                handler.ClientCertificateOptions = ClientCertificateOption.Manual;
                handler.ClientCertificates.Add(ClientCertificateHelper.GetX509Certificate2(config));

                var request = new HttpRequestMessage()
                {
                    RequestUri = new Uri(GetFileByObjectId + deleteFilePropertiesViewModel.ObjectId.ToString()),
                    Method = HttpMethod.Delete
                };
                var ObjectValetApplication = config.GetSection("OAuthSettings:OV:ObjectValetApplication").Value;
                request.Headers.Add("ObjectValetApplication", ObjectValetApplication);
                request.Headers.Add("Authorization", "Bearer " + token);

                HttpResponseMessage response = client.SendAsync(request).Result;
                if (response.IsSuccessStatusCode)
                {
                   bool IsFileMetaDataDeleted;
                    if(response.IsSuccessStatusCode)
                    {
                        IsFileMetaDataDeleted = await _attachmentDetails.DeleteAttachmentDetails(deleteFilePropertiesViewModel);

                        fileStatus.IsDeleted = IsFileMetaDataDeleted;

                        if(!IsFileMetaDataDeleted)
                        {
                            fileStatus.Error = "File Deleted from Object Valet but unable to delete from database";
                        }
                    }
                }
                else 
                { 
                    fileStatus = new DeleteFilePropertiesModel 
                        {
                            IsDeleted = false,
                            Error = "Failed to delete the file"
                        };
                }
                
            }
            return fileStatus;

        }

        public static string RemoveSpecialCharacters(string str)
        {
            StringBuilder sb = new StringBuilder();
            foreach (char c in str)
            {
                if ((c >= '0' && c <= '9') || (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || c == '_' || c == '.' || c == ' ')
                {
                    if (c == ' ')
                        sb.Append('_');
                    else
                        sb.Append(c);
                }
            }
            return sb.ToString();
        }


        
            }
    
}

﻿using AutoMapper;
using CareCoordination.Api.Controllers;
using CareCoordination.Application.Abstracts.HandlerInterfaces;
using CareCoordination.Application.Logger;
using CareCoordination.Application.Models;
using CareCoordination.Domain.Models.HistoricalCaseDataModels;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System.Net;
using Xunit;

namespace CareCoordination.Tests.Controllers
{
    public class HistoricalCaseControllerTest
    {
        private readonly Mock<IApplicationLogger> _logger;
        private readonly Mock<IHistoricalCaseDataManagement> _dataManagement;
        private readonly HistoricalCaseController _controller;
        private readonly Mock<IMapper> _mapper;

        public HistoricalCaseControllerTest()
        {
            _logger = new Mock<IApplicationLogger>();
            _dataManagement = new Mock<IHistoricalCaseDataManagement>();
            _mapper = new Mock<IMapper>();
            _controller = new HistoricalCaseController(_logger.Object, _dataManagement.Object, _mapper.Object);
        }

        [Fact]
        public async Task GetHistoricalCaseData_calls_return200()
        {
            //Arrange
            GetHistoricalCaseDataRequestModel request = new GetHistoricalCaseDataRequestModel { requestId = "CC00000001" };

            var response = new List<CareCoordinationHistoricalRequest>
            {
                new CareCoordinationHistoricalRequest
                {
                    RequestForCareCoordinationKey = "REQ123",
                    CareCoordinationId = "CC00000001",
                    RequestedServiceDate = new DateTime(2025, 7, 4),
                    DateOfClosing = new DateTime(2025, 7, 10),
                    RequestedServices = new RequestedServices
                    {
                        Program = "HomeCare",
                        ServicePlaceCode = "11",
                        ServicePlace = "Home",
                        ServicePlaceFullName = "Patient's Home",
                        ServiceTypes = new List<ServiceType>
                        {
                            new ServiceType { ServiceTypeId = "ST001", ServiceTypeName = "Nursing" }
                        }
                    },
                    MemberPolicy = new MemberPolicyModel
                    {
                        InsuranceCarrierKey = "INS789",
                        MemberPolicyKey = "MPKEY001",
                        MemberId = "MEM123",
                        Gender = "Female",
                        FirstName = "Jane",
                        LastName = "Doe",
                        DateOfBirth = new DateTime(1985, 5, 20),
                        AddressLine1 = "123 Main St",
                        City = "NeyYork",
                        StateCode = "NY",
                        ZipCode = "10001",
                        GroupNumber = "GRP456",
                        PrimaryLanguage = "English",
                        IsMemberQuickCreate = false,
                        IsMemberEligible = true
                    },
                    Providers = new List<Provider>
                    {
                        new Provider
                        {
                            FirstName = "John",
                            LastName = "Smith",
                            Phone = "1234567890",
                            City = "NeyYork",
                            StateCode = "NY",
                            Zip = "10001",
                            OrganizationName = "HealthCare Inc.",
                            ProviderType = "Physician",
                            IsParticipatingProvider = true
                        }
                    },
                    ProcedureCodes = new List<ProcedureCode>
                    {
                        new ProcedureCode
                        {
                            Name = "PROC001",
                            SimplifiedDescription = "Initial Consultation",
                            Units = "1"
                        }
                    },
                    Requester = new Requester
                    {
                        FirstName = "Alice",
                        LastName = "Johnson",
                        PhoneNumber = "9876543210",
                        Email = "alice.johnson@example.com",
                        Facility = "Care Facility A"
                    },
                    ReasonDetails = new ReasonDetails
                    {
                        Reason = "Post-surgery care",
                        Notes = "Patient requires daily nursing",
                        StartOfCareDate = new DateTime(2025, 7, 5)
                    },
                    Insurer = new Insurer
                    {
                        InsuranceCarrierName = "ABC Insurance",
                        InsuranceCarrierDisplayName = "ABC Health"
                    },
                    StatusDetails = new StatusDetails
                    {
                        Status = "Open",
                        Notes = "Awaiting provider assignment"
                    }
                }
                };

            _dataManagement.Setup(m => m.GetHistoricalCaseData(request)).ReturnsAsync(response);
            //Act
            var actualResult = await _controller.GetHistoricalCaseData(request);
            //Assert
            Assert.NotNull(actualResult);
        }

        [Fact]
        public async Task GetRequestDetailsById_calls_return500()
        {
            //Arrange
            GetHistoricalCaseDataRequestModel request = new GetHistoricalCaseDataRequestModel { requestId = "CC00000001" };
            _dataManagement.Setup(m => m.GetHistoricalCaseData(request)).Throws(new Exception());
            //Act
            var actualResult = await _controller.GetHistoricalCaseData(request) as ObjectResult;

            //Assert
            Assert.Equal((int)HttpStatusCode.InternalServerError, actualResult?.StatusCode);
        }

        [Fact]
        public async Task GetHistoricalCaseData_calls_return400()
        {
            //Arrange
            GetHistoricalCaseDataRequestModel request = new GetHistoricalCaseDataRequestModel { requestId = "" };
            //Act
            var actualResult = await _controller.GetHistoricalCaseData(request) as ObjectResult;

            //Assert
            Assert.Equal((int)HttpStatusCode.BadRequest, actualResult?.StatusCode);
        }
    }
}

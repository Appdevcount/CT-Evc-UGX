﻿using CareCoordination.Application.Abstracts.HandlerInterfaces;
using CareCoordination.Application.Abstracts.ServiceInterfaces;
using CareCoordination.Application.Handlers;
using CareCoordination.Application.Models;
using CareCoordination.Domain.Models.HistoricalCaseDataModels;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace CareCoordination.Tests.ApplictaionHandlers
{
    public class HistoricalCaseDataManagementTests
    {
        public readonly Mock<IHistoricalCaseDataService> _mockHistoricalCaseDataManagement;
        public readonly HistoricalCaseDataManagement _historicalCaseDataManagement;

        public HistoricalCaseDataManagementTests() 
        {
            _mockHistoricalCaseDataManagement = new Mock<IHistoricalCaseDataService>();
            _historicalCaseDataManagement = new HistoricalCaseDataManagement(_mockHistoricalCaseDataManagement.Object);
        }

        [Fact]
        public async Task GetHistoricalCaseData_ReturnCaseDetails()
        {
            //Arrange
            GetHistoricalCaseDataRequestModel request = new GetHistoricalCaseDataRequestModel { requestId = "CC00000001" };
            var response = new List<CareCoordinationHistoricalRequest>
            {
                new CareCoordinationHistoricalRequest
                {
                    RequestForCareCoordinationKey = "REQ123",
                    CareCoordinationId = "CC00000001",
                    RequestedServiceDate = new DateTime(2025, 7, 4),
                    DateOfClosing = new DateTime(2025, 7, 10),
                    RequestedServices = new RequestedServices
                    {
                        Program = "HomeCare",
                        ServicePlaceCode = "11",
                        ServicePlace = "Home",
                        ServicePlaceFullName = "Patient's Home",
                        ServiceTypes = new List<ServiceType>
                        {
                            new ServiceType { ServiceTypeId = "ST001", ServiceTypeName = "Nursing" }
                        }
                    },
                    MemberPolicy = new MemberPolicyModel
                    {
                        InsuranceCarrierKey = "INS789",
                        MemberPolicyKey = "MPKEY001",
                        MemberId = "MEM123",
                        Gender = "Female",
                        FirstName = "Jane",
                        LastName = "Doe",
                        DateOfBirth = new DateTime(1985, 5, 20),
                        AddressLine1 = "123 Main St",
                        City = "NeyYork",
                        StateCode = "NY",
                        ZipCode = "10001",
                        GroupNumber = "GRP456",
                        PrimaryLanguage = "English",
                        IsMemberQuickCreate = false,
                        IsMemberEligible = true
                    },
                    Providers = new List<Provider>
                    {
                        new Provider
                        {
                            FirstName = "John",
                            LastName = "Smith",
                            Phone = "1234567890",
                            City = "NeyYork",
                            StateCode = "NY",
                            Zip = "10001",
                            OrganizationName = "HealthCare Inc.",
                            ProviderType = "Physician",
                            IsParticipatingProvider = true
                        }
                    },
                    ProcedureCodes = new List<ProcedureCode>
                    {
                        new ProcedureCode
                        {
                            Name = "PROC001",
                            SimplifiedDescription = "Initial Consultation",
                            Units = "1"
                        }
                    },
                    Requester = new Requester
                    {
                        FirstName = "Alice",
                        LastName = "Johnson",
                        PhoneNumber = "9876543210",
                        Email = "alice.johnson@example.com",
                        Facility = "Care Facility A"
                    },
                    ReasonDetails = new ReasonDetails
                    {
                        Reason = "Post-surgery care",
                        Notes = "Patient requires daily nursing",
                        StartOfCareDate = new DateTime(2025, 7, 5)
                    },
                    Insurer = new Insurer
                    {
                        InsuranceCarrierName = "ABC Insurance",
                        InsuranceCarrierDisplayName = "ABC Health"
                    },
                    StatusDetails = new StatusDetails
                    {
                        Status = "Open",
                        Notes = "Awaiting provider assignment"
                    }
                }
                };

            _mockHistoricalCaseDataManagement.Setup(s => s.GetHistoricalCaseData(It.IsAny<GetHistoricalCaseDataRequestModel>())).ReturnsAsync(response);

            //Act
            var result = await _historicalCaseDataManagement.GetHistoricalCaseData(request);

            //Assert
            Assert.NotNull(result);
        }
    }
}

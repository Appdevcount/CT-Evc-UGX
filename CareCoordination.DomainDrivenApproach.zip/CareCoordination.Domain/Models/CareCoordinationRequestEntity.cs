﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordination.Domain.Models
{
    public class CareCoordinationRequestEntity
    {
        public string? CareCoordinationEpisodeId { get; set; }
        public string? CareCoordinationEpisodeDate { get; set; }
        public string? CaseStatus { get; set; }
        public string? RequesterFName { get; set; }
        public string? RequesterLName { get; set; }
        public string? RequesterContactNo { get; set; }
        public string? RequesterContactExt { get; set; }
        public string? RequesterFaxNo { get; set; }
        public string? RequesterFacility { get; set; }
        public string? RequesterEmailID { get; set; }
        public string? HealthPlan { get; set; }
        public int? CompanyId { get; set; }
        public string? Program { get; set; }
        public string? Reason { get; set; }
        public string? DateOfService { get; set; }
        public string? DateOfClosing { get; set; }
        public bool? IsEscalated { get; set; }
        public bool? StaffedRequest { get; set; }
        public string? SubServiceType { get; set; }
        public string? CaseManagerFName { get; set; }
        public string? CaseManagerLName { get; set; }
        public string? CaseManagerPhoneNo { get; set; }
        public string? CaseManagerExtention { get; set; }
        public string? CaseManagerEmail { get; set; }
        public string? CreatedBy { get; set; }
        public string? CreateDate { get; set; }
        public bool? MissedStartOfCare { get; set; }
        public string? MissedStartOfCareReason { get; set; }
        public string? FollowUpDate { get; set; }
        public string? FollowUpNotes { get; set; }
        public string? AssigneeEmailId { get; set; }
        public string? AssigneeName { get; set; }
        public string? AssigneeDate { get; set; }
        //member
        public string? PatientID { get; set; }
        public string? PatientMemberCode { get; set; }
        public string? PatientName { get; set; }
        public string? PatientDOB { get; set; }
        public string? GroupNumber { get; set; }
        public string? PlanType { get; set; }
        public string? LineOfBusiness { get; set; }
        public string? Language { get; set; }
        public string? PatientPlanType { get; set; }
        public string? PatientEntity { get; set; }
        public string? Category { get; set; }
        public string? PatientIPA { get; set; }
        public long? PatientIdent { get; set; }
        public string? Email { get; set; }
        public string? CellPhone { get; set; }
        public string? JurisdictionState { get; set; }
        public string? TIT19 { get; set; }
        public string? Calculated_PatientID_PatientMemberCode_GroupNumber { get; set; }
        public int? CaseFactor { get; set; }
        public string? PatientPUSRDF { get; set; }
        public string? FundType { get; set; }
        public string? ERISA { get; set; }
        public string? EXTID { get; set; }
        public string? MemberStartDate { get; set; }
        public bool? MemberQuickCreate { get; set; }
        public string? PatientSex { get; set; }
        public string? PatientAddr1 { get; set; }
        public string? PatientAddr2 { get; set; }
        public string? PatientState { get; set; }
        public string? PatientCity { get; set; }
        public string? PatientZip { get; set; }
        //Site 
        public string? OAOSiteID { get; set; }
        public string? NonParSiteID { get; set; }
        public string? OldSiteID { get; set; }
        public string? SiteName { get; set; }
        public string? SiteAddr1 { get; set; }
        public string? SiteAddr2 { get; set; }
        public string? SiteCity { get; set; }
        public string? SiteState { get; set; }
        public string? SiteZip { get; set; }
        public string? SitePhone { get; set; }
        public string? SiteFax { get; set; }
        public string? SiteSpec1 { get; set; }
        public string? SiteSpec2 { get; set; }
        public string? SiteSpecDesc1 { get; set; }
        public string? SiteSpecDesc2 { get; set; }
        public string? SiteAlternateID { get; set; }
        public string? SiteNYMIPar { get; set; }
        public string? SteeragePosition { get; set; }
        public string? NPI { get; set; }
        public string? SiteIdent { get; set; }
        public string? SelectionMethodID { get; set; }
        public string? SiteEmail { get; set; }
        public string? PUSRDF { get; set; }
        public string? SiteIPA { get; set; }
        public string? SiteEntity { get; set; }
        public string? SiteType { get; set; }
        public string? PhysicianName { get; set; }
        public string? OON { get; set; }

    }

    public class AttachmentEntity
    {
        public int Id { get; set; }
        public string? ReceivedDate { get; set; }
        public string? AttachmentName { get; set; }
        public string? AMSObjectValetId { get; set; }
        public string? DocumentType { get; set; }
        public string? CreatedBy { get; set; }
        public string? CreatedDate { get; set; }
    }

    public class NoteEntity
    {
        public int Id { get; set; }
        public string? Notes { get; set; }
        public string? CreatedBy { get; set; }
        public string? CreatedDate { get; set; }
    }

    public class CptCodeEntity
    {
        public int? Id { get; set; }
        public string? CptCode { get; set; }
        public string? CPTSimplifiedDesc { get; set; }
        public string? CreatedBy { get; set; }
        public string? CreatedDate { get; set; }
        public bool? PrivateDutyNurse { get; set; }
        public bool? CustomNeed { get; set; }
    }

    public class CareCoordinationActivityEntity
    {
        public int Id { get; set; }
        public string? Comments { get; set; }
        public string? UserId { get; set; }
        public string? RoleType { get; set; }
        public string? CreatedBy { get; set; }
        public string? CreatedDate { get; set; }
    }

    public class GetRequestDetailsByIdResultModel
    {
        public CareCoordinationRequestEntity? RequestEntity { get; set; }
        public IEnumerable<AttachmentEntity>? AttachmentsEntity { get; set; }
        public IEnumerable<NoteEntity>? NotesEntity { get; set; }
        public IEnumerable<CptCodeEntity>? CptCodesEntity { get; set; }
        public IEnumerable<CareCoordinationActivityEntity>? ActivitiesEntity { get; set; }

    }
}

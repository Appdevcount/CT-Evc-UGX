﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordination.Domain.Models
{
    public class RequestSearchResultEntity
    {
        public string? CareCoordinationEpisodeId { get; set; }
        public string? CareCoordinationEpisodeDate { get; set; }
        public string? CaseStatus { get; set; }
        public string? HealthPlan { get; set; }
        public int? CompanyId { get; set; }
        public string? Reason { get; set; }
        public string? DateOfService { get; set; }
        public string? DateOfClosing { get; set; }
        public bool? IsEscalated { get; set; }
        public string? CreatedBy { get; set; }
        public string? CreateDate { get; set; }
        public string? PatientID { get; set; }
        public string? PatientName { get; set; }
        public string? PatientDOB { get; set; }
        public string? Program { get; set; }
        public bool? StaffedRequest { get; set; }
        public string? SubServiceType { get; set; }
        public bool IsRestrictedMember { get; set; }

    }
}

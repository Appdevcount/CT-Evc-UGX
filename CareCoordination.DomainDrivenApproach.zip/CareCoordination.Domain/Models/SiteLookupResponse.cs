﻿namespace CareCoordination.Domain.Models;

public class GetSitesResponse
{
    public string? PRVNO { get; set; }
    public string? PNAME { get; set; }
    public string? PSNAM { get; set; }
    public string? APRNO { get; set; }
    public string? PADD1 { get; set; }
    public string? PADD2 { get; set; }
    public string? PCITY { get; set; }
    public string? PSTAT { get; set; }
    public string? PAZIP { get; set; }
    public string? PPHON { get; set; }
    public string? PPFAX { get; set; }
    public string? PTYPE { get; set; }
    public string? PTYP2 { get; set; }
    public string? MDPRV { get; set; }
    public string? PSMID { get; set; }
    public string? CONTRACT_EFFECTIVE_DATE { get; set; }
    public string? CONTRACT_TERM_DATE { get; set; }
    public string? FFS_VENDOR { get; set; }
    public string? GROUP_CARRIER { get; set; }
    public string? PLAN_TYPE { get; set; }
    public string? PROVIDER_ATTRIBUTE { get; set; }
    public string? PPSTRF { get; set; }
    public string? PROVIDER_PAR_FLAG { get; set; }
    public string? PreferredSort { get; set; }
    public string? GEOZIP { get; set; }
    public string? SelectableYN { get; set; }
    public string? NPI { get; set; }
    public string? TaxID { get; set; }
    public string? ENTITY { get; set; }
    public string? IPACODE { get; set; }
    public string? PUSRDF { get; set; }
    public string? PPPSTS { get; set; }
    public string? NetworkIds { get; set; }
}

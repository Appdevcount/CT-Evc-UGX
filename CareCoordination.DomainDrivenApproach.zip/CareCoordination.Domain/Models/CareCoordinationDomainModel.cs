﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordination.Domain.Models
{
    [ExcludeFromCodeCoverage]
    public class CareCoordinationDomainModel
    {
        public string? EpisodeId { get; set; }
        public int CompanyId { get; set; }
        public required string HealthPlan { get; set; }
        public required string Reason { get; set; }
        public string? Notes { get; set; }
        public DateTime? DateOfService { get; set; }
        public bool IsEscalated { get; set; }
        public Requestor? Requestor { get; set; }
        public PatientDetails? PatientDetails { get; set; }
        public bool StaffedRequest { get; set; }
        public string? SubServiceType { get; set; }

    }
    [ExcludeFromCodeCoverage]
    public class Requestor
    {
        public required string FirstName { get; set; }
        public string? LastName { get; set; }
        public string? PhoneNumber { get; set; }
        public string? Extension { get; set; }
        public string? Fax { get; set; }
        public string? Email { get; set; }
        public string? Facility { get; set; }
    }
    [ExcludeFromCodeCoverage]
    public class PatientDetails
    {
        public required string ID { get; set; }
        public required string Name { get; set; }
        public string? Addr1 { get; set; }
        public string? Addr2 { get; set; }
        public string? City { get; set; }
        public string? State { get; set; }
        public string? Zip { get; set; }
        public string? Sex { get; set; }
        public string? Phone { get; set; }
        public DateTime? DOB { get; set; }
        public string? OAOSubNo { get; set; }
        public string? OAOPerNo { get; set; }
        public string? OAOEmpNo { get; set; }
        public string? MemberCode { get; set; }
        public string? GroupNumber { get; set; }
        public string? PlanType { get; set; }
        public string? LineOfBusiness { get; set; }
        public string? Language { get; set; }
        public string? PatientPlanType { get; set; }
        public string? Entity { get; set; }
        public string? Category { get; set; }
        public string? IPA { get; set; }
        public long Ident { get; set; }
        public string? Email { get; set; }
        public string? CellPhone { get; set; }
        public string? JurisdictionState { get; set; }
        public string? TIT19 { get; set; }
        public int CaseFactor { get; set; }
        public string? PUSRDF { get; set; }
        public string? FundType { get; set; }
        public string? ERISA { get; set; }
        public string? EXTID { get; set; }
        public DateTime? MemberStartDate { get; set; }
        public bool IsQuickCreate { get; set; }

    }
}

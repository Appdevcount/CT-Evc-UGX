﻿using System.Diagnostics.CodeAnalysis;

namespace CareCoordination.Domain.Models
{
    [ExcludeFromCodeCoverage]
    public class UserRolesEntity
    {
        public string? user_ID { get; set; }
        public int? user_num { get; set; }
        public string? user_name { get; set; }
        public string? RoleType { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public int? RoleID { get; set; }
        public string? Permission { get; set; }
        public string? PermissionDescription { get; set; }
    }
}

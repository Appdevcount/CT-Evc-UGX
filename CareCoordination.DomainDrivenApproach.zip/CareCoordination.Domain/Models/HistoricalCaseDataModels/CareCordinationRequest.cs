﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordination.Domain.Models.HistoricalCaseDataModels
{
    public class CareCordinationRequest
    {
        public string ccRequestID { get; set; }
        public string ccCaseStatus { get; set; }
        public string ccReason { get; set; }
        public string caseManagerName { get; set; }
        public DateTime socDate { get; set; }
        public Member member { get; set; }
        public List<Procedure> procedure { get; set; }
        public ServicingProvider servicingProvider { get; set; }
    }

    public class Member
    {
        public string memberID { get; set; }
        public MemberPolicy memberPolicy { get; set; }
    }

    public class MemberPolicy
    {
        public string insurer { get; set; }
        public string program { get; set; }
    }

    public class Procedure
    {
        public string procedureCode { get; set; }
        public string procedureCodeDescription { get; set; }
    }

    public class Root
    {
        public CareCordinationRequest careCordinationRequest { get; set; }
    }

    public class ServicingProvider
    {
        public string physicianName { get; set; }
    }
}

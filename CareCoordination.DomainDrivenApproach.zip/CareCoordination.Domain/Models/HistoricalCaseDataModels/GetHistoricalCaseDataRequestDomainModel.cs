﻿using System.Diagnostics.CodeAnalysis;

namespace CareCoordination.Domain.Models.HistoricalCaseDataModels;

[ExcludeFromCodeCoverage]
public class GetHistoricalCaseDataRequestDomainModel
{
    public string? requestId { get; set; }
    public string? patientId { get; set; }
    public string? firstName { get; set; }
    public string? lastName { get; set; }
    public string? dateOfBirth { get; set; }
}

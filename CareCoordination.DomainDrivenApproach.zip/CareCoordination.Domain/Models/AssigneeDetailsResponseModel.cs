﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordination.Domain.Models
{
    public class AssigneeDetailsResponseModel
    {
        public string? AssigneeUser { get; set; }
        public string? AssigneeName { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordination.Domain.Models
{
    public class ProcedureCodeSearchResponseEntity
    {
        public string? ProcedureCode { get; set; }
        public string? ProcedureDesc { get; set; }

    }
}

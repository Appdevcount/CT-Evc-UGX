﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordination.Domain.Models
{
    [ExcludeFromCodeCoverage]
    public class CaseManagementEntity
    {
        public string? RequestId { get; set; }
        public bool? MissedStartOfCare { get; set; }
        public string? MissedStartOfCareReason { get; set; }
        public string? CaseStatus { get; set; }
        public bool? IsEscalated { get; set; }
        public DateTime? FollowUPDate { get; set; }
        public string? FollowUPNote { get; set; }
        public string? Notes { get; set; }
        public string? CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? PhoneNumber { get; set; }
        public string? Extension { get; set; }
        public string? Email { get; set; }
        public string? RequestType { get; set; }
        public DateTime? DateOfService { get; set; }
        public string? CloseReason { get; set; }

    }
}

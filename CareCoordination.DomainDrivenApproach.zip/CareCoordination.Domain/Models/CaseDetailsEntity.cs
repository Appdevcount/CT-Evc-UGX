﻿using System.Diagnostics.CodeAnalysis;

namespace CareCoordination.Domain.Models
{
    [ExcludeFromCodeCoverage]
    public class CaseDetailsEntity
    {
        public string? HealthPlan { get; set; }
        public int CompanyId { get; set; }
        public string? CptCode { get; set; }
        public string? Modality { get; set; }
        public string? PatientID { get; set; }
        public string? PatientDOB { get; set; }
        public string? PatientName { get; set; }
        public string? PatientState { get; set; }
        public string? PatientMemberCode { get; set; }
        public string? MemberQuickCreate { get; set; }
        public string? PatientIPA { get; set; }
        public string? GroupNumber { get; set; }
        public string? PatientZip { get; set; }
        public string? PatientEntity { get; set; }
        public string? PatientPlanType { get; set; }
        public string? LineOfBusiness { get; set; }
        public string? PlanType { get; set; }

    }
}

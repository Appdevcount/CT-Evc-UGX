﻿using System.Diagnostics.CodeAnalysis;

namespace CareCoordination.Domain.Models
{
    [ExcludeFromCodeCoverage]
    public class CareCoordinationAuthTokenEntity
    {
        public int? CareCoordinationTokenId { get; set; }
        public string? UserName { get; set; }
        public string? RefreshToken { get; set; }
        public DateTime? Expiration { get; set; }
        public DateTime? CreatedDate { get; set; }
    }
}

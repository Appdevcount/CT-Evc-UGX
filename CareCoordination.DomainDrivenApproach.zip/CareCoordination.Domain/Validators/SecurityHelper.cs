﻿using System.Diagnostics.CodeAnalysis;
using System.Text.RegularExpressions;

namespace CareCoordination.Api.Helpers
{
    [ExcludeFromCodeCoverage]
    public static class SecurityHelper
    {
        public static bool IsPotentialXss(string input)
        {
            if (string.IsNullOrEmpty(input))
                return false;

            string lowerInput = input.ToLowerInvariant();

            string[] xssPatterns = new[]
            {"<script", "</script", "javascript:", "onerror=", "onload=", "onclick=","eval(", "expression(", "src=", "iframe", "document.cookie", "alert("
};

            foreach (var pattern in xssPatterns)
            {
                if (lowerInput.Contains(pattern))
                    return true;
            }

            if (Regex.IsMatch(lowerInput, @"(%3C|%3E|%22|%27|%3D|%2F)"))
                return true;

            return false;
        }
    }

}

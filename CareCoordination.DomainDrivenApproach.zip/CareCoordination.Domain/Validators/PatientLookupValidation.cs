﻿using CareCoordination.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Diagnostics.CodeAnalysis;

namespace CareCoordination.Domain.Validators
{
    [ExcludeFromCodeCoverage]
    public static class PatientLookupValidation
    {
        public static string ValidateRequest(string? PatientID, string? PatientLastName, string? PatientDob, string? PatientFirstName)
        {
            string error = string.Empty;
            string specialCharPattern = @"[^a-zA-Z\s]";
            if (string.IsNullOrEmpty(PatientID) && string.IsNullOrEmpty(PatientLastName) && string.IsNullOrEmpty(PatientFirstName))
                {
                    error = "Either Patient Last Name or First Name or Patient ID  is mandatory!!";
                    return error;
                }
                else if (!string.IsNullOrEmpty(PatientFirstName) && Regex.IsMatch(PatientFirstName, specialCharPattern))
                {
                    error = "Patient First name cannot contain special characters or numbers";
                    return error;
                }
                else if (Regex.IsMatch(PatientLastName, specialCharPattern))
                {
                    error = "Patient last name cannot contain special characters or numbers";
                    return error;
                }
            
            return error;

        }
    } }

﻿using AutoMapper;
using CareCoordination.Domain.Constants;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordination.Domain.Validators
{
    public static class AttachmentValidation
    {
        [ExcludeFromCodeCoverage]
        public static string ValidateAttachment (IFormFile file)
        {
            string error = string.Empty;
            if (file == null || file.Length == 0)
            {
                error= "No file was uploaded.";
                return error;
            }

            long maxFileSizeInBytes = Constants.Constants.MaxFileSize * 1024 * 1024;

            if (file.Length > maxFileSizeInBytes)
            {
                error=  $"File size exceeds the limit of {Constants.Constants.MaxFileSize} MB.";
                return error;
            }
            if(!FileConstants.AllowedFileExtensions.Contains(Path.GetExtension(file.FileName)))
            {
                error = "Invalid file type. Only file types allowed are  -  .jpg, .png ,.jpeg, .pdf, .doc, .docx, .tif,.tiff, .txt,.zip";
                return error;
            }
            var fileName = file.FileName;
            var extensions = fileName.Split('.').Skip(1).ToList();
            if (extensions.Count > 1)
            {
                error = "Invalid file type due to multiple extension.";
                return error;
            }
            return error;
        }
    }

}


﻿using System.Text.RegularExpressions;
using System.Diagnostics.CodeAnalysis;
using CareCoordination.Domain.Models.HistoricalCaseDataModels;

namespace CareCoordination.Domain.Validators
{
    [ExcludeFromCodeCoverage]
    public static class GetHistoricalDataValidation
    {
        public static string ValidateRequest(GetHistoricalCaseDataRequestDomainModel input)
        {
            string error = string.Empty;
            if (string.IsNullOrEmpty(input?.patientId) && string.IsNullOrEmpty(input?.requestId)
                && (string.IsNullOrEmpty(input?.firstName) || string.IsNullOrEmpty(input?.lastName) || string.IsNullOrEmpty(input?.dateOfBirth)))
            {
                error = "Input validation error, provide RequestId / PatientId / FirstName, LastName, DateOfBirth.";
                return error;
            }
            return error;
        }
    } }

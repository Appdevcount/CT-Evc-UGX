using System;

namespace CareCoordination.Domain.Services
{
    public class AttachmentDomainService
    {
        public string ValidateAttachmentCount(int count, int maxCount)
        {
            if (count > maxCount)
            {
                return "The limit to attach files for this Request ID has reached.";
            }
            return string.Empty;
        }
    }
}

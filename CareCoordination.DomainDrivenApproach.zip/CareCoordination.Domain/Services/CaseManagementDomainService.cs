using System;
using CareCoordination.Domain.Entities;

namespace CareCoordination.Domain.Services
{
    public class CaseManagementDomainService
    {
        public bool CanEscalate(CaseManagementEntity caseEntity)
        {
            // Example business rule: Only escalate if not already escalated and meets criteria
            return !caseEntity.IsEscalated && caseEntity.Status == "Pending";
        }

        public bool CanAddNote(CaseManagementEntity caseEntity)
        {
            // Example business rule: Only add note if case is active
            return caseEntity.Status == "Active";
        }

        // Add more business rules as needed
    }
}

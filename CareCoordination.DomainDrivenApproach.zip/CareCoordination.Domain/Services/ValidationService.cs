using System;

namespace CareCoordination.Domain.Services
{
    public class ValidationService
    {
        public bool ValidateUser(string username)
        {
            // Add domain validation logic here
            return !string.IsNullOrWhiteSpace(username);
        }
    }
}

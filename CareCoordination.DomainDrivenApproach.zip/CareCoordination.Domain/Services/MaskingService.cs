using System;
using System.Reflection;

namespace CareCoordination.Domain.Services
{
    public class MaskingService
    {
        public T MaskPropertiesExcept<T>(T obj, string propertyToExclude)
        {
            T maskedObj = Activator.CreateInstance<T>();
            foreach (PropertyInfo prop in typeof(T).GetProperties())
            {
                if (!prop.CanRead || !prop.CanWrite)
                    continue;
                if (string.Equals(prop.Name, propertyToExclude, StringComparison.OrdinalIgnoreCase))
                {
                    prop.SetValue(maskedObj, prop.GetValue(obj));
                }
                else
                {
                    prop.SetValue(maskedObj, GetMaskedValue(prop.PropertyType));
                }
            }
            return maskedObj;
        }

        private object GetMaskedValue(Type type)
        {
            if (type == typeof(string)) return "***";
            if (type == typeof(int?) || type == typeof(long?) || type == typeof(short?)) return -1;
            if (type == typeof(DateTime?)) return DateTime.MinValue;
            if (type == typeof(bool?)) return false;
            if (type.IsValueType) return Activator.CreateInstance(type);
            return null;
        }
    }
}

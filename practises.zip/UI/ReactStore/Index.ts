import { combineReducers } from "redux";
// import { requestReducer } from "./requestReducer";
//import { authReducer } from "./auth-reducer";
  
export const rootReducer = combineReducers({ } as any);